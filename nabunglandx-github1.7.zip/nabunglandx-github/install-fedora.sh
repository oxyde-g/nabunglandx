#!/usr/bin/env bash
# Pasang nabunglandx di Fedora: menu aplikasi + ikon. Jalankan: bash install-fedora.sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

if ! python3 -c "import tkinter" 2>/dev/null; then
  echo "Memasang python3-tkinter (butuh sudo)..."
  sudo dnf install -y python3-tkinter
fi

# Pillow (opsional): wallpaper JPG/WEBP, blur, dan redup yang lebih halus
if ! python3 -c "import PIL" 2>/dev/null; then
  echo "Memasang python3-pillow (opsional, butuh sudo)..."
  sudo dnf install -y python3-pillow || echo "Dilewati - app tetap jalan (mode ringan)."
fi

mkdir -p "$HOME/.local/bin" \
         "$HOME/.local/share/applications" \
         "$HOME/.local/share/icons/hicolor/scalable/apps"

install -m755 "$DIR/nabunglandx.py" "$HOME/.local/bin/nabunglandx"

cat > "$HOME/.local/share/icons/hicolor/scalable/apps/nabunglandx.svg" <<'EOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#7c5cff"/><rect x="14" y="36" width="10" height="16" rx="3" fill="#fff"/><rect x="27" y="24" width="10" height="28" rx="3" fill="#fff" opacity=".9"/><rect x="40" y="12" width="10" height="40" rx="3" fill="#fff"/></svg>
EOF

cat > "$HOME/.local/share/applications/nabunglandx.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=nabunglandx
Comment=Pengatur keuangan ringan
Exec=$HOME/.local/bin/nabunglandx
Icon=nabunglandx
Terminal=false
Categories=Office;Finance;
StartupWMClass=Nabunglandx
EOF

update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
gtk-update-icon-cache -f "$HOME/.local/share/icons/hicolor" 2>/dev/null || true

echo "Selesai! Cari 'nabunglandx' di menu aplikasi, atau jalankan: nabunglandx"
