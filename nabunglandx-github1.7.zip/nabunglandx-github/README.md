# nabunglandx

Pengatur keuangan pribadi yang **ringan** untuk Fedora Linux dan Windows. Catat uang masuk/keluar,
pilih rekening dan tanggal lewat kalender, lihat diagram bulanan, dan impor mutasi bank tanpa input manual.

Hanya memakai pustaka bawaan Python (`tkinter` + `sqlite3`). Data tersimpan lokal di komputermu.

## Fitur

- **Dashboard**: ringkasan saldo, diagram batang pemasukan vs pengeluaran per bulan, donat pengeluaran per kategori.
- **Transaksi**: pemasukan, pengeluaran, dan transfer antar rekening. Rekening dipilih dari daftar, tanggal dari kalender.
- **Rekening**: bank, tabungan, e-wallet, tunai. Bisa digabung (pindah bank tanpa input ulang).
- **Bisnis**: kalkulator untung-rugi usaha dengan diagram alur uang (lihat bagian *Menu Bisnis* di bawah).
- **Impor mutasi**: baca CSV mutasi bank/e-wallet, kategori ditebak otomatis, impor ulang aman (duplikat dilewati).
- **Sembunyikan saldo**: samarkan saldo, pemasukan, dan pengeluaran (`F8`).
- **Tab collapse**: sidebar bisa diciutkan jadi ikon (`F9`), kartu di tiap halaman bisa dilipat.
- **Zoom & font responsif**: `Ctrl` + scroll / `Ctrl +` / `Ctrl -` / `Ctrl 0`; font ikut ukuran jendela.
- **Wallpaper**: gradasi bawaan atau gambar dari file, atur bagian gambar yang dipakai (bingkai geser + zoom),
  redup, blur, pilih area (sidebar / halaman), dan transparansi jendela.
- **Tema**: Malam, Terang, Samudra, Hutan, Senja, atau Kustom + warna aksen bebas.
- **Ekspor/backup**: ekspor CSV, backup dan restore database.

Kolom jumlah memakai titik sebagai pemisah ribuan otomatis (`680890` jadi `680.890`) dan kursor ikut maju.
Koma = desimal (dibulatkan ke rupiah).

## Pasang

### Fedora

```bash
git clone https://github.com/USERNAME/nabunglandx.git
cd nabunglandx
bash install-fedora.sh
```

Skrip memasang `python3-tkinter` (dan Pillow, opsional), lalu menambahkan app ke menu aplikasi.
Atau langsung jalankan: `python3 nabunglandx.py`.

### Windows

1. Pasang Python dari <https://www.python.org/downloads/> (centang **Add python.exe to PATH**; tkinter ikut terpasang).
2. Klik dua kali `nabunglandx.pyw` (tanpa jendela konsol).

`nabunglandx.pyw` isinya sama persis dengan `nabunglandx.py`.

### Pillow (opsional)

Tanpa Pillow, wallpaper hanya mendukung PNG/GIF. Dengan Pillow: JPG/WEBP, blur, redup halus, dan pengatur bagian gambar.
App bisa memasangnya sendiri dari Pengaturan, atau: `pip install pillow` / `sudo dnf install python3-pillow`.

## Menu Bisnis

Kalkulator untung-rugi usaha yang dibuat supaya mudah dipahami (warung, toko online, jasa, paket wisata, dll).
Isi angka dari atas ke bawah, hasilnya langsung muncul di sebelah kanan.

1. **Jualan**: apa yang dijual (cangkir, porsi, paket, orang), jumlah terjual, dan harga jual.
2. **Modal pokok**: biaya yang *habis tiap kali ada yang beli* (bahan, barang, kemasan).
3. **Biaya tetap**: dibayar sama saja walau jualan sedikit (sewa, gaji, listrik, iklan).
4. **Pajak** (boleh dilewati): final % dari omzet, atau % dari untung.

Tiap angka bisa diketik atau digeser dengan slider.

Yang ditampilkan:

- **Hasil usahamu**: kesimpulan dengan bahasa sehari-hari, misalnya *"UNTUNG Rp 2.680.000 sebulan. Dari tiap Rp 100 yang masuk, sekitar Rp 11 jadi untung bersih"*, lengkap dengan saran kalau rugi.
- **Uangmu dipakai untuk apa?**: bar pembagian uang masuk ke modal pokok, biaya tetap, pajak, dan untung.
- **Titik aman**: meteran jumlah terjual minimum supaya tidak rugi.
- **Rincian hitungan**: laba kotor, untung sebelum pajak, untung bersih, lengkap dengan rumusnya.
- **Mau untung berapa?**: isi target untung, lalu app menghitung berapa yang harus terjual atau harga minimalnya.
- **Alur uang lengkap**: diagram Sankey dari mana uang masuk dan ke mana perginya (oranye = modal pokok, ungu = biaya tetap, hijau = untung).
- **Skenario**: simpan banyak skenario (ada 4 contoh), duplikat, ubah nama, hapus, dan ekspor CSV.

Rumus:

```
Laba kotor          = Uang masuk - Modal pokok
Untung sebelum pajak = Laba kotor - Biaya tetap
Untung bersih       = Untung sebelum pajak - Pajak
Titik aman          = Biaya tetap / (Harga per satuan - Modal per satuan)
```

Angka pada contoh hanya karangan untuk belajar. Ganti dengan data usahamu.

## Pintasan

| Tombol | Fungsi |
|---|---|
| `Ctrl` + scroll, `Ctrl +`, `Ctrl -` | Zoom in / out |
| `Ctrl 0` | Reset zoom |
| `F8` / `Ctrl Shift H` | Sembunyikan / tampilkan saldo |
| `F9` / `Ctrl \` | Ciutkan / lebarkan sidebar |
| `Ctrl 1` ... `Ctrl 5` | Dashboard, Transaksi, Rekening, Bisnis, Pengaturan |

## Lokasi data

- Linux: `~/.local/share/nabunglandx/`
- Windows: `%APPDATA%\nabunglandx\`

Berisi `nabunglandx.db` (data) dan `settings.json` (tampilan).

## Format CSV mutasi

Butuh kolom tanggal dan jumlah (atau debit/kredit). Contoh:

```csv
Tanggal;Keterangan;Debit;Kredit
01/10/2026;GOFOOD;25.000,00;
02/10/2026;GAJI;;1.500.000,00
```

## Lisensi

MIT, lihat [LICENSE](LICENSE).
