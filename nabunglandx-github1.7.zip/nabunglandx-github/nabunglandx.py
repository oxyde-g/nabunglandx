#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
nabunglandx - pengatur keuangan pribadi yang ringan.

Hanya memakai pustaka bawaan Python (tkinter + sqlite3), jadi tidak perlu pip install.
Pillow (opsional) hanya dipakai untuk gambar wallpaper JPG/WEBP, blur, dan redup yang halus.
Jalan di Fedora Linux dan Windows dengan file yang sama.
Data tersimpan lokal:  Linux  ~/.local/share/nabunglandx/
                       Windows %APPDATA%\\nabunglandx\\
"""
import base64
import calendar
import csv
import io
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import weakref
import tkinter as tk
from datetime import date, datetime, timedelta
from tkinter import colorchooser, filedialog, font as tkfont, messagebox, ttk

APP = "nabunglandx"
VERSION = "1.7"

MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
          "Agustus", "September", "Oktober", "November", "Desember"]
MON3 = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]
DAYS = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
DAY3 = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"]

KINDS = ["Bank", "Tabungan", "E-Wallet", "Tunai"]
DEF_CAT = {
    "out": ["Makan", "Transportasi", "Belanja", "Tagihan", "Kuliah", "Hiburan",
            "Kesehatan", "Pulsa & Internet", "Lainnya"],
    "in": ["Uang saku", "Gaji", "Beasiswa", "Freelance", "Hadiah", "Lainnya"],
}
PALETTE = ["#7c5cff", "#22b8cf", "#f59e0b", "#ef4444", "#10b981",
           "#ec4899", "#3b82f6", "#a3e635", "#f97316", "#14b8a6"]

THEMES = {
    "Malam": dict(bg="#0f1117", side="#0b0d12", card="#181b24", card2="#1f2330", text="#e8eaf0",
                  muted="#8b91a3", accent="#7c5cff", good="#2ecc9a", bad="#ff6b81", line="#272c3b"),
    "Terang": dict(bg="#f3f5fa", side="#ffffff", card="#ffffff", card2="#eef1f8", text="#1b2033",
                   muted="#6b7390", accent="#4f46e5", good="#12a37a", bad="#e5484d", line="#e1e5f0"),
    "Samudra": dict(bg="#0b1620", side="#08111a", card="#122434", card2="#18304a", text="#e6f1fa",
                    muted="#7f9bb3", accent="#22b8cf", good="#3ddc97", bad="#ff7a7a", line="#1f3a54"),
    "Hutan": dict(bg="#0f1a14", side="#0b130e", card="#16261c", card2="#1d3326", text="#e8f3ec",
                  muted="#86a393", accent="#4ade80", good="#4ade80", bad="#fb7185", line="#23402f"),
    "Senja": dict(bg="#1a1216", side="#140d11", card="#241920", card2="#2d1f28", text="#f6e9ee",
                  muted="#a58b97", accent="#fb923c", good="#34d399", bad="#f43f5e", line="#3a2733"),
}

# wallpaper bawaan (gradasi 3 warna, dibuat langsung oleh aplikasi - tanpa file gambar)
WALLS = {
    "aurora": ("Aurora", ["#1b1464", "#6a3df0", "#22d3ee"]),
    "senja": ("Senja", ["#2b1055", "#d946a8", "#ffb347"]),
    "laut": ("Laut", ["#06202b", "#0e5e75", "#38bdf8"]),
    "hutan": ("Rimba", ["#052e1f", "#15803d", "#bef264"]),
    "fajar": ("Fajar", ["#fde68a", "#fda4af", "#a5b4fc"]),
    "malam": ("Langit", ["#05060a", "#1a1f3a", "#3b2f6b"]),
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts(
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'Bank',
    init INTEGER NOT NULL DEFAULT 0, color TEXT NOT NULL DEFAULT '#7c5cff');
CREATE TABLE IF NOT EXISTS tx(
    id INTEGER PRIMARY KEY, day TEXT NOT NULL, kind TEXT NOT NULL, amount INTEGER NOT NULL,
    acc INTEGER NOT NULL, acc2 INTEGER, cat TEXT, note TEXT);
CREATE INDEX IF NOT EXISTS ix_tx_day ON tx(day);
CREATE TABLE IF NOT EXISTS biz(
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, data TEXT NOT NULL);
"""


# ----------------------------------------------------------------- helper umum
def data_dir():
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
    elif sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    p = os.path.join(base, APP)
    os.makedirs(p, exist_ok=True)
    return p


def num(n):
    return f"{int(n):,}".replace(",", ".")


def rp(n):
    return ("-" if n < 0 else "") + "Rp " + num(abs(n))


MASK = "Rp ••••••"


# ---- angka: titik = pemisah ribuan (diketik/ditempel), koma = desimal. Rupiah akhirnya dibulatkan.
def _group(d):
    return num(int(d)) if d else ""


def read_money(s):
    """-> (rupiah bulat, bagian utuh, pecahan). 'Rp 1.500'->1500 | '680.890'->680890 | '1.234,56'->1235 (titik = ribuan, koma = desimal)"""
    t = re.sub(r"[^0-9.,]", "", str(s or ""))
    if not t:
        return 0, "", ""
    if "," in t:
        left, _, right = t.partition(",")
        left, frac = left.replace(".", ""), re.sub(r"\D", "", right)[:2]
    else:
        left, frac = t.replace(".", ""), ""
    v = int(left) if left else 0
    if frac and int(frac.ljust(2, "0")) >= 50:
        v += 1
    return v, left, frac


def parse_money(s):
    return read_money(s)[0]


def fmt_money_text(raw):
    """Rapikan teks yang sedang diketik: ribuan diberi titik otomatis, koma = desimal."""
    t = re.sub(r"[^0-9.,]", "", raw)
    if "," in t:
        left, _, right = t.partition(",")
        left = re.sub(r"\D", "", left).lstrip("0")
        return (_group(left) or "0") + "," + re.sub(r"\D", "", right)[:2]
    return _group(re.sub(r"\D", "", t).lstrip("0"))


def money_hint(raw):
    if not re.search(r"\d", raw or ""):
        return ""
    v, left, frac = read_money(raw)
    s = "Terbaca: " + rp(v)
    if frac:
        s += f"  (dibulatkan dari {_group(left.lstrip('0')) or '0'},{frac})"
    elif v >= 10000:
        s += "  ·  " + short(v)
    return s


def rgba_png_b64(color, alpha):
    """PNG 1x1 berwarna + transparansi (tanpa Pillow) untuk pencampuran lewat compositing bawaan Tk."""
    import struct
    import zlib
    r, g, b = hex_rgb(color)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    raw = b"\x00" + bytes((r, g, b, max(0, min(255, round(alpha * 255)))))
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))
    return base64.b64encode(png)


def grad_rgb(stops, w, h):
    """Gradasi diagonal 3 warna -> baris-baris (r,g,b)."""
    c = [hex_rgb(s) for s in stops]
    rows = []
    for y in range(h):
        v = y / max(1, h - 1)
        row = []
        for x in range(w):
            t = (x / max(1, w - 1) + v) / 2
            a, b, k = (c[0], c[1], t * 2) if t < .5 else (c[1], c[2], (t - .5) * 2)
            row.append((round(a[0] + (b[0] - a[0]) * k), round(a[1] + (b[1] - a[1]) * k),
                        round(a[2] + (b[2] - a[2]) * k)))
        rows.append(row)
    return rows


# --------------------------------------------------------------- impor mutasi
_BLN = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "mei": 5, "may": 5, "jun": 6, "jul": 7, "agu": 8,
        "agt": 8, "aug": 8, "sep": 9, "okt": 10, "oct": 10, "nov": 11, "des": 12, "dec": 12}
_KEYS = {  # kata kunci sederhana -> kategori pengeluaran
    "Makan": ("gofood", "grabfood", "shopeefood", "resto", "cafe", "kopi", "warung", "bakso", "makan",
              "indomaret", "alfamart", "mcd", "kfc"),
    "Transportasi": ("gojek", "grab", "bensin", "pertamina", "tol", "krl", "kai", "transjakarta", "parkir"),
    "Belanja": ("shopee", "tokopedia", "lazada", "tiktok", "blibli"),
    "Tagihan": ("listrik", "pln", "pdam", "bpjs", "kos", "sewa", "cicilan"),
    "Pulsa & Internet": ("pulsa", "telkomsel", "indosat", "xl", "axis", "data", "wifi", "indihome"),
    "Hiburan": ("netflix", "spotify", "youtube", "steam", "game", "bioskop", "xxi"),
    "Kuliah": ("ukt", "spp", "kampus", "buku", "kuliah"),
}


def guess_cat(text, kind):
    if kind != "out":
        return "Lainnya"
    low = (text or "").lower()
    for cat, words in _KEYS.items():
        if any(w in low for w in words):
            return cat
    return "Lainnya"


def parse_date(s):
    s = (s or "").strip().replace("'", " ")
    if not s:
        return None
    s = re.split(r"[T ]\d{1,2}:\d{2}", s)[0].strip()
    m = re.match(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$", s)
    if m:
        y, mo, d = map(int, m.groups())
    else:
        m = re.match(r"^(\d{1,2})[-/. ]+([A-Za-z]{3,})[-/. ,]+(\d{2,4})$", s)
        if m and m.group(2)[:3].lower() in _BLN:
            d, mo, y = int(m.group(1)), _BLN[m.group(2)[:3].lower()], int(m.group(3))
        else:
            m = re.match(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$", s)
            if not m:
                return None
            d, mo, y = map(int, m.groups())
    if y < 100:
        y += 2000
    try:
        return date(y, mo, d)
    except ValueError:
        return None


def parse_amount(s):
    """-> (nilai positif bulat, tanda: -1 / +1 / 0 bila tidak diketahui)"""
    s = (s or "").strip()
    if not s:
        return 0, 0
    low = s.lower()
    sign = 0
    if "-" in s or (s.startswith("(") and s.endswith(")")):
        sign = -1
    if re.search(r"\b(db|dr|d)\b|debit", low):
        sign = -1
    elif re.search(r"\b(cr|k)\b|kredit|credit", low):
        sign = 1
    t = re.sub(r"[^0-9.,]", "", s)
    if not t:
        return 0, sign
    if "." in t and "," in t:
        dec = "," if t.rfind(",") > t.rfind(".") else "."
        t = t.replace("," if dec == "." else ".", "").replace(dec, ".")
    elif "," in t or "." in t:
        sep = "," if "," in t else "."
        parts = t.split(sep)
        if len(parts) == 2 and len(parts[1]) in (1, 2):      # 50000,00  -> desimal
            t = parts[0] + "." + parts[1]
        else:                                                # 1.234.567 -> ribuan
            t = "".join(parts)
    try:
        return int(round(float(t))), sign
    except ValueError:
        return 0, sign


_H = {
    "date": ("tanggal", "tgl", "date", "waktu", "posting date", "transaction date", "tanggal transaksi"),
    "desc": ("keterangan", "uraian", "deskripsi", "description", "remark", "remarks", "berita", "catatan",
             "transaksi", "detail", "narrative", "note", "notes"),
    "debit": ("debit", "keluar", "pengeluaran", "db", "debet", "withdrawal", "uang keluar"),
    "credit": ("kredit", "masuk", "pemasukan", "cr", "credit", "deposit", "uang masuk"),
    "amount": ("jumlah", "amount", "nominal", "mutasi", "nilai"),
    "type": ("jenis", "tipe", "type", "d/c", "dc", "db/cr", "d/k", "dk", "cr/db", "k/d"),
}


def _role(h):
    h = h.strip().lower()
    for role, names in _H.items():
        if h in names:
            return role
    return None


def parse_mutasi(path):
    """Baca CSV mutasi bank (BCA/BRI/Mandiri/BNI/Jago/SeaBank/e-wallet/ekspor nabunglandx).
    -> (daftar baris, jumlah baris dilewati)"""
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        raw = fh.read()
    head = raw[:4000]
    delim = max((",", ";", "\t"), key=head.count)
    rows = list(csv.reader(raw.splitlines(), delimiter=delim))
    hdr_i, cols = None, {}
    for i, r in enumerate(rows[:40]):
        c = {}
        for j, h in enumerate(r):
            role = _role(h)
            if role and role not in c:
                c[role] = j
        if "date" in c and (("amount" in c) or ("debit" in c) or ("credit" in c)):
            hdr_i, cols = i, c
            break
    if hdr_i is None:
        raise ValueError("Kolom tidak dikenali. Butuh kolom Tanggal dan Jumlah (atau Debit/Kredit).")
    out, skipped = [], 0
    for r in rows[hdr_i + 1:]:
        if not any(x.strip() for x in r):
            continue
        get = lambda k: r[cols[k]].strip() if k in cols and cols[k] < len(r) else ""
        d = parse_date(get("date"))
        if not d:
            skipped += 1
            continue
        kind, amt = None, 0
        tcol = get("type").lower()
        if "debit" in cols or "credit" in cols:
            dv, _ = parse_amount(get("debit"))
            cv, _ = parse_amount(get("credit"))
            if dv and not cv:
                kind, amt = "out", dv
            elif cv and not dv:
                kind, amt = "in", cv
        if kind is None and "amount" in cols:
            amt, sg = parse_amount(get("amount"))
            if tcol.startswith(("pemasukan", "masuk", "cr", "k", "kredit", "credit", "in")):
                sg = 1
            elif tcol.startswith(("pengeluaran", "keluar", "db", "d", "debit", "out")):
                sg = -1
            elif tcol.startswith("transfer"):
                sg = 0
                amt = 0
            if sg == 0 and amt and not tcol.startswith("transfer"):
                sg = 1                                    # angka tanpa tanda = uang masuk
            kind = "in" if sg > 0 else "out" if sg < 0 else None
        if not kind or amt <= 0:
            skipped += 1
            continue
        desc = get("desc")
        out.append(dict(day=d.isoformat(), kind=kind, amount=amt, note=desc[:120],
                        cat=guess_cat(desc, kind) if kind == "out" else "Lainnya"))
    return out, skipped


def short(v):
    v = abs(v)
    if v >= 1e9:
        s, u = v / 1e9, "M"
    elif v >= 1e6:
        s, u = v / 1e6, "jt"
    elif v >= 1e3:
        s, u = v / 1e3, "rb"
    else:
        return str(int(v))
    return f"{s:.1f}".rstrip("0").rstrip(".").replace(".", ",") + u


def nice_max(v):
    if v <= 0:
        return 1
    e = 10 ** int(math.floor(math.log10(v)))
    for k in (1, 2, 4, 8, 10):
        if v <= k * e:
            return k * e
    return 10 * e


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    ra, rb = hex_rgb(a), hex_rgb(b)
    return "#%02x%02x%02x" % tuple(round(x + (y - x) * t) for x, y in zip(ra, rb))


def lum(h):
    r, g, b = hex_rgb(h)
    return (r * 299 + g * 587 + b * 114) / 1000


def on_color(h):
    return "#ffffff" if lum(h) < 150 else "#10131a"


def fmt_date(d, long=False):
    if long:
        return f"{DAYS[d.weekday()]}, {d.day} {MON3[d.month - 1]} {d.year}"
    return f"{d.day} {MON3[d.month - 1]}"


def load_settings(path):
    cfg = {"theme": "Malam", "accent": "", "font": 10, "custom": {}, "zoom": 1.0, "autofont": True,
           "alpha": 100, "hide": False, "side": None, "fold": {}, "win": [1240, 800], "wp": {"src": "", "dim": 35, "blur": 0, "zoom": 100, "fx": 50, "fy": 50,
                                                       "side": True, "body": True}}
    try:
        with open(path, encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            wp = dict(cfg["wp"])
            if isinstance(saved.get("wp"), dict):
                wp.update(saved["wp"])
            cfg.update(saved)
            cfg["wp"] = wp
            if not isinstance(cfg.get("fold"), dict):
                cfg["fold"] = {}
    except Exception:
        pass
    for k, lo, hi, d in (("zoom", .7, 2.0, 1.0), ("alpha", 40, 100, 100), ("font", 7, 20, 10)):
        try:
            cfg[k] = max(lo, min(hi, float(cfg[k]) if k == "zoom" else int(cfg[k])))
        except (TypeError, ValueError):
            cfg[k] = d
    return cfg


def resolve_theme(cfg):
    name = cfg.get("theme", "Malam")
    if name == "Kustom":
        c = {k: cfg.get("custom", {}).get(k, THEMES["Malam"][k]) for k in ("bg", "card", "text")}
        dark = lum(c["bg"]) < 140
        t = dict(bg=c["bg"], card=c["card"], text=c["text"], accent=THEMES["Malam"]["accent"])
        t["side"] = mix(c["bg"], "#000000", .3) if dark else c["card"]
        t["card2"] = mix(c["card"], c["text"], .07)
        t["muted"] = mix(c["text"], c["bg"], .5)
        t["line"] = mix(c["card"], c["text"], .13)
        t["good"] = "#2ecc9a" if dark else "#12a37a"
        t["bad"] = "#ff6b81" if dark else "#e5484d"
    else:
        t = dict(THEMES.get(name, THEMES["Malam"]))
    if cfg.get("accent"):
        t["accent"] = cfg["accent"]
    return t


# ------------------------------------------------------------------- bisnis (untung-rugi & alur uang)
COL_IN, COL_POKOK, COL_TETAP, GREY = "#38bdf8", "#fb923c", "#818cf8", "#94a3b8"
BIZ_TAX = (("none", "Tanpa pajak"), ("final", "% dari omzet"), ("umum", "% dari untung"))
BIZ_OLD_UMROH = ([35000000], [15000000, 8000000, 6000000, 15000000, 1500000])   # contoh lama (dari gambar) -> diganti


def biz_model(unit, per, qty, inc, cost, tax_mode="none", tax=0.0):
    """inc: [(nama, nilai, dasar)]  cost: [(nama, nilai, dasar)]   dasar: 'unit' = per satuan, 'tetap' = sekali/periode."""
    return {"unit": unit, "per": per, "qty": qty, "tax_mode": tax_mode, "tax": tax, "target": 0,
            "inc": [{"n": n, "v": int(v), "b": b} for n, v, b in inc],
            "cost": [{"n": n, "v": int(v), "b": b} for n, v, b in cost]}


def biz_template(key):
    if key == "kopi":
        return biz_model("Cangkir", "sebulan", 1500, [("Penjualan kopi & minuman", 16000, "unit")],
                         [("Biji kopi & susu", 5500, "unit"), ("Gula, es & topping", 1500, "unit"),
                          ("Gelas & sedotan", 700, "unit"), ("Sewa tempat", 3000000, "tetap"),
                          ("Gaji 2 barista", 5000000, "tetap"), ("Listrik & air", 900000, "tetap"),
                          ("Internet & lain-lain", 350000, "tetap"), ("Promosi", 400000, "tetap")],
                         "final", 0.5)
    if key == "toko":
        return biz_model("Pcs", "sebulan", 400, [("Harga jual barang", 85000, "unit")],
                         [("Beli barang dari supplier", 52000, "unit"), ("Packing & bubble wrap", 2500, "unit"),
                          ("Fee marketplace", 6000, "unit"), ("Gaji admin", 2500000, "tetap"),
                          ("Iklan", 2000000, "tetap"), ("Internet", 300000, "tetap")], "final", 0.5)
    if key == "jasa":
        return biz_model("Proyek", "sebulan", 5, [("Fee proyek", 3500000, "unit")],
                         [("Bantuan freelancer", 800000, "unit"), ("Aset & lisensi per proyek", 150000, "unit"),
                          ("Langganan software", 600000, "tetap"), ("Internet", 300000, "tetap"),
                          ("Transport", 400000, "tetap")])
    if key == "wisata":
        return biz_model("Peserta", "per trip", 25, [("Biaya paket per peserta", 4500000, "unit")],
                         [("Transportasi", 1100000, "unit"), ("Penginapan", 1300000, "unit"),
                          ("Makan", 600000, "unit"), ("Tiket masuk & pemandu", 450000, "unit"),
                          ("Tour leader", 3000000, "tetap"), ("Promosi & admin", 1500000, "tetap")])
    return biz_model("Unit", "sebulan", 1, [("Harga jual", 0, "unit")], [("Modal per unit", 0, "unit")])


BIZ_TEMPLATES = (("kopi", "Warung Kopi (contoh)"), ("toko", "Toko Online (contoh)"),
                 ("jasa", "Jasa / Freelance (contoh)"), ("wisata", "Paket Wisata (contoh)"),
                 ("kosong", "Kosong (isi sendiri)"))


def biz_clean(d):
    """Rapikan data skenario dari database (aman terhadap data rusak, kurang kolom, atau format lama)."""
    base = biz_template("kosong")
    if not isinstance(d, dict):
        return base
    m = {"unit": str(d.get("unit") or "Unit")[:20], "per": str(d.get("per") or "sebulan")[:20],
         "inc": [], "cost": [], "tax_mode": "none"}
    try:
        m["qty"] = max(1, min(10 ** 7, int(float(d.get("qty", 1)))))
    except (TypeError, ValueError):
        m["qty"] = 1
    try:
        m["tax"] = max(0.0, min(90.0, float(d.get("tax", 0))))
    except (TypeError, ValueError):
        m["tax"] = 0.0
    try:
        m["target"] = max(0, int(float(d.get("target", 0))))
    except (TypeError, ValueError):
        m["target"] = 0
    if d.get("tax_mode") in ("none", "final", "umum"):
        m["tax_mode"] = d["tax_mode"]
    for key in ("inc", "cost"):
        lst = d.get(key)
        for it in lst if isinstance(lst, list) else []:
            if not isinstance(it, dict):
                continue
            try:
                v = max(0, int(float(it.get("v", 0))))
            except (TypeError, ValueError):
                v = 0
            m[key].append({"n": str(it.get("n", ""))[:60], "v": v, "b": "tetap" if it.get("b") == "tetap" else "unit"})
    return m if (m["inc"] or m["cost"]) else base


def biz_is_old_umroh(d):
    """Contoh lama (angka dari gambar) yang belum diubah pengguna -> boleh diganti contoh baru."""
    try:
        return ([i["v"] for i in d["inc"]] == BIZ_OLD_UMROH[0] and [i["v"] for i in d["cost"]] == BIZ_OLD_UMROH[1])
    except (KeyError, TypeError):
        return False


def biz_calc(m):
    """Seluruh hitungan. Item 'unit' dikali jumlah terjual; item 'tetap' dihitung sekali per periode.
    Modal pokok = biaya per satuan (habis tiap jual). Biaya tetap (operasional) = sewa, gaji, dll."""
    q = max(1, int(m.get("qty", 1)))

    def tot(it):
        return int(it["v"]) * (q if it.get("b", "unit") == "unit" else 1)
    inc = [(it["n"] or "Pemasukan", tot(it)) for it in m["inc"]]
    pokok_items = [(it["n"] or "Modal", tot(it)) for it in m["cost"] if it.get("b", "unit") == "unit"]
    tetap_items = [(it["n"] or "Biaya", tot(it)) for it in m["cost"] if it.get("b") == "tetap"]
    omzet = sum(v for _, v in inc)
    pokok = sum(v for _, v in pokok_items)
    ops = sum(v for _, v in tetap_items)
    kotor = omzet - pokok
    ebt = kotor - ops
    mode = m.get("tax_mode", "none")
    rate = max(0.0, min(0.9, float(m.get("tax", 0)) / 100))
    if mode == "final":
        pajak = round(max(0, omzet) * rate)
    elif mode == "umum":
        pajak = round(max(0, ebt) * rate)
    else:
        pajak = 0
        mode = "none"
    bersih = ebt - pajak
    biaya = pokok + ops
    # titik impas & target: n = (T*kT + F - I_tetap*kO) / (p*kO - vc)
    p = sum(it["v"] for it in m["inc"] if it.get("b", "unit") == "unit")
    i_fix = sum(it["v"] for it in m["inc"] if it.get("b") == "tetap")
    vc = sum(it["v"] for it in m["cost"] if it.get("b", "unit") == "unit")
    fix = sum(it["v"] for it in m["cost"] if it.get("b") == "tetap")
    ko = 1 - rate if mode == "final" else 1.0
    kt = 1 / (1 - rate) if mode == "umum" else 1.0
    cm = p * ko - vc
    target = max(0, int(m.get("target", 0)))

    def units_for(T):
        if cm <= 0:
            return None
        return max(0, math.ceil((T * kt + fix - i_fix * ko) / cm - 1e-9))

    def price_for(T):
        return max(0.0, ((T * kt + biaya) / ko - i_fix) / q)
    spend = [(n, v) for n, v in pokok_items + tetap_items if v > 0]
    top = max(spend, key=lambda x: x[1]) if spend else None
    return dict(q=q, inc=inc, pokok_items=pokok_items, tetap_items=tetap_items, omzet=omzet, pokok=pokok, ops=ops,
                kotor=kotor, ebt=ebt, pajak=pajak, bersih=bersih, biaya=biaya, mode=mode, rate=rate,
                deficit=max(0, -bersih), p=p, vc=vc, fix=fix, i_fix=i_fix, cm=cm, target=target,
                top=top, top_pct=(top[1] / biaya if top and biaya else 0.0),
                m_kotor=kotor / omzet if omzet > 0 else 0.0, m_bersih=bersih / omzet if omzet > 0 else 0.0,
                roi=bersih / biaya if biaya > 0 else 0.0, r_biaya=biaya / omzet if omzet > 0 else 0.0,
                bep=units_for(0), bep_price=price_for(0), t_units=units_for(target), t_price=price_for(target))


def biz_say(c, m, M):
    """Kesimpulan dalam bahasa sehari-hari. M = fungsi format uang (bisa menyamarkan angka)."""
    u, per, q = (m.get("unit") or "unit").strip().lower(), (m.get("per") or "sebulan").strip(), c["q"]
    if c["omzet"] <= 0 and c["biaya"] <= 0:
        return dict(tone="muted", head="Belum ada hitungan",
                    sub="Isi harga jual dan jumlah terjual di sebelah kiri. Hasilnya langsung muncul di sini.", tips=[])
    cents = round(c["m_bersih"] * 100)
    tips = []
    if c["bersih"] > 0:
        tone, head = "good", f"UNTUNG {M(c['bersih'])} {per}"
        sub = (f"Dari tiap Rp 100 yang masuk, sekitar Rp {cents} jadi untung bersih. "
               f"Tiap {u} menyisakan {M(round(c['bersih'] / q))}.")
    elif c["bersih"] == 0:
        tone, head = "muted", "IMPAS (pas-pasan)"
        sub = "Uang masuk sama dengan semua pengeluaran: tidak untung, tidak rugi."
    else:
        tone, head = "bad", f"RUGI {M(-c['bersih'])} {per}"
        sub = f"Uang masuk kurang {M(-c['bersih'])} untuk menutup semua pengeluaran."
        if c["bep"] is not None:
            tips.append(f"Supaya tidak rugi: jual minimal {num(c['bep'])} {u} (sekarang {num(q)}), atau naikkan "
                        f"harga jadi minimal {M(math.ceil(c['bep_price'] - 1e-9))} per {u}, atau kurangi biaya.")
        else:
            tips.append(f"Harga jual per {u} ({M(c['p'])}) lebih kecil dari modalnya ({M(c['vc'])}), jadi makin "
                        f"banyak terjual makin rugi. Naikkan harga atau turunkan modal.")
    if c["bersih"] >= 0 and c["bep"] is not None and c["omzet"] > 0:
        tips.append(f"Titik aman di {num(c['bep'])} {u}. Sekarang {num(q)}: " +
                    (f"lebih {num(q - c['bep'])} dari titik aman." if q > c["bep"] else "pas di titik aman."))
    if c["top"] and c["biaya"] > 0:
        tips.append(f"Biaya terbesar: {c['top'][0]} ({round(c['top_pct'] * 100)}% dari semua biaya).")
    return dict(tone=tone, head=head, sub=sub, tips=tips)


def biz_split(c):
    """Untuk bar 'Rp 100 dipakai untuk apa': (dasar, [(nama, nilai, warna_kunci)]). Kunci warna: pokok/tetap/pajak/untung."""
    spend = c["biaya"] + c["pajak"]
    base = max(c["omzet"], spend, 1)
    segs = [("Modal pokok", c["pokok"], "pokok"), ("Biaya tetap", c["ops"], "tetap"), ("Pajak", c["pajak"], "pajak")]
    if c["bersih"] > 0:
        segs.append(("Untung bersih", c["bersih"], "untung"))
    return base, [s for s in segs if s[1] > 0]


def biz_flows(c, good, bad):
    """Data diagram alur uang. left = sumber uang; groups = (nama, jumlah, warna, [(item, jumlah)])."""
    left = [(n, v, COL_IN) for n, v in c["inc"] if v > 0]
    if c["deficit"] > 0:
        left.append(("Kurang (rugi)", c["deficit"], bad))
    groups = []
    for name, col, items in (("Modal pokok", COL_POKOK, c["pokok_items"]), ("Biaya tetap", COL_TETAP, c["tetap_items"])):
        its = [(n, v) for n, v in items if v > 0]
        if its:
            groups.append((name, sum(v for _, v in its), col, its))
    if c["pajak"] > 0:
        groups.append(("Pajak", c["pajak"], GREY, [("Pajak", c["pajak"])]))
    if c["bersih"] > 0:
        groups.append(("Untung bersih", c["bersih"], good, [("Untung bersih", c["bersih"])]))
    return left, groups


def ribbon(x0, a0, a1, x1, b0, b1, steps=22):
    top, bot = [], []
    for i in range(steps + 1):
        t = i / steps
        s = t * t * (3 - 2 * t)
        x = x0 + (x1 - x0) * t
        top += [x, a0 + (b0 - a0) * s]
        bot = [x, a1 + (b1 - a1) * s] + bot
    return top + bot


def sankey4(left, groups, W, H, pl, pr, nw, g_in, g_grp, pad_y, minh=3):
    """Posisi node & pita Sankey 4 kolom: sumber -> uang masuk -> kelompok -> rincian (murni matematika)."""
    T = sum(v for _, v, _ in left)
    if T <= 0 or not groups or W < 100 or H < 60:
        return None
    ng = len(groups)
    gap_items = sum(max(0, len(g[3]) - 1) for g in groups) * g_in + max(0, ng - 1) * g_grp
    gap_left = max(0, len(left) - 1) * g_in
    avail = max(20.0, H - 2 * pad_y)
    gap = max(gap_items, gap_left)
    if gap > avail * .45:
        k = avail * .45 / gap
        g_in, g_grp, gap_items, gap_left, gap = g_in * k, g_grp * k, gap_items * k, gap_left * k, gap * k
    scale = (avail - gap) / T
    cy = H / 2
    xl0, xl1 = pl, pl + nw
    xr0, xr1 = W - pr - nw, W - pr
    span = xr0 - xl1
    xm0 = xl1 + span * .20
    xg0 = xl1 + span * .60
    nodes, links = [], []
    # kolom kanan (rincian) + kolom tengah-kanan (kelompok)
    slots = [[max(v * scale, minh) for _, v in g[3]] for g in groups]
    colh = sum(sum(s) for s in slots) + gap_items
    y = cy - colh / 2
    gpos, ipos = [], []
    for g, sl in zip(groups, slots):
        ys, pos = y, []
        for sh in sl:
            pos.append((y, sh))
            y += sh + g_in
        y -= g_in
        gpos.append((ys, y))
        ipos.append(pos)
        y += g_grp
    # kolom kiri
    lslots = [max(v * scale, minh) for _, v, _ in left]
    ly = cy - (sum(lslots) + gap_left) / 2
    T_h = T * scale
    my = cy - T_h / 2
    off = my
    for (name, v, col), sh in zip(left, lslots):
        th, yc = v * scale, ly + sh / 2
        nodes.append(dict(side="L", name=name, v=v, color=col, x0=xl0, x1=xl1, y0=ly, y1=ly + sh))
        links.append(dict(pts=ribbon(xl1, yc - th / 2, yc + th / 2, xm0, off, off + th), color=col, name=name, v=v, alt=0))
        off += th
        ly += sh + g_in
    off = my
    for gi, (g, (ys, ye)) in enumerate(zip(groups, gpos)):
        gname, gv, gcol, items = g
        gh = max(gv * scale, minh)
        gy0 = (ys + ye) / 2 - gh / 2
        links.append(dict(pts=ribbon(xm0 + nw, off, off + gv * scale, xg0, gy0, gy0 + gh), color=gcol, name=gname,
                          v=gv, alt=0))
        off += gv * scale
        nodes.append(dict(side="G", name=gname, v=gv, color=gcol, x0=xg0, x1=xg0 + nw, y0=gy0, y1=gy0 + gh))
        goff = gy0 + (gh - gv * scale) / 2
        for j, ((iname, iv), (iy, ish)) in enumerate(zip(items, ipos[gi])):
            th, yc = iv * scale, iy + ish / 2
            links.append(dict(pts=ribbon(xg0 + nw, goff, goff + th, xr0, yc - th / 2, yc + th / 2), color=gcol,
                              name=iname, v=iv, alt=j % 2))
            nodes.append(dict(side="R", name=iname, v=iv, color=gcol, x0=xr0, x1=xr1, y0=iy, y1=iy + ish))
            goff += th
    nodes.append(dict(side="M", name="Uang masuk", v=T, color=None, x0=xm0, x1=xm0 + nw, y0=my, y1=my + T_h))
    return dict(nodes=nodes, links=links, total=T, scale=scale)


# ------------------------------------------------------------------- database
class DB:
    def __init__(self, path):
        self.path = path
        self.open()

    def open(self):
        self.c = sqlite3.connect(self.path)
        self.c.row_factory = sqlite3.Row
        self.c.executescript(SCHEMA)
        if not self.c.execute("SELECT 1 FROM accounts LIMIT 1").fetchone():
            for n, k, col in (("Bank Utama", "Bank", "#3b82f6"), ("Tabungan", "Tabungan", "#10b981"),
                              ("Dompet Tunai", "Tunai", "#f59e0b")):
                self.c.execute("INSERT INTO accounts(name,kind,init,color) VALUES(?,?,0,?)", (n, k, col))
            self.c.commit()

    def close(self):
        try:
            self.c.close()
        except Exception:
            pass

    # rekening
    def balances(self):
        return self.c.execute("""
            SELECT a.id, a.name, a.kind, a.color, a.init,
              a.init
              + COALESCE((SELECT SUM(amount) FROM tx WHERE acc=a.id AND kind='in'),0)
              - COALESCE((SELECT SUM(amount) FROM tx WHERE acc=a.id AND kind IN ('out','tf')),0)
              + COALESCE((SELECT SUM(amount) FROM tx WHERE acc2=a.id AND kind='tf'),0) AS bal
            FROM accounts a ORDER BY a.id""").fetchall()

    def save_account(self, aid, name, kind, init, color):
        if aid:
            self.c.execute("UPDATE accounts SET name=?,kind=?,init=?,color=? WHERE id=?",
                           (name, kind, init, color, aid))
        else:
            self.c.execute("INSERT INTO accounts(name,kind,init,color) VALUES(?,?,?,?)",
                           (name, kind, init, color))
        self.c.commit()

    def tx_count(self, aid):
        return self.c.execute("SELECT COUNT(*) FROM tx WHERE acc=? OR acc2=?", (aid, aid)).fetchone()[0]

    def delete_account(self, aid):
        self.c.execute("DELETE FROM tx WHERE acc=? OR acc2=?", (aid, aid))
        self.c.execute("DELETE FROM accounts WHERE id=?", (aid,))
        self.c.commit()

    def merge_account(self, src, dst, drop_src):
        """Pindahkan seluruh riwayat + saldo awal rekening src ke dst (saldo total tetap sama)."""
        c = self.c
        c.execute("UPDATE tx SET acc=? WHERE acc=?", (dst, src))
        c.execute("UPDATE tx SET acc2=? WHERE acc2=?", (dst, src))
        c.execute("DELETE FROM tx WHERE kind='tf' AND acc=acc2")
        init = c.execute("SELECT init FROM accounts WHERE id=?", (src,)).fetchone()[0]
        c.execute("UPDATE accounts SET init=init+? WHERE id=?", (init, dst))
        c.execute("UPDATE accounts SET init=0 WHERE id=?", (src,))
        if drop_src:
            c.execute("DELETE FROM accounts WHERE id=?", (src,))
        c.commit()

    def import_rows(self, acc, rows):
        """Masukkan baris mutasi ke rekening acc. Baris yang sudah ada dilewati (aman diimpor ulang)."""
        have = {}
        for r in self.c.execute("SELECT day, kind, amount, COALESCE(note,'') n FROM tx WHERE acc=?", (acc,)):
            k = (r[0], r[1], r[2], r[3])
            have[k] = have.get(k, 0) + 1
        added = dup = 0
        for r in rows:
            k = (r["day"], r["kind"], r["amount"], r["note"])
            if have.get(k, 0) > 0:
                have[k] -= 1
                dup += 1
                continue
            self.c.execute("INSERT INTO tx(day,kind,amount,acc,acc2,cat,note) VALUES(?,?,?,?,NULL,?,?)",
                           (r["day"], r["kind"], r["amount"], acc, r["cat"], r["note"]))
            added += 1
        self.c.commit()
        return added, dup

    # bisnis
    def biz_list(self):
        return self.c.execute("SELECT id, name FROM biz ORDER BY id").fetchall()

    def biz_get(self, bid):
        return self.c.execute("SELECT * FROM biz WHERE id=?", (bid,)).fetchone()

    def biz_save(self, bid, name, data):
        js = json.dumps(data, ensure_ascii=False)
        if bid:
            self.c.execute("UPDATE biz SET name=?, data=? WHERE id=?", (name, js, bid))
        else:
            bid = self.c.execute("INSERT INTO biz(name, data) VALUES(?,?)", (name, js)).lastrowid
        self.c.commit()
        return bid

    def biz_delete(self, bid):
        self.c.execute("DELETE FROM biz WHERE id=?", (bid,))
        self.c.commit()

    # transaksi
    def add_tx(self, day, kind, amount, acc, acc2, cat, note, tid=None):
        if tid:
            self.c.execute("UPDATE tx SET day=?,kind=?,amount=?,acc=?,acc2=?,cat=?,note=? WHERE id=?",
                           (day, kind, amount, acc, acc2, cat, note, tid))
        else:
            self.c.execute("INSERT INTO tx(day,kind,amount,acc,acc2,cat,note) VALUES(?,?,?,?,?,?,?)",
                           (day, kind, amount, acc, acc2, cat, note))
        self.c.commit()

    def delete_tx(self, tid):
        self.c.execute("DELETE FROM tx WHERE id=?", (tid,))
        self.c.commit()

    def get_tx(self, tid):
        return self.c.execute("SELECT * FROM tx WHERE id=?", (tid,)).fetchone()

    _JOIN = ("SELECT t.*, a.name AS an, b.name AS bn FROM tx t "
             "JOIN accounts a ON a.id=t.acc LEFT JOIN accounts b ON b.id=t.acc2 ")

    def month_tx(self, ym):
        return self.c.execute(self._JOIN + "WHERE substr(t.day,1,7)=? ORDER BY t.day DESC, t.id DESC",
                              (ym,)).fetchall()

    def recent(self, n):
        return self.c.execute(self._JOIN + "ORDER BY t.day DESC, t.id DESC LIMIT ?", (n,)).fetchall()

    def all_tx(self):
        return self.c.execute(self._JOIN + "ORDER BY t.day, t.id").fetchall()

    def month_totals(self, ym):
        d = {r[0]: r[1] for r in self.c.execute(
            "SELECT kind, SUM(amount) FROM tx WHERE substr(day,1,7)=? AND kind IN ('in','out') GROUP BY kind",
            (ym,))}
        return d.get("in", 0), d.get("out", 0)

    def year_series(self, year):
        inc, exp = [0] * 12, [0] * 12
        for m, k, s in self.c.execute(
                "SELECT substr(day,6,2), kind, SUM(amount) FROM tx "
                "WHERE substr(day,1,4)=? AND kind IN ('in','out') GROUP BY 1,2", (f"{year:04d}",)):
            (inc if k == "in" else exp)[int(m) - 1] = s
        return inc, exp

    def cat_sums(self, ym):
        return [(r[0], r[1]) for r in self.c.execute(
            "SELECT COALESCE(NULLIF(cat,''),'Lainnya') c, SUM(amount) s FROM tx "
            "WHERE substr(day,1,7)=? AND kind='out' GROUP BY c ORDER BY s DESC", (ym,))]

    def categories(self, kind):
        seen = list(DEF_CAT[kind])
        for r in self.c.execute("SELECT DISTINCT cat FROM tx WHERE kind=? AND cat<>''", (kind,)):
            if r[0] not in seen:
                seen.append(r[0])
        return seen



# --------------------------------------------------------------------- widget
class Btn(tk.Label):
    """Tombol datar ringan dengan efek hover."""

    def __init__(self, master, text, cmd, bg, fg, hover, font, padx=16, pady=8, **kw):
        super().__init__(master, text=text, bg=bg, fg=fg, font=font, padx=padx, pady=pady,
                         cursor="hand2", **kw)
        self._bg, self._hv, self._cmd = bg, hover, cmd
        self._k, self._to, self._job = 0.0, 0.0, None
        self.bind("<Enter>", lambda e: self._fade(1.0))
        self.bind("<Leave>", lambda e: self._fade(0.0))
        self.bind("<Button-1>", lambda e: self._cmd())

    def _fade(self, to):
        """Warna berubah halus (3-4 langkah ~16 ms) saat kursor masuk/keluar."""
        self._to = to
        if self._job is None:
            self._tick()

    def _tick(self):
        self._job = None
        try:
            if not self.winfo_exists():
                return
            d = self._to - self._k
            self._k = self._to if abs(d) < .3 else self._k + (.34 if d > 0 else -.34)
            self.config(bg=mix(self._bg, self._hv, max(0.0, min(1.0, self._k))))
            if self._k != self._to:
                self._job = self.after(16, self._tick)
        except tk.TclError:
            pass


def rrect(c, x0, y0, x1, y1, r, **kw):
    """Persegi panjang bersudut membulat di canvas."""
    r = max(0, min(r, (x1 - x0) / 2, (y1 - y0) / 2))
    pts = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1, x1 - r, y1,
           x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
    return c.create_polygon(pts, smooth=True, **kw)


def nav_icon(c, key, cx, cy, s, col, bg, tags="ui"):
    """Ikon menu digambar sebagai bentuk vektor (tidak bergantung pada font yang terpasang)."""
    h, w = s / 2, max(2, round(s * .11))
    if key == "dashboard":
        g = s * .14
        q = (s - g) / 2
        for dx, dy in ((0, 0), (q + g, 0), (0, q + g), (q + g, q + g)):
            c.create_rectangle(cx - h + dx, cy - h + dy, cx - h + dx + q, cy - h + dy + q, fill=col, outline="",
                               tags=tags)
    elif key == "transaksi":
        sh = (s * .30, s * .36, s * .15)
        c.create_line(cx - h, cy - s * .2, cx + h, cy - s * .2, width=w, fill=col, arrow="last", arrowshape=sh,
                      tags=tags)
        c.create_line(cx + h, cy + s * .2, cx - h, cy + s * .2, width=w, fill=col, arrow="last", arrowshape=sh,
                      tags=tags)
    elif key == "rekening":
        rrect(c, cx - h, cy - s * .36, cx + h, cy + s * .36, s * .16, fill="", outline=col, width=w, tags=tags)
        c.create_line(cx - h, cy - s * .1, cx + h, cy - s * .1, width=w, fill=col, tags=tags)
        c.create_rectangle(cx - h + s * .16, cy + s * .12, cx - h + s * .42, cy + s * .22, fill=col, outline="",
                           tags=tags)
    elif key == "bisnis":                                            # tas kerja
        rrect(c, cx - h, cy - s * .24, cx + h, cy + s * .38, s * .14, fill="", outline=col, width=w, tags=tags)
        c.create_line(cx - s * .2, cy - s * .24, cx - s * .2, cy - s * .38, cx + s * .2, cy - s * .38,
                      cx + s * .2, cy - s * .24, width=w, fill=col, tags=tags)
        c.create_line(cx - h, cy + s * .05, cx + h, cy + s * .05, width=w, fill=col, tags=tags)
    else:                                                            # pengaturan: tiga penggeser
        for yy, kx in ((-.3, .18), (0, -.22), (.3, .24)):
            c.create_line(cx - h, cy + s * yy, cx + h, cy + s * yy, width=w, fill=col, tags=tags)
            r = s * .15
            c.create_oval(cx + s * kx - r, cy + s * yy - r, cx + s * kx + r, cy + s * yy + r, fill=col, outline=bg,
                          width=max(1, w // 2), tags=tags)


def chevron(c, cx, cy, s, left, col, tags="ui"):
    """Tanda « / » (dua sudut) dari garis."""
    w = max(2, round(s * .12))
    d = -1 if left else 1
    for off in (-s * .22, s * .22):
        x = cx + off
        c.create_line(x - d * s * .16, cy - s * .3, x + d * s * .16, cy, x - d * s * .16, cy + s * .3,
                      width=w, fill=col, joinstyle="round", capstyle="round", tags=tags)


def eye_icon(c, cx, cy, s, hidden, col, tags="ui"):
    """Ikon mata (tampil) / mata dicoret (tersembunyi), digambar dengan kanvas."""
    w, h = s * .62, s * .36
    c.create_oval(cx - w, cy - h, cx + w, cy + h, outline=col, width=max(1.5, s / 11), tags=tags)
    r = h * .55
    c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=col, outline="", tags=tags)
    if hidden:
        c.create_line(cx - w, cy + h * 1.25, cx + w, cy - h * 1.25, fill=col, width=max(2, s / 9), tags=tags)


class Fit(tk.Label):
    """Label yang menyusutkan huruf (lalu memotong dengan …) supaya selalu muat, tanpa memaksa kolom melebar."""

    def __init__(self, master, app, text, fonts, fg, bg, **kw):
        super().__init__(master, text="", font=app.f[fonts[0]], fg=fg, bg=bg, anchor="w", width=1, padx=0, **kw)
        self.app, self.full, self.fonts = app, text, fonts
        self.bind("<Configure>", lambda e: self.fit(e.width))

    def fit(self, w):
        f = self.app.f
        w -= 2
        if w < 12:
            return
        for k in self.fonts:
            if f[k].measure(self.full) <= w:
                self.config(font=f[k], text=self.full)
                return
        k, txt = self.fonts[-1], self.full
        while len(txt) > 1 and f[k].measure(txt + "…") > w:
            txt = txt[:-1]
        self.config(font=f[k], text=txt + "…")


class Tip:
    """Tooltip kecil (dipakai saat sidebar diciutkan)."""

    def __init__(self, app):
        self.app, self.w = app, None

    def show(self, text, x, y):
        self.hide()
        a, t = self.app, self.app.t
        w = tk.Toplevel(a)
        w.wm_overrideredirect(True)
        try:
            w.attributes("-topmost", True)
        except tk.TclError:
            pass
        tk.Label(w, text=text, font=a.f["s"], bg=t["card2"], fg=t["text"], padx=a.px(10), pady=a.px(5),
                 highlightthickness=1, highlightbackground=t["line"]).pack()
        w.geometry(f"+{x}+{y}")
        self.w = w

    def hide(self):
        if self.w is not None:
            try:
                self.w.destroy()
            except tk.TclError:
                pass
            self.w = None


class Bg(tk.Canvas):
    """Pengganti Frame untuk latar halaman: bisa menampilkan potongan wallpaper di belakang isinya.
    Tanpa wallpaper ia hanya kotak berwarna biasa (sama ringannya dengan Frame)."""

    def __init__(self, master, app, tint=None, alpha=0.0, bg=None, wp=True, part="body", **kw):
        super().__init__(master, bg=bg or app.t["bg"], highlightthickness=0, bd=0, **kw)
        self.app, self.tint, self.alpha, self._ph, self._wp = app, tint, alpha, None, wp
        self._part = part
        app.bgs.add(self)
        if wp:
            self.bind("<Configure>", lambda e: app.wp_dirty(), add="+")

    def paint(self):
        if not self._wp or not self.winfo_exists():
            return
        self.delete("wp")
        self._ph = None
        a = self.app
        if not a.wp_on() or not a.cfg["wp"].get(self._part, True):
            return
        w, h = self.winfo_width(), self.winfo_height()
        if w < 4 or h < 4:
            return
        x, y = self.winfo_rootx() - a.winfo_rootx(), self.winfo_rooty() - a.winfo_rooty()
        r = a.wp_slice(x, y, w, h, self.tint, self.alpha)
        if r is None:
            return
        img, dx, dy = r
        self._ph = img
        self.create_image(dx, dy, anchor="nw", image=img, tags="wp")
        a.wp_overlay(self, w, h, self.tint)
        self.tag_lower("wp")


class Header(Bg):
    """Judul halaman + tombol di kanan, digambar di atas wallpaper (tanpa kotak latar)."""

    def __init__(self, master, app, title, sub):
        super().__init__(master, app, width=10, height=10)
        t, f = app.t, app.f
        self.items = []
        self.t1 = self.create_text(0, 0, anchor="nw", text=title, font=f["h1"], fill=t["text"])
        self.t2 = self.create_text(0, 0, anchor="nw", text=sub, font=f["n"], fill=t["muted"])
        app.headers.append(self)
        self.bind("<Configure>", lambda e: self.lay(), add="+")
        self.refit()

    def refit(self):
        a = self.app
        h1, h2 = a.f["h1"].metrics("linespace"), a.f["n"].metrics("linespace")
        self.coords(self.t2, 0, h1 + a.px(2))
        self.config(height=h1 + h2 + a.px(6))
        self.lay()

    def add(self, widget, gap=8):
        it = self.create_window(0, 0, window=widget, anchor="e")
        self.items.append((it, widget, gap))
        self.lay()

    def lay(self):
        W, H = self.winfo_width(), float(self.cget("height"))
        x = W
        for it, wd, gap in self.items:
            wd.update_idletasks()
            self.coords(it, x, H / 2)
            x -= wd.winfo_reqwidth() + self.app.px(gap)


class Side(Bg):
    """Sidebar (tab Dashboard / Transaksi / Rekening / Pengaturan). Bisa diciutkan jadi ikon saja."""

    def __init__(self, master, app):
        super().__init__(master, app, tint=app.t["side"], alpha=.74, bg=app.t["side"], part="side",
                         width=app.side_w(app.side_coll), height=10)
        self.rows, self.hover = [], None
        self.tip = Tip(app)
        self.bind("<Configure>", lambda e: self.redraw(), add="+")
        self.bind("<Motion>", self.on_move)
        self.bind("<Leave>", self.on_leave)
        self.bind("<Button-1>", self.on_click)

    def is_coll(self):
        a = self.app
        return self.winfo_width() < (a.side_w(False) + a.side_w(True)) / 2

    def redraw(self):
        if not self.winfo_exists():
            return
        self.delete("ui")
        a = self.app
        t, f, px = a.t, a.f, a.px
        W, H = self.winfo_width(), self.winfo_height()
        if W < 10 or H < 10:
            return
        coll = self.is_coll()
        y = px(22)
        lh = f["h2"].metrics("linespace")
        r = lh * .36
        lx = W / 2 if coll else px(22) + r
        self.create_polygon(lx, y + lh / 2 - r, lx + r, y + lh / 2, lx, y + lh / 2 + r, lx - r, y + lh / 2,
                            fill=t["accent"], outline="", tags="ui")
        if not coll:
            self.create_text(lx + r + px(10), y + lh / 2, text="nabunglandx", font=f["h2"],
                             fill=t["text"], anchor="w", tags="ui")
        y += lh + px(24)
        rh = f["n"].metrics("linespace") + px(22)
        ix = W / 2 if coll else px(34)
        self.rows = []
        for key, icon, label in a.NAV:
            on, hv = key == a.page, key == self.hover
            if on or hv:
                rrect(self, px(10), y, W - px(10), y + rh, px(10), outline="", tags="ui",
                      fill=t["card2"] if on else mix(t["side"], t["card2"], .55))
            if on:
                self.create_rectangle(px(10), y + px(10), px(13), y + rh - px(10), fill=t["accent"], outline="",
                                      tags="ui")
            col = t["text"] if on else t["muted"]
            nav_icon(self, key, ix, y + rh / 2, f["n"].metrics("linespace") * .95,
                     t["accent"] if on else col, t["card2"] if on else t["side"])
            if not coll:
                self.create_text(px(62), y + rh / 2, text=label, anchor="w", font=f["b"] if on else f["n"],
                                 fill=col, tags="ui")
            self.rows.append((y, y + rh, key))
            y += rh + px(3)
        # bawah: total saldo + tombol ciutkan
        tog1 = H - px(16)
        tog0 = tog1 - rh
        if self.hover == "toggle":
            rrect(self, px(10), tog0, W - px(10), tog1, px(10), fill=mix(t["side"], t["card2"], .55), outline="",
                  tags="ui")
        chevron(self, ix, tog0 + rh / 2, f["n"].metrics("linespace") * .8, not coll, t["muted"])
        if not coll:
            self.create_text(px(62), tog0 + rh / 2, text="Ciutkan menu", anchor="w", font=f["n"], fill=t["muted"],
                             tags="ui")
        self.rows.append((tog0, tog1, "toggle"))
        hid = a.hide
        es = f["s"].metrics("linespace") * 1.5
        if coll:
            ey = tog0 - px(44)
            self.create_text(W / 2, tog0 - px(14), text="••" if hid else short(a.total), font=f["s"],
                             fill=t["muted"], tags="ui")
            eye_icon(self, W / 2, ey, es, hid, t["accent"] if self.hover == "eye" else t["muted"])
            self.rows.append((ey - es, ey + es, "eye"))
        else:
            ey = tog0 - px(44) + f["s"].metrics("linespace") / 2
            self.create_text(px(24), tog0 - px(44), text="TOTAL SALDO", anchor="w", font=f["s"], fill=t["muted"],
                             tags="ui")
            self.create_text(px(24), tog0 - px(22), text=a.bal(a.total), anchor="w", font=f["m"],
                             fill=t["text"], tags="ui")
            eye_icon(self, W - px(26), ey, es, hid, t["accent"] if self.hover == "eye" else t["muted"])
            self.rows.append((ey - es, ey + es, "eye"))

    def _row(self, y):
        for y0, y1, k in self.rows:
            if y0 <= y < y1:
                return k
        return None

    def on_move(self, e):
        k = self._row(e.y)
        if k == self.hover:
            return
        self.hover = k
        self.redraw()
        self.config(cursor="hand2" if k else "")
        self.tip.hide()
        if k and self.is_coll():
            names = {n[0]: n[2] for n in self.app.NAV}
            names["eye"] = "Tampilkan saldo" if self.app.hide else "Sembunyikan saldo"
            y0 = [r[0] for r in self.rows if r[2] == k][0]
            self.tip.show(names.get(k, "Bentangkan menu"), self.winfo_rootx() + self.winfo_width() + 4,
                          self.winfo_rooty() + int(y0) + self.app.px(6))

    def on_leave(self, e):
        self.hover = None
        self.tip.hide()
        self.redraw()

    def on_click(self, e):
        k = self._row(e.y)
        self.tip.hide()
        if k == "toggle":
            self.app.toggle_side()
        elif k == "eye":
            self.app.toggle_hide()
        elif k:
            self.app.show(k)


class Switch(tk.Canvas):
    """Saklar on/off."""

    def __init__(self, master, app, value, cmd):
        t = app.t
        w, h = app.px(42), app.px(22)
        super().__init__(master, width=w, height=h, bg=master.cget("bg"), highlightthickness=0, cursor="hand2")
        self.app, self.val, self.cmd, self.w, self.h = app, bool(value), cmd, w, h
        self.bind("<Button-1>", self.flip)
        self.draw()

    def draw(self):
        t = self.app.t
        self.delete("all")
        rrect(self, 1, 1, self.w - 1, self.h - 1, self.h / 2, fill=t["accent"] if self.val else t["line"], outline="")
        r = self.h / 2 - 3
        cx = self.w - self.h / 2 if self.val else self.h / 2
        self.create_oval(cx - r, self.h / 2 - r, cx + r, self.h / 2 + r, fill="#ffffff", outline="")

    def flip(self, e=None):
        self.val = not self.val
        self.draw()
        self.cmd(self.val)


class Page(tk.Frame):
    """Halaman yang otomatis bisa di-scroll bila isinya lebih tinggi dari jendela (mis. saat di-zoom)."""

    def __init__(self, master, app):
        super().__init__(master, bg=app.t["bg"])
        self.app = app
        self.cv = Bg(self, app, wp=False)
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.cv.yview)
        self.cv.configure(yscrollcommand=self._yset)
        self.cv.pack(side="left", fill="both", expand=True)
        self.inner = Bg(self.cv, app)
        self.win = self.cv.create_window(0, 0, window=self.inner, anchor="nw")
        self.cv.bind("<Configure>", self._fit, add="+")
        self.inner.bind("<Configure>", self._fit, add="+")
        self._goal = self._sj = None

    def _yset(self, a, b):
        self.sb.set(a, b)

    def _fit(self, e=None):
        cw, ch = self.cv.winfo_width(), self.cv.winfo_height()
        if cw < 5 or ch < 5:
            return
        rh = self.inner.winfo_reqheight()
        h = max(ch, rh)
        self._goal = None
        self.cv.itemconfigure(self.win, width=cw, height=h)
        self.cv.configure(scrollregion=(0, 0, cw, h))
        need = rh > ch + 1
        if need and not self.sb.winfo_ismapped():
            self.sb.pack(side="right", fill="y")
        elif not need and self.sb.winfo_ismapped():
            self.sb.pack_forget()
            self.cv.yview_moveto(0)

    def scroll(self, n):
        """Scroll dengan easing (meluncur), bukan lompat per baris."""
        if not self.sb.winfo_ismapped():
            return
        a, b = self.cv.yview()
        span = b - a
        base = self._goal if self._goal is not None else a
        self._goal = max(0.0, min(1.0 - span, base + n * 0.1 * span))
        if self._sj is None:
            self._glide()

    def _glide(self):
        self._sj = None
        try:
            if not self.winfo_exists() or self._goal is None:
                return
            a = self.cv.yview()[0]
            d = self._goal - a
            if abs(d) < .0008:
                self.cv.yview_moveto(self._goal)
                self._goal = None
                self.app.wp_dirty(40)
                return
            self.cv.yview_moveto(a + d * .35)
            self.app.wp_dirty(90)
            self._sj = self.after(16, self._glide)
        except tk.TclError:
            self._goal = None


# ------------------------------------------------------------------- diagram
class BarChart(tk.Canvas):
    """Diagram batang pemasukan vs pengeluaran per bulan dalam satu tahun."""

    def __init__(self, master, app, on_pick=None):
        super().__init__(master, bg=app.t["card"], highlightthickness=0, height=app.px(190))
        self.app, self.on_pick = app, on_pick
        self.inc, self.exp, self.sel, self.year, self.cols = [0] * 12, [0] * 12, 0, 2000, []
        app.charts.append(self)
        self._rj = None
        self.bind("<Configure>", lambda e: self.soon())
        self.bind("<Motion>", self.on_move)
        self.bind("<Leave>", lambda e: self.delete("tip"))
        self.bind("<Button-1>", self.on_click)

    def soon(self):
        if self._rj is None:
            self._rj = self.after(24, self._do)

    def _do(self):
        self._rj = None
        self.redraw()

    def set_data(self, inc, exp, sel, year):
        if not self.winfo_exists():
            return
        self.inc, self.exp, self.sel, self.year = inc, exp, sel, year
        self.redraw()

    def redraw(self):
        if not self.winfo_exists():
            return
        a = self.app
        t, f = a.t, a.f
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 80 or h < 80:
            return
        L = f["s"].measure("88,8jt") + a.px(14)
        R, T, B = a.px(8), a.px(10), f["s"].metrics("linespace") + a.px(14)
        pw, ph = w - L - R, h - T - B
        top = nice_max(max(max(self.inc), max(self.exp), 1))
        for i in range(5):
            y = T + ph - ph * i / 4
            self.create_line(L, y, w - R, y, fill=t["line"])
            self.create_text(L - a.px(8), y, text="•••" if a.hide else short(top * i / 4), anchor="e", fill=t["muted"], font=f["s"])
        gw = pw / 12
        bw = max(3, min(gw * 0.3, a.px(20)))
        self.cols = []
        for m in range(12):
            x0c = L + gw * m
            cx = x0c + gw / 2
            self.cols.append((x0c, x0c + gw))
            if m == self.sel:
                self.create_rectangle(x0c + 2, T, x0c + gw - 2, T + ph, fill=t["card2"], outline="")
            for k, (val, col) in enumerate(((self.inc[m], t["good"]), (self.exp[m], t["bad"]))):
                if val <= 0:
                    continue
                x0 = cx - bw - 1 if k == 0 else cx + 1
                y1 = T + ph
                y0 = y1 - max(2, ph * val / top)
                self.create_rectangle(x0, y0, x0 + bw, y1, fill=col, outline="")
            self.create_text(cx, h - B / 2 + a.px(2), text=MON3[m], font=f["s"],
                             fill=t["text"] if m == self.sel else t["muted"])

    def _col(self, x):
        for i, (a, b) in enumerate(self.cols):
            if a <= x < b:
                return i
        return None

    def on_move(self, e):
        self.delete("tip")
        i = self._col(e.x)
        if i is None:
            return
        a = self.app
        t, f = a.t, a.f
        txt = f"{MONTHS[i]} {self.year}\nMasuk   {a.amt(self.inc[i])}\nKeluar  {a.amt(self.exp[i])}"
        tid = self.create_text(0, 0, text=txt, anchor="nw", fill=t["text"], font=f["s"], tags="tip")
        x0, y0, x1, y1 = self.bbox(tid)
        bw_, bh_ = x1 - x0 + 16, y1 - y0 + 12
        x = min(max(e.x + 14, 4), max(4, self.winfo_width() - bw_ - 4))
        y = min(max(e.y - bh_ - 6, 4), max(4, self.winfo_height() - bh_ - 4))
        self.coords(tid, x + 8, y + 6)
        r = self.create_rectangle(x, y, x + bw_, y + bh_, fill=t["card2"], outline=t["line"], tags="tip")
        self.tag_lower(r, tid)

    def on_click(self, e):
        i = self._col(e.x)
        if i is not None and self.on_pick:
            self.on_pick(i + 1)


class Donut(tk.Canvas):
    """Diagram donat pengeluaran per kategori + legenda."""

    def __init__(self, master, app):
        super().__init__(master, bg=app.t["card"], highlightthickness=0, height=app.px(190))
        self.app, self.data = app, []
        app.charts.append(self)
        self._rj = None
        self.bind("<Configure>", lambda e: self.soon())

    def soon(self):
        if self._rj is None:
            self._rj = self.after(24, self._do)

    def _do(self):
        self._rj = None
        self.redraw()

    def set_data(self, data):
        if not self.winfo_exists():
            return
        self.data = data
        self.redraw()

    def redraw(self):
        if not self.winfo_exists():
            return
        a = self.app
        t, f = a.t, a.f
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 80 or h < 80:
            return
        total = sum(v for _, v in self.data)
        if total <= 0:
            self.create_text(w / 2, h / 2, text="Belum ada pengeluaran\nbulan ini", fill=t["muted"],
                             font=f["n"], justify="center")
            return
        items = list(self.data)
        if len(items) > 6:
            rest = sum(v for _, v in items[5:])
            items = items[:5] + [("Lainnya", rest)]
        cols = [PALETTE[i % len(PALETTE)] for i in range(len(items))]
        wide = w >= a.px(380)
        size = min(h - 16, w - 16 if not wide else w * 0.46)
        ring = max(10, size * 0.17)
        x0, y0 = 8 + ring / 2, (h - size) / 2 + ring / 2
        bbox = (x0, y0, x0 + size - ring, y0 + size - ring)
        ang = 90
        for (name, val), col in zip(items, cols):
            ext = -359.99 if len(items) == 1 else -360 * val / total
            self.create_arc(*bbox, start=ang, extent=ext, style="arc", outline=col, width=ring)
            ang += ext
        cx, cy = x0 + (size - ring) / 2, y0 + (size - ring) / 2
        self.create_text(cx, cy - f["h2"].metrics("linespace") * .3, text="••••" if a.hide else short(total), fill=t["text"], font=f["h2"])
        self.create_text(cx, cy + f["s"].metrics("linespace") * .9, text="total keluar", fill=t["muted"], font=f["s"])
        if wide:
            lx = size + 28
            rh = max(a.px(28), f["n"].metrics("linespace") + a.px(8))
            y = max(8, (h - rh * len(items)) / 2)
            for (name, val), col in zip(items, cols):
                self.create_oval(lx, y + rh / 2 - 5, lx + 10, y + rh / 2 + 5, fill=col, outline="")
                nm = name if len(name) <= 16 else name[:15] + "…"
                self.create_text(lx + 18, y + rh / 2, text=nm, anchor="w", fill=t["text"], font=f["n"])
                self.create_text(w - 10, y + rh / 2, text=f"{val * 100 / total:.0f}%" if a.hide else f"{val * 100 / total:.0f}%  ·  {short(val)}", anchor="e",
                                 fill=t["muted"], font=f["s"])
                y += rh


class _Soon(tk.Canvas):
    """Kanvas yang menggambar ulang digabung (tidak berulang-ulang saat jendela ditarik)."""

    def __init__(self, master, app, height):
        super().__init__(master, bg=app.t["card"], highlightthickness=0, height=height)
        self.app, self.calc, self.unit, self._rj = app, None, "unit", None
        app.charts.append(self)
        self.bind("<Configure>", lambda e: self.soon())

    def soon(self):
        if self._rj is None:
            self._rj = self.after(16, self._do)

    def _do(self):
        self._rj = None
        self.redraw()

    def set_calc(self, c, unit="unit"):
        self.calc, self.unit = c, unit
        self.soon()

    @staticmethod
    def ell(font, s, maxw):
        if maxw < 24:
            return ""
        if font.measure(s) <= maxw:
            return s
        while len(s) > 1 and font.measure(s + "…") > maxw:
            s = s[:-1]
        return s + "…"

    def redraw(self):
        pass


def pct_text(v, base):
    p = v * 100 / base if base else 0
    return "<1%" if 0 < p < 1 else f"{round(p)}%"


class Sankey(_Soon):
    """Diagram alur uang 4 kolom: sumber -> uang masuk -> kelompok (modal pokok / biaya tetap / pajak / untung) -> rincian."""

    def __init__(self, master, app, height):
        super().__init__(master, app, height)
        self.tips = {}
        self.bind("<Motion>", self.on_move)
        self.bind("<Leave>", lambda e: self.delete("tip"))

    def tip_text(self, name, v, total):
        return f"{name}\n{self.app.bal(v)}  ·  {pct_text(v, total)} dari total"

    def redraw(self):
        if not self.winfo_exists():
            return
        a = self.app
        t, f = a.t, a.f
        self.delete("all")
        self.tips = {}
        W, H = self.winfo_width(), self.winfo_height()
        c = self.calc
        if W < 160 or H < 100 or not c:
            return
        left, groups = biz_flows(c, t["good"], t["bad"])
        if not left or not groups:
            self.create_text(W / 2, H / 2, text="Isi harga jual dan biaya untuk melihat alur uangnya",
                             fill=t["muted"], font=f["n"])
            return
        lh, sl = f["n"].metrics("linespace"), f["s"].metrics("linespace")
        wide = W >= a.px(720)
        pl, pr = max(a.px(84), W * (.21 if wide else .17)), max(a.px(108), W * (.27 if wide else .36))
        nw = max(8, a.px(12))
        L = sankey4(left, groups, W, H, pl, pr, nw, a.px(9), lh + sl + a.px(14), a.px(12) + lh + sl + a.px(6))
        if not L:
            return
        total = L["total"]
        for lk in L["links"]:
            it = self.create_polygon(lk["pts"], fill=mix(t["card"], lk["color"], .40 + .14 * lk["alt"]), outline="")
            self.tips[it] = self.tip_text(lk["name"], lk["v"], total)
        last = {"L": -1e9, "R": -1e9}
        for nd in L["nodes"]:
            side = nd["side"]
            col = nd["color"] or t["accent"]
            rid = self.create_rectangle(nd["x0"], nd["y0"], nd["x1"], nd["y1"], fill=col, outline="")
            name = nd["name"]
            if side == "M" and c["deficit"] > 0:
                name = "Total pengeluaran"
            self.tips[rid] = self.tip_text(name, nd["v"], total)
            amt = a.bal(nd["v"])
            if side in ("G", "M"):
                single = side == "G" and any(g[0] == nd["name"] and len(g[3]) == 1 and g[3][0][0] == nd["name"]
                                             for g in groups)
                if single:
                    continue                                   # nama sama dengan rincian di kanan: tak perlu dua kali
                cx = (nd["x0"] + nd["x1"]) / 2
                sub = amt if side == "M" else f"{amt} · {pct_text(nd['v'], total)}"
                self.create_text(cx, nd["y0"] - a.px(4), text=self.ell(f["s"], sub, a.px(190)), anchor="s",
                                 font=f["s"], fill=t["muted"])
                self.create_text(cx, nd["y0"] - a.px(4) - sl, text=self.ell(f["b"], name, a.px(190)), anchor="s",
                                 font=f["b"], fill=t["text"])
                continue
            yc = (nd["y0"] + nd["y1"]) / 2
            two = nd["y1"] - nd["y0"] >= lh + sl + a.px(4)
            hg = lh + sl if two else lh
            if yc - hg / 2 < last[side] + a.px(2):
                continue                                         # label bertabrakan: lewati (tooltip tetap ada)
            last[side] = yc + hg / 2
            if side == "L":
                x, anc, maxw = nd["x0"] - a.px(8), "e", nd["x0"] - a.px(12)
                sub = amt
            else:
                x, anc, maxw = nd["x1"] + a.px(8), "w", W - nd["x1"] - a.px(12)
                sub = f"{amt} · {pct_text(nd['v'], total)}"
            if two:
                self.create_text(x, yc - hg / 2 + lh / 2, text=self.ell(f["n"], name, maxw), anchor=anc,
                                 font=f["n"], fill=t["text"])
                self.create_text(x, yc + hg / 2 - sl / 2, text=self.ell(f["s"], sub, maxw), anchor=anc,
                                 font=f["s"], fill=t["muted"])
            else:
                txt = name
                for cand in (f"{name}  {sub}", f"{name}  {amt}"):         # muat yang paling lengkap
                    if f["s"].measure(cand) <= maxw:
                        txt = cand
                        break
                self.create_text(x, yc, text=self.ell(f["s"], txt, maxw), anchor=anc, font=f["s"], fill=t["text"])

    def on_move(self, e):
        self.delete("tip")
        ids = self.find_withtag("current")
        if not ids or ids[0] not in self.tips:
            return
        t, f = self.app.t, self.app.f
        tid = self.create_text(0, 0, text=self.tips[ids[0]], anchor="nw", fill=t["text"], font=f["s"], tags="tip")
        x0, y0, x1, y1 = self.bbox(tid)
        bw_, bh_ = x1 - x0 + 16, y1 - y0 + 12
        x = min(max(e.x + 14, 4), max(4, self.winfo_width() - bw_ - 4))
        y = min(max(e.y - bh_ - 6, 4), max(4, self.winfo_height() - bh_ - 4))
        self.coords(tid, x + 8, y + 6)
        r = self.create_rectangle(x, y, x + bw_, y + bh_, fill=t["card2"], outline=t["line"], tags="tip")
        self.tag_lower(r, tid)


class SplitBar(_Soon):
    """'Uangmu dipakai untuk apa?': bar uang masuk lalu bar pembagiannya (modal pokok / biaya tetap / pajak / untung)."""

    def __init__(self, master, app):
        super().__init__(master, app, app.px(170))

    def redraw(self):
        if not self.winfo_exists():
            return
        a = self.app
        t, f, px = a.t, a.f, a.px
        self.delete("all")
        W = self.winfo_width()
        c = self.calc
        if W < 120 or not c:
            return
        if c["omzet"] <= 0 and c["biaya"] <= 0:
            self.create_text(W / 2, px(40), text="Belum ada angka", fill=t["muted"], font=f["n"])
            return
        base, segs = biz_split(c)
        cols = {"pokok": COL_POKOK, "tetap": COL_TETAP, "pajak": GREY, "untung": t["good"]}
        sl, lh = f["s"].metrics("linespace"), f["n"].metrics("linespace")
        lw = max(f["s"].measure("Uang masuk"), f["s"].measure("Dipakai untuk")) + px(14)
        x0, x1 = lw, W - px(8)
        bw, bh = max(10, x1 - x0), max(px(24), lh + px(8))
        y = px(6)
        self.create_text(px(2), y + bh / 2, text="Uang masuk", anchor="w", font=f["s"], fill=t["muted"])
        w1 = bw * c["omzet"] / base
        if w1 > 0:
            self.create_rectangle(x0, y, x0 + w1, y + bh, fill=COL_IN, outline="")
            txt = a.bal(c["omzet"])
            if f["s"].measure(txt) + px(12) < w1:
                self.create_text(x0 + px(8), y + bh / 2, text=txt, anchor="w", font=f["s"], fill=on_color(COL_IN))
        if c["deficit"] > 0:
            tx = f"kurang {a.bal(c['deficit'])}"
            if x0 + w1 + px(8) + f["s"].measure(tx) < W:
                self.create_text(x0 + w1 + px(8), y + bh / 2, text=tx, anchor="w", font=f["s"], fill=t["bad"])
        y2 = y + bh + px(10)
        self.create_text(px(2), y2 + bh / 2, text="Dipakai untuk", anchor="w", font=f["s"], fill=t["muted"])
        x = x0
        for name, v, key in segs:
            w = bw * v / base
            self.create_rectangle(x, y2, x + w, y2 + bh, fill=cols[key], outline=t["card"], width=1)
            ptxt = pct_text(v, base)
            if f["s"].measure(ptxt) + px(10) < w:
                self.create_text(x + w / 2, y2 + bh / 2, text=ptxt, font=f["s"], fill=on_color(cols[key]))
            x += w
        y3 = y2 + bh + px(14)
        rows = [(cols[k], n, v, pct_text(v, base)) for n, v, k in segs]
        if c["deficit"] > 0:
            rows.append((t["bad"], "Kurang (rugi)", c["deficit"], "—"))
        rh = lh + px(6)
        for col, name, v, ptxt in rows:
            self.create_rectangle(px(4), y3 + rh / 2 - px(5), px(14), y3 + rh / 2 + px(5), fill=col, outline="")
            self.create_text(px(24), y3 + rh / 2, text=name, anchor="w", font=f["n"], fill=t["text"])
            self.create_text(W - px(6), y3 + rh / 2, text=f"{a.bal(v)}   {ptxt}", anchor="e", font=f["n"],
                             fill=t["muted"])
            y3 += rh
        need = int(y3 + px(4))
        if abs(int(float(self.cget("height"))) - need) > 2:
            self.config(height=need)


class Meter(_Soon):
    """Meteran 'titik aman': seberapa jauh jumlah terjual dari batas tidak rugi."""

    def __init__(self, master, app):
        super().__init__(master, app, app.px(84))

    def redraw(self):
        if not self.winfo_exists():
            return
        a = self.app
        t, f, px = a.t, a.f, a.px
        self.delete("all")
        W, H = self.winfo_width(), self.winfo_height()
        c, u = self.calc, self.unit
        if W < 120 or not c:
            return
        if c["omzet"] <= 0 and c["biaya"] <= 0:
            return
        if c["bep"] is None:
            self.create_text(px(4), H / 2, anchor="w", width=W - px(8), fill=t["bad"], font=f["n"],
                             text=f"Tidak ada titik aman: harga jual per {u} lebih kecil dari modalnya, jadi "
                                  "makin banyak terjual makin rugi.")
            return
        q, bep = c["q"], c["bep"]
        if bep <= 0:
            self.create_text(px(4), H / 2, anchor="w", width=W - px(8), fill=t["good"], font=f["n"],
                             text="Tanpa biaya tetap: setiap penjualan langsung menambah untung.")
            return
        mx = max(q, bep) * 1.25
        x0, x1 = px(10), W - px(10)
        th = px(14)
        ty = H / 2 - th / 2 + px(2)
        rrect(self, x0, ty, x1, ty + th, th / 2, fill=t["card2"], outline="")
        qx = x0 + (x1 - x0) * q / mx
        ok = q >= bep
        if qx - x0 > 2:
            rrect(self, x0, ty, max(qx, x0 + th), ty + th, th / 2, fill=t["good"] if ok else t["bad"], outline="")
        bx = x0 + (x1 - x0) * bep / mx
        self.create_line(bx, ty - px(6), bx, ty + th + px(6), fill=t["text"], width=2)
        lab = f"Titik aman: {num(bep)} {u}"
        anc = "e" if bx > W * .7 else "w" if bx < W * .3 else "s"
        self.create_text(bx + (px(6) if anc == "w" else -px(6) if anc == "e" else 0), ty - px(8),
                         text=lab, anchor="se" if anc == "e" else "sw" if anc == "w" else "s", font=f["s"],
                         fill=t["text"])
        lab2 = f"Sekarang: {num(q)} {u}"
        anc2 = "ne" if qx > W * .7 else "nw" if qx < W * .3 else "n"
        self.create_text(qx, ty + th + px(8), text=lab2, anchor=anc2, font=f["s"],
                         fill=t["good"] if ok else t["bad"])


class CalendarPopup(tk.Toplevel):
    """Kalender pilih tanggal."""

    def __init__(self, app, anchor, current, on_pick):
        super().__init__(app)
        self.app, self.cur, self.on_pick = app, current, on_pick
        self.vy, self.vm = current.year, current.month
        t = app.t
        self.title("Pilih tanggal")
        self.configure(bg=t["line"])
        self.resizable(False, False)
        self.transient(app)
        self.inner = tk.Frame(self, bg=t["card"], padx=app.px(14), pady=app.px(12))
        self.inner.pack(padx=1, pady=1)
        self.draw()
        self.geometry(f"+{anchor.winfo_rootx()}+{anchor.winfo_rooty() + anchor.winfo_height() + 6}")
        self.bind("<Escape>", lambda e: self.destroy())
        self.after(80, self._grab)

    def _grab(self):
        try:
            self.grab_set()
            self.focus_set()
        except tk.TclError:
            pass

    def shift(self, dm):
        m = self.vm - 1 + dm
        self.vy += m // 12
        self.vm = m % 12 + 1
        self.draw()

    def pick(self, d):
        self.on_pick(date(self.vy, self.vm, d))
        self.destroy()

    def draw(self):
        app, t, f = self.app, self.app.t, self.app.f
        px = app.px
        for w in self.inner.winfo_children():
            w.destroy()
        bg = t["card"]
        nav = tk.Frame(self.inner, bg=bg)
        nav.pack(fill="x", pady=(0, px(8)))
        for txt, dm in (("«", -12), ("‹", -1)):
            b = tk.Label(nav, text=txt, font=f["m"], fg=t["muted"], bg=bg, cursor="hand2", padx=px(8))
            b.pack(side="left")
            b.bind("<Button-1>", lambda e, d=dm: self.shift(d))
        for txt, dm in (("»", 12), ("›", 1)):
            b = tk.Label(nav, text=txt, font=f["m"], fg=t["muted"], bg=bg, cursor="hand2", padx=px(8))
            b.pack(side="right")
            b.bind("<Button-1>", lambda e, d=dm: self.shift(d))
        tk.Label(nav, text=f"{MONTHS[self.vm - 1]} {self.vy}", font=f["b"], fg=t["text"], bg=bg).pack()
        grid = tk.Frame(self.inner, bg=bg)
        grid.pack()
        for c, d in enumerate(DAY3):
            tk.Label(grid, text=d, font=f["s"], fg=t["bad"] if c == 6 else t["muted"], bg=bg,
                     width=4).grid(row=0, column=c, pady=(0, px(4)))
        today = date.today()
        weeks = calendar.Calendar(0).monthdayscalendar(self.vy, self.vm)
        for r, wk in enumerate(weeks, start=1):
            for c, d in enumerate(wk):
                if d == 0:
                    continue
                cur = (self.vy, self.vm, d) == (self.cur.year, self.cur.month, self.cur.day)
                tdy = (self.vy, self.vm, d) == (today.year, today.month, today.day)
                nbg = t["accent"] if cur else bg
                fg = on_color(t["accent"]) if cur else (t["bad"] if c == 6 else t["text"])
                lb = tk.Label(grid, text=str(d), width=4, pady=px(5), bg=nbg, fg=fg, cursor="hand2",
                              font=f["b"] if (cur or tdy) else f["n"],
                              highlightthickness=1 if tdy and not cur else 0, highlightbackground=t["accent"])
                lb.grid(row=r, column=c, padx=1, pady=1)
                if not cur:
                    lb.bind("<Enter>", lambda e, w=lb: w.config(bg=t["card2"]))
                    lb.bind("<Leave>", lambda e, w=lb: w.config(bg=bg))
                lb.bind("<Button-1>", lambda e, dd=d: self.pick(dd))
        foot = tk.Frame(self.inner, bg=bg)
        foot.pack(fill="x", pady=(px(10), 0))
        app.btn(foot, "Hari ini", lambda: (self.on_pick(date.today()), self.destroy()), "ghost",
                font="s", pady=5, padx=12).pack(side="left")
        app.btn(foot, "Tutup", self.destroy, "ghost", font="s", pady=5, padx=12).pack(side="right")


# ------------------------------------------------------------------ aplikasi
BASE_D = {"s": -2, "n": 0, "b": 0, "m": 2, "h2": 4, "big": 7, "h1": 10}
BOLD = ("b", "m", "h2", "big", "h1")
FOLD_ON, FOLD_OFF = "–", "+"      # terbuka / terlipat (karakter ada di semua font)


class App(tk.Tk):
    NAV = [("dashboard", "▦", "Dashboard"), ("transaksi", "⇄", "Transaksi"),
           ("rekening", "▣", "Rekening"), ("bisnis", "◈", "Bisnis"),
           ("pengaturan", "⚙", "Pengaturan")]

    def __init__(self):
        super().__init__(className="nabunglandx")
        self.title("nabunglandx")
        self.dir = data_dir()
        self.cfg_path = os.path.join(self.dir, "settings.json")
        self.db_path = os.path.join(self.dir, "nabunglandx.db")
        self.cfg = load_settings(self.cfg_path)
        self.db = DB(self.db_path)
        self.bgs, self.charts, self.headers = weakref.WeakSet(), [], []
        self.fam = self.pick_family()
        self.zoom = max(0.7, min(2.0, float(self.cfg["zoom"])))
        self.auto = 1.0
        self.t = resolve_theme(self.cfg)
        self.total = 0
        self.hide = bool(self.cfg.get("hide", False))
        self.page, self.edit_id, self.fold_hook = "dashboard", None, None
        today = date.today()
        self.ym = (today.year, today.month)
        self._rz = self._zj = self._tj = self._sa = self._wpjob = None
        self._toast = None
        self._pil = None
        self.wp_ok, self.wp_pim, self.wp_tk, self.wp_off, self.wp_key, self.wp_srcimg = False, None, None, (0, 0), None, None
        self.mkfonts()
        try:
            w, h = (int(v) for v in self.cfg["win"])
        except Exception:
            w, h = 1240, 800
        self.geometry(f"{max(w, 560)}x{max(h, 420)}")
        self.minsize(560, 420)
        self.side_coll = self.calc_coll(w)
        self.set_icon()
        self.wp_load()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.bind("<Configure>", self._on_cfg)
        for k in ("<Control-plus>", "<Control-equal>", "<Control-KP_Add>"):
            self.bind_all(k, lambda e: self.zoom_by(.1))
        for k in ("<Control-minus>", "<Control-KP_Subtract>"):
            self.bind_all(k, lambda e: self.zoom_by(-.1))
        for k in ("<Control-0>", "<Control-KP_0>"):
            self.bind_all(k, lambda e: self.set_zoom(1.0))
        for k in ("<F8>", "<Control-Shift-H>", "<Control-Shift-h>"):
            self.bind_all(k, lambda e: self.toggle_hide())
        for k in ("<F9>", "<Control-backslash>"):
            self.bind_all(k, lambda e: self.toggle_side())
        for i, (key, _, _) in enumerate(self.NAV, 1):
            self.bind_all(f"<Control-Key-{i}>", lambda e, k=key: self.show(k))
        for k in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.bind_all(k, self.on_wheel)
        self.build()
        self.after(60, self.apply_alpha)

    # ---- dasar
    def pick_family(self):
        avail = set(tkfont.families(self))
        for fam in ("Segoe UI", "Inter", "Cantarell", "Noto Sans", "Ubuntu", "Roboto", "DejaVu Sans"):
            if fam in avail:
                return fam
        return tkfont.nametofont("TkDefaultFont").actual("family")

    @property
    def fs(self):
        return self.zoom * self.auto

    def px(self, n):
        return int(round(n * self.zoom)) if n else 0

    def side_w(self, coll):
        return int((64 if coll else 216) * max(.85, min(self.fs, 1.6)))

    def calc_coll(self, width):
        s = self.cfg.get("side")
        return bool(s) if s is not None else width < 940

    def mkfonts(self):
        self.f = {k: tkfont.Font(family=self.fam, size=-10, weight="bold" if k in BOLD else "normal")
                  for k in BASE_D}
        self.apply_fonts()

    def apply_fonts(self):
        base = int(self.cfg["font"])
        sc = float(self.tk.call("tk", "scaling"))
        for k, d in BASE_D.items():
            self.f[k].configure(size=-max(8, round((base + d) * sc * self.fs)))
        try:
            ttk.Style(self).configure("Treeview", rowheight=int(self.f["n"].metrics("linespace") * 1.9))
        except tk.TclError:
            pass

    def refresh_fonts(self):
        for h in list(self.headers):
            if h.winfo_exists():
                h.refit()
        for c in list(self.charts):
            c.redraw()
        if getattr(self, "side", None) is not None and self.side.winfo_exists():
            self.side.redraw()

    def set_icon(self):
        try:
            img = tk.PhotoImage(width=64, height=64)
            img.put(self.t["accent"], to=(0, 0, 64, 64))
            for x0, y0 in ((14, 36), (27, 24), (40, 12)):
                img.put("#ffffff", to=(x0, y0, x0 + 10, 52))
            self.iconphoto(True, img)
            self._icon = img
        except Exception:
            pass

    def save_cfg(self):
        try:
            with open(self.cfg_path, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    def on_close(self):
        try:
            self.cfg["win"] = [self.winfo_width(), self.winfo_height()]
        except Exception:
            pass
        self.biz_flush()
        self.save_cfg()
        self.db.close()
        self.destroy()

    def apply_theme(self):
        self.t = resolve_theme(self.cfg)
        self.apply_fonts()
        self.set_icon()
        self.save_cfg()
        self.wp_key = None
        self.build()

    def apply_alpha(self):
        try:
            self.attributes("-alpha", max(0.4, min(1.0, int(self.cfg.get("alpha", 100)) / 100)))
        except tk.TclError:
            pass

    # ---- ukuran jendela, zoom, scroll
    def _on_cfg(self, e):
        if e.widget is not self:
            return
        if self._rz:
            self.after_cancel(self._rz)
        self._rz = self.after(100, self.on_resize)

    def on_resize(self):
        self._rz = None
        W, H = self.winfo_width(), self.winfo_height()
        if W < 100 or H < 100:
            return
        a = 1.0
        if self.cfg.get("autofont", True):      # huruf ikut membesar/mengecil mengikuti ukuran jendela
            a = (W / 1240 * H / 800) ** .5
            a = max(.82, min(1.6, round((1 + (a - 1) * .8) * 50) / 50))
        changed = abs(a - self.auto) > 1e-6
        self.auto = a
        if changed:
            self.apply_fonts()
        coll = self.calc_coll(W)
        if coll != self.side_coll:
            self.set_side_coll(coll)
        elif changed and self.side.winfo_exists():
            self.side.config(width=self.side_w(self.side_coll))
        if changed:
            self.refresh_fonts()
        self.wp_dirty(30)

    def apply_autofont(self, on):
        self.cfg["autofont"] = bool(on)
        self.save_cfg()
        self.on_resize()

    def set_side_coll(self, coll, animate=True):
        self.side_coll = coll
        to = self.side_w(coll)
        if self._sa:
            self.after_cancel(self._sa)
            self._sa = None
        cur = self.side.winfo_width()
        if not animate or abs(cur - to) < 4:
            self.side.config(width=to)
            self.side.redraw()
            return

        def step(i):
            if not self.side.winfo_exists():
                return
            k = i / 6
            k = 1 - (1 - k) ** 2
            self.side.config(width=int(cur + (to - cur) * k))
            self.side.redraw()
            self._sa = self.after(16, lambda: step(i + 1)) if i < 6 else None
        step(1)

    def bal(self, n):
        """Saldo sebagai teks; disamarkan bila mode sembunyikan saldo aktif."""
        return MASK if self.hide else rp(n)

    def amt(self, n, sign=""):
        """Jumlah uang (pemasukan/pengeluaran/transaksi) -> teks; disamarkan bila mode sembunyikan aktif."""
        return MASK if self.hide else sign + rp(n)

    def set_hide(self, on, announce=True):
        self.hide = bool(on)
        self.cfg["hide"] = self.hide
        self.save_cfg()
        if getattr(self, "side", None) is not None and self.side.winfo_exists():
            self.side.redraw()
        self.show(self.page, keep=self.snap_form())
        if announce:
            self.toast("Saldo & keuangan disembunyikan" if self.hide else "Saldo & keuangan ditampilkan")

    def toggle_hide(self):
        self.set_hide(not self.hide)

    def toggle_side(self):
        self.cfg["side"] = not self.side_coll
        self.save_cfg()
        self.set_side_coll(self.cfg["side"])

    def set_side_mode(self, mode):                     # None = otomatis, True = ciut, False = lebar
        self.cfg["side"] = mode
        self.save_cfg()
        self.set_side_coll(self.calc_coll(self.winfo_width()))

    def set_zoom(self, z):
        z = max(0.7, min(2.0, round(z * 10) / 10))
        if abs(z - self.zoom) > 1e-6:
            self.zoom = z
            self.cfg["zoom"] = z
            self.save_cfg()
            self.apply_fonts()
            self.refresh_fonts()
            if self._zj:
                self.after_cancel(self._zj)
            self._zj = self.after(170, self._zoom_build)
        self.toast(f"Zoom {int(round(z * 100))}%")

    def _zoom_build(self):
        self._zj = None
        self.build()

    def zoom_by(self, d):
        self.set_zoom(self.zoom + d)

    def toast(self, text):
        t = self.t
        try:
            if self._toast is None or not self._toast.winfo_exists():
                self._toast = tk.Label(self, font=self.f["b"], bg=t["card2"], fg=t["text"], padx=self.px(16),
                                       pady=self.px(8), highlightthickness=1, highlightbackground=t["line"])
            self._toast.config(text=text)
            self._toast.place(relx=1, rely=1, x=-self.px(24), y=-self.px(24), anchor="se")
            self._toast.lift()
            if self._tj:
                self.after_cancel(self._tj)
            lab = self._toast

            def hide():
                try:
                    if lab.winfo_exists():
                        lab.place_forget()
                except tk.TclError:
                    pass
            self._tj = self.after(1300, hide)
        except tk.TclError:
            pass

    def on_wheel(self, e):
        ctrl = bool(e.state & 0x4)
        if getattr(e, "num", 0) == 4:
            d = 1
        elif getattr(e, "num", 0) == 5:
            d = -1
        else:
            d = 1 if e.delta > 0 else -1
        if ctrl:
            self.zoom_by(.1 * d)
            return
        try:
            w = e.widget
            if w.winfo_class() in ("Treeview", "Listbox", "Scale", "Text"):
                return
            pg = getattr(self, "pg", None)
            if pg is not None and str(w).startswith(str(pg)):
                pg.scroll(-3 * d)
        except Exception:
            pass

    # ---- pembantu UI
    def lbl(self, parent, text, font="n", fg="text", **kw):
        return tk.Label(parent, text=text, font=self.f[font], fg=self.t.get(fg, fg),
                        bg=kw.pop("bg", parent.cget("bg")), **kw)

    def card(self, parent, pad=16):
        t = self.t
        return tk.Frame(parent, bg=t["card"], highlightthickness=1, highlightbackground=t["line"],
                        padx=self.px(pad), pady=self.px(pad))

    def btn(self, parent, text, cmd, kind="primary", font="b", **kw):
        t = self.t
        if kind == "primary":
            bg, fg = t["accent"], on_color(t["accent"])
            hv = mix(bg, "#ffffff", .18)
        elif kind == "danger":
            bg, fg = t["card2"], t["bad"]
            hv = mix(bg, t["bad"], .22)
        else:
            bg, fg = t["card2"], t["text"]
            hv = mix(bg, t["text"], .12)
        kw["padx"], kw["pady"] = self.px(kw.get("padx", 16)), self.px(kw.get("pady", 8))
        return Btn(parent, text, cmd, bg, fg, hv, self.f[font], **kw)

    def entry(self, parent, var, font="n", **kw):
        t = self.t
        return tk.Entry(parent, textvariable=var, font=self.f[font], bg=t["card2"], fg=t["text"],
                        insertbackground=t["text"], relief="flat", highlightthickness=1,
                        highlightbackground=t["line"], highlightcolor=t["accent"], **kw)

    def combo(self, parent, var, values, readonly=True):
        cb = ttk.Combobox(parent, textvariable=var, values=values, font=self.f["n"],
                          state="readonly" if readonly else "normal")
        cb.bind("<<ComboboxSelected>>", lambda e: e.widget.selection_clear())
        return cb

    def money_entry(self, parent, var, font="n", hint=None, **kw):
        """Kolom angka rupiah. Titik ribuan muncul otomatis tiap 3 digit; kursor dihitung dari jumlah DIGIT di
        kirinya, jadi saat titik bertambah kursor ikut maju (tidak tertinggal). Koma = desimal.
        Tombol angka/Backspace/Delete ditangani langsung (Tk bisa menimpa posisi kursor setelah trace)."""
        e = self.entry(parent, var, font, **kw)
        busy, prev, tok = [False], [var.get()], [0]
        KEEP = "0123456789,"

        def cursor_for(new, n):
            if not n:
                return 0
            cnt = 0
            for i, c in enumerate(new):
                if c in KEEP:
                    cnt += 1
                    if cnt == n:
                        return i + 1
            return len(new)

        def apply(raw, pos, now=True):
            """raw = teks mentah, pos = posisi kursor di raw -> rapikan, taruh kursor di digit yang sama."""
            n = sum(1 for c in raw[:pos] if c in KEEP)
            new = fmt_money_text(raw)
            busy[0] = True
            try:
                if var.get() != new:
                    var.set(new)
            finally:
                busy[0] = False
            idx = cursor_for(new, n)
            e.icursor(idx)
            tok[0] += 1
            if not now:                                   # dari dalam trace: Tk bisa menimpa kursor, tegaskan lagi
                t0 = tok[0]
                e.after_idle(lambda: e.winfo_exists() and tok[0] == t0 and e.icursor(idx))
            prev[0] = new
            if hint is not None and hint.winfo_exists():
                hint.config(text=money_hint(new))

        def on_trace(*_):                                 # tempel / perubahan dari luar
            if busy[0]:
                return
            raw = var.get()
            pm = re.fullmatch(r"\s*(?:Rp\.?)?\s*(\d+)\.(\d{1,2})\s*", raw) if len(raw) - len(prev[0]) > 1 else None
            if pm:                                        # tempel "1500.50" (format ekspor) -> 1501, bukan 150050
                raw = str(int(pm.group(1)) + (1 if int(pm.group(2).ljust(2, "0")) >= 50 else 0))
            try:
                pos = e.index("insert")
            except tk.TclError:
                pos = len(raw)
            apply(raw, pos, now=False)

        def sel_range():
            try:
                if e.selection_present():
                    return e.index("sel.first"), e.index("sel.last")
            except tk.TclError:
                pass
            return None

        def on_key(ev):
            if ev.state & 0x4 or ev.char not in tuple("0123456789.,"):
                return None
            txt, rng = var.get(), sel_range()
            pos = e.index("insert")
            if rng:
                txt, pos = txt[:rng[0]] + txt[rng[1]:], rng[0]
            apply(txt[:pos] + ev.char + txt[pos:], pos + 1)
            return "break"

        def on_back(ev):
            txt, rng = var.get(), sel_range()
            pos = e.index("insert")
            if rng:
                apply(txt[:rng[0]] + txt[rng[1]:], rng[0])
                return "break"
            j = pos - 1
            while j >= 0 and txt[j] == ".":               # lewati titik, hapus digit di kirinya
                j -= 1
            if j >= 0:
                apply(txt[:j] + txt[j + 1:], j)
            return "break"

        def on_del(ev):
            txt, rng = var.get(), sel_range()
            pos = e.index("insert")
            if rng:
                apply(txt[:rng[0]] + txt[rng[1]:], rng[0])
                return "break"
            j = pos
            while j < len(txt) and txt[j] == ".":
                j += 1
            if j < len(txt):
                apply(txt[:j] + txt[j + 1:], pos)
            return "break"
        e.bind("<KeyPress>", on_key)
        e.bind("<BackSpace>", on_back)
        e.bind("<Delete>", on_del)
        var.trace_add("write", on_trace)
        return e

    def style_ttk(self):
        t, f = self.t, self.f
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("Treeview", background=t["card"], fieldbackground=t["card"], foreground=t["text"],
                    borderwidth=0, rowheight=int(f["n"].metrics("linespace") * 1.9), font=f["n"])
        s.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
        s.configure("Treeview.Heading", background=t["card2"], foreground=t["muted"], relief="flat",
                    borderwidth=0, font=f["b"], padding=(8, 6))
        s.map("Treeview.Heading", background=[("active", t["card2"])])
        s.map("Treeview", background=[("selected", t["accent"])],
              foreground=[("selected", on_color(t["accent"]))])
        s.configure("TCombobox", fieldbackground=t["card2"], background=t["card2"], foreground=t["text"],
                    arrowcolor=t["muted"], bordercolor=t["line"], lightcolor=t["card2"],
                    darkcolor=t["card2"], padding=self.px(7), arrowsize=self.px(14))
        s.map("TCombobox", fieldbackground=[("readonly", t["card2"]), ("focus", t["card2"])],
              foreground=[("readonly", t["text"])], selectbackground=[("readonly", t["card2"])],
              selectforeground=[("readonly", t["text"])], bordercolor=[("focus", t["accent"])])
        s.configure("Vertical.TScrollbar", background=t["card2"], troughcolor=t["bg"],
                    bordercolor=t["bg"], arrowcolor=t["muted"], lightcolor=t["card2"],
                    darkcolor=t["card2"], gripcount=0, arrowsize=self.px(12))
        s.map("Vertical.TScrollbar", background=[("pressed", t["accent"]), ("active", t["muted"]),
                                                 ("!active", t["line"])])
        self.option_add("*TCombobox*Listbox.background", t["card2"])
        self.option_add("*TCombobox*Listbox.foreground", t["text"])
        self.option_add("*TCombobox*Listbox.selectBackground", t["accent"])
        self.option_add("*TCombobox*Listbox.selectForeground", on_color(t["accent"]))
        self.option_add("*TCombobox*Listbox.font", f["n"])

    def modal(self, title):
        t = self.t
        d = tk.Toplevel(self)
        d.title(title)
        d.configure(bg=t["card"], padx=self.px(22), pady=self.px(20))
        d.resizable(False, False)
        d.transient(self)
        d.bind("<Escape>", lambda e: d.destroy())
        return d

    def show_modal(self, d, w):
        d.update_idletasks()
        W, H = max(int(w * self.fs), d.winfo_reqwidth()), d.winfo_reqheight()
        x = self.winfo_rootx() + (self.winfo_width() - W) // 2
        y = self.winfo_rooty() + (self.winfo_height() - H) // 3
        d.geometry(f"{W}x{H}+{max(x, 0)}+{max(y, 0)}")

        def grab():
            try:
                d.grab_set()
                d.focus_set()
            except tk.TclError:
                pass
        d.after(80, grab)

    def wrapw(self, w):
        return int((w - 44) * self.fs)

    # ---- wallpaper
    def pil(self):
        if self._pil is None:
            try:
                from PIL import Image, ImageFilter
                self._pil = (Image, ImageFilter)
            except Exception:
                self._pil = False
        return self._pil

    def wp_on(self):
        return bool(self.wp_ok and self.cfg["wp"].get("src"))

    def wp_load(self):
        """Muat sumber wallpaper sesuai pengaturan (gambar dibaca sekali, lalu diolah sesuai ukuran jendela)."""
        self.wp_ok, self.wp_srcimg, self.wp_pim, self.wp_tk, self.wp_key = False, None, None, None, None
        src = self.cfg["wp"].get("src", "")
        if not src:
            return None
        try:
            if src.startswith("grad:"):
                self.wp_srcimg = ("grad", WALLS[src[5:]][1])
            elif src.startswith("file:"):
                path = src[5:]
                P = self.pil()
                if P:
                    im = P[0].open(path)
                    im.load()
                    im = im.convert("RGB")
                    im.thumbnail((2560, 2560))
                    self.wp_srcimg = ("pil", im)
                else:
                    self.wp_srcimg = ("tk", tk.PhotoImage(file=path))
            else:
                return None
            self.wp_ok = True
            return None
        except Exception as ex:
            self.cfg["wp"]["src"] = ""
            return str(ex)

    def wp_dirty(self, delay=140):
        if not self.wp_on():
            return
        if self._wpjob:
            self.after_cancel(self._wpjob)
        self._wpjob = self.after(delay, self._wp_flush)

    def _wp_flush(self):
        self._wpjob = None
        if not self.wp_on():
            return
        self.wp_render()
        for b in list(self.bgs):
            try:
                b.paint()
            except tk.TclError:
                pass

    def wp_render(self):
        W, H = self.winfo_width(), self.winfo_height()
        if not self.wp_ok or W < 50 or H < 50:
            return
        wp = self.cfg["wp"]
        key = (wp["src"], wp.get("dim", 0), wp.get("blur", 0), W, H, self.t["bg"],
               wp.get("zoom", 100), wp.get("fx", 50), wp.get("fy", 50))
        if key == self.wp_key:
            return
        self.wp_key = key
        kind, obj = self.wp_srcimg
        P = self.pil()
        self.wp_pim = self.wp_tk = None
        self.wp_off = (0, 0)
        try:
            if P:
                Image, ImageFilter = P
                rs = getattr(Image, "Resampling", Image)
                if kind == "grad":
                    rows = grad_rgb(obj, 24, 15)
                    im = Image.new("RGB", (24, 15))
                    im.putdata([c for r in rows for c in r])
                    im = im.resize((W, H), rs.BICUBIC)
                else:
                    sw, sh = obj.size
                    z = max(1.0, min(4.0, float(wp.get("zoom", 100)) / 100))
                    fx = max(0.0, min(1.0, float(wp.get("fx", 50)) / 100))
                    fy = max(0.0, min(1.0, float(wp.get("fy", 50)) / 100))
                    fw = min(sw, sh * W / H) / z                  # bagian sumber yang tampil (bingkai)
                    fh = fw * H / W
                    x0, y0 = (sw - fw) * fx, (sh - fh) * fy
                    box = (x0, y0, x0 + fw, y0 + fh)
                    try:
                        im = obj.resize((W, H), rs.BILINEAR, box=box, reducing_gap=2.0)
                    except TypeError:
                        im = obj.resize((W, H), rs.BILINEAR, box=box)
                if wp.get("blur", 0) > 0:
                    im = im.filter(ImageFilter.GaussianBlur(wp["blur"]))
                if wp.get("dim", 0) > 0:
                    im = Image.blend(im, Image.new("RGB", im.size, self.t["bg"]), wp["dim"] / 100)
                self.wp_pim = im
            elif kind == "grad":
                gw, gh = 160, 100
                small = tk.PhotoImage(width=gw, height=gh)
                for y, row in enumerate(grad_rgb(obj, gw, gh)):
                    small.put("{" + " ".join("#%02x%02x%02x" % c for c in row) + "}", to=(0, y))
                k = max(-(-W // gw), -(-H // gh))
                self.wp_tk = small.zoom(k)
                self.tk_tint(self.wp_tk, self.t["bg"], wp.get("dim", 0) / 100)
                self.wp_off = ((self.wp_tk.width() - W) // 2, (self.wp_tk.height() - H) // 2)
            else:
                iw, ih = obj.width(), obj.height()
                s = max(W / iw, H / ih)
                img = obj.subsample(max(1, int(1 / s))) if s < 1 else obj.zoom(-(-int(s * 100) // 100) or 1)
                self.tk_tint(img, self.t["bg"], wp.get("dim", 0) / 100)
                self.wp_tk = img
                self.wp_off = (max(0, (img.width() - W) // 2), max(0, (img.height() - H) // 2))
        except Exception:
            self.wp_pim = self.wp_tk = None

    def tk_tint(self, img, color, alpha):
        """Campur warna ke PhotoImage (alpha 0..1) memakai compositing Tk, tanpa Pillow."""
        if alpha <= 0:
            return
        try:
            ov = tk.PhotoImage(data=rgba_png_b64(color, alpha), format="png")
            self.tk.call(str(img), "copy", str(ov), "-to", 0, 0, img.width(), img.height(),
                         "-compositingrule", "overlay")
        except tk.TclError:
            pass

    def to_photo(self, im):
        buf = io.BytesIO()
        im.save(buf, "PNG", compress_level=1)
        return tk.PhotoImage(data=base64.b64encode(buf.getvalue()))

    def wp_slice(self, x, y, w, h, tint, alpha):
        """Potongan wallpaper untuk area (x,y,w,h) di jendela -> (gambar, offset_x, offset_y)."""
        if self.wp_pim is not None:
            Image = self.pil()[0]
            W, H = self.wp_pim.size
            x0, y0, x1, y1 = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
            if x1 - x0 < 1 or y1 - y0 < 1:
                return None
            c = self.wp_pim.crop((x0, y0, x1, y1))
            if tint and alpha > 0:
                c = Image.blend(c, Image.new("RGB", c.size, tint), alpha)
            return self.to_photo(c), x0 - x, y0 - y
        if self.wp_tk is not None:
            ox, oy = self.wp_off
            W, H = self.wp_tk.width(), self.wp_tk.height()
            x0, y0 = max(x, 0), max(y, 0)
            x1, y1 = min(x + w, W - ox), min(y + h, H - oy)
            if x1 - x0 < 1 or y1 - y0 < 1:
                return None
            img = tk.PhotoImage()
            self.tk.call(str(img), "copy", str(self.wp_tk), "-from", x0 + ox, y0 + oy, x1 + ox, y1 + oy)
            if tint and alpha > 0:
                self.tk_tint(img, tint, alpha)
            return img, x0 - x, y0 - y
        return None

    def wp_overlay(self, cv, w, h, tint):
        """Redup & tint sudah diterapkan ke gambar (Pillow atau compositing Tk), jadi tak ada lapisan tambahan."""
        return

    def wp_thumb(self, spec, w, h):
        """Gambar mini untuk pratinjau pilihan wallpaper."""
        img = tk.PhotoImage(width=w, height=h)
        try:
            if spec.startswith("grad:"):
                for y, row in enumerate(grad_rgb(WALLS[spec[5:]][1], w, h)):
                    img.put("{" + " ".join("#%02x%02x%02x" % c for c in row) + "}", to=(0, y))
            elif spec.startswith("file:"):
                P = self.pil()
                if P:
                    im = P[0].open(spec[5:])
                    im = im.convert("RGB")
                    sw, sh = im.size
                    s = max(w / sw, h / sh)
                    im = im.resize((max(w, round(sw * s)), max(h, round(sh * s))))
                    l, tp = (im.width - w) // 2, (im.height - h) // 2
                    return self.to_photo(im.crop((l, tp, l + w, tp + h)))
                src = tk.PhotoImage(file=spec[5:])
                f = max(1, min(src.width() // w, src.height() // h))
                return src.subsample(f)
        except Exception:
            img.put(self.t["card2"], to=(0, 0, w, h))
        return img

    def wp_set(self, src):
        err = None
        if src != self.cfg["wp"].get("src"):
            self.cfg["wp"].update(zoom=100, fx=50, fy=50)
        self.cfg["wp"]["src"] = src
        if src:
            err = self.wp_load()
            if err:
                messagebox.showerror("Wallpaper gagal", f"Gambar tidak bisa dibuka:\n{err}", parent=self)
        else:
            self.wp_load()
        self.save_cfg()
        self.wp_key = None
        self.show(self.page)
        self.wp_dirty(20)

    def wp_pick_file(self):
        p = filedialog.askopenfilename(parent=self, title="Pilih gambar wallpaper",
                                       filetypes=[("Gambar", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"),
                                                  ("Semua", "*.*")])
        if not p:
            return
        if not self.pil() and os.path.splitext(p)[1].lower() not in (".png", ".gif", ".ppm", ".pgm"):
            if messagebox.askyesno("Perlu Pillow",
                                   "Format ini (JPG/WEBP/BMP) butuh pustaka Pillow.\n\nPasang sekarang? "
                                   "(sekali saja, sekitar 3 MB, butuh internet)", parent=self):
                self.install_pillow(then=lambda: self.wp_use_file(p))
            return
        self.wp_use_file(p)

    def wp_use_file(self, p):
        self.wp_set("file:" + p)
        if self.wp_on() and self.pil():
            self.after(220, self.wp_frame_dialog)      # langsung atur bagian mana yang dipakai

    def wp_frame_dialog(self):
        """Pilih bagian gambar yang dipakai: bingkai terang = tampil di app, area gelap = tidak ikut."""
        wp = self.cfg["wp"]
        if not (wp.get("src", "").startswith("file:") and self.pil() and self.wp_srcimg and self.wp_srcimg[0] == "pil"):
            self.toast("Pilih foto lewat 'Gambar saya' dulu (butuh Pillow)")
            return
        im = self.wp_srcimg[1]
        sw, sh = im.size
        t, P = self.t, self.px
        d = self.modal("Atur bagian wallpaper")
        self.lbl(d, "Atur bagian gambar", "h2", bg=t["card"]).pack(anchor="w")
        self.lbl(d, "Bingkai terang = bagian yang tampil di app. Area gelap tidak ikut. Geser bingkai dengan "
                    "mouse, perbesar/perkecil dengan slider.", "s", "muted", bg=t["card"],
                 wraplength=self.wrapw(520), justify="left").pack(anchor="w", pady=(4, P(10)))
        CW, CH = P(520), P(330)
        cv = tk.Canvas(d, width=CW, height=CH, bg=t["card2"], highlightthickness=0, cursor="fleur")
        cv.pack()
        k = min(CW / sw, CH / sh)
        iw, ih = max(1, int(sw * k)), max(1, int(sh * k))
        ix, iy = (CW - iw) // 2, (CH - ih) // 2
        Image = self.pil()[0]
        photo = self.to_photo(im.resize((iw, ih), getattr(Image, "Resampling", Image).BILINEAR))
        cv.create_image(ix, iy, anchor="nw", image=photo)
        A = max(self.winfo_width(), 100) / max(self.winfo_height(), 100)
        st = {"z": max(1.0, float(wp.get("zoom", 100)) / 100), "fx": float(wp.get("fx", 50)) / 100,
              "fy": float(wp.get("fy", 50)) / 100, "px": 0, "py": 0, "sx": .5, "sy": .5}

        def frame():
            fw = min(sw, sh * A) / st["z"]
            return fw, fw / A

        def draw():
            cv.delete("ov")
            fw, fh = frame()
            x0, y0 = (sw - fw) * st["fx"], (sh - fh) * st["fy"]
            X0, Y0, X1, Y1 = ix + x0 * k, iy + y0 * k, ix + (x0 + fw) * k, iy + (y0 + fh) * k
            for r in ((ix, iy, ix + iw, Y0), (ix, Y1, ix + iw, iy + ih), (ix, Y0, X0, Y1), (X1, Y0, ix + iw, Y1)):
                if r[2] - r[0] > .5 and r[3] - r[1] > .5:
                    cv.create_rectangle(*r, fill="#000000", stipple="gray50", outline="", tags="ov")
            cv.create_rectangle(X0, Y0, X1, Y1, outline=t["accent"], width=2, tags="ov")

        def commit():
            wp.update(zoom=int(round(st["z"] * 100)), fx=int(round(st["fx"] * 100)), fy=int(round(st["fy"] * 100)))
            self.save_cfg()
            self.wp_key = None
            self.wp_dirty(10)

        def press(e):
            st.update(px=e.x, py=e.y, sx=st["fx"], sy=st["fy"])

        def move(e):
            fw, fh = frame()
            rx, ry = sw - fw, sh - fh
            if rx > .5:
                st["fx"] = max(0.0, min(1.0, st["sx"] + (e.x - st["px"]) / k / rx))
            if ry > .5:
                st["fy"] = max(0.0, min(1.0, st["sy"] + (e.y - st["py"]) / k / ry))
            draw()

        cv.bind("<Button-1>", press)
        cv.bind("<B1-Motion>", move)
        cv.bind("<ButtonRelease-1>", lambda e: commit())

        def zoom_mv(v):
            st["z"] = max(1.0, min(4.0, v / 100))
            draw()
        self.slider(d, "Perbesar bagian", 100, 400, int(st["z"] * 100), on_move=zoom_mv,
                    on_release=lambda v: commit(), fmt="{}%").pack(fill="x", pady=(P(10), P(8)))
        row = tk.Frame(d, bg=t["card"])
        row.pack(fill="x")

        def reset():
            st.update(z=1.0, fx=.5, fy=.5)
            commit()
            d.destroy()
            self.after(30, self.wp_frame_dialog)
        self.btn(row, "Reset ke tengah", reset, "ghost", font="s", pady=6).pack(side="left")
        self.btn(row, "Selesai", d.destroy, "primary", pady=8).pack(side="right")
        d._keep = photo
        draw()
        self.show_modal(d, 580)

    def install_pillow(self, then=None):
        self.toast("Memasang Pillow…")
        out = {}

        def work():
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            base = [sys.executable, "-m", "pip", "install", "--user", "--quiet", "pillow"]
            for extra in (["--break-system-packages"], []):
                try:
                    r = subprocess.run(base + extra, capture_output=True, text=True, creationflags=flags, timeout=300)
                except Exception as ex:
                    out["err"] = str(ex)
                    break
                if r.returncode == 0:
                    out["ok"] = True
                    break
                out["err"] = (r.stderr or r.stdout or "")[-400:]
            self.after(0, done)

        def done():
            if out.get("ok"):
                try:
                    import importlib
                    import site
                    importlib.invalidate_caches()
                    us = site.getusersitepackages()
                    if us not in sys.path:
                        sys.path.append(us)
                except Exception:
                    pass
                self._pil = None
                if self.pil():
                    self.toast("Pillow terpasang ✓")
                    if then:
                        then()
                    else:
                        self.wp_load()
                        self.wp_key = None
                        self.show(self.page)
                    return
            messagebox.showwarning("Gagal memasang Pillow",
                                   "Tidak bisa memasang otomatis.\n\nCoba manual:\n  Windows:  py -m pip install pillow\n"
                                   "  Fedora:   sudo dnf install python3-pillow\n\n" + str(out.get("err", ""))[-200:],
                                   parent=self)
        threading.Thread(target=work, daemon=True).start()

    # ---- lipat / buka (collapse)
    def folded(self, key):
        return bool(self.cfg["fold"].get(key))

    def _fold_changed(self):
        if self.fold_hook:
            try:
                self.fold_hook()
            except tk.TclError:
                pass
        self.wp_dirty(40)

    def fold_card(self, parent, key, title, pad=16, font="m"):
        """Kartu dengan judul yang bisa diklik untuk melipat/membuka isinya. -> (kartu, isi)"""
        t = self.t
        card = self.card(parent, pad)
        card.fkey = key
        head = tk.Frame(card, bg=t["card"])
        head.pack(fill="x")
        chev = tk.Label(head, font=self.f["m"], fg=t["muted"], bg=t["card"], cursor="hand2", padx=self.px(4))
        chev.pack(side="right")
        ttl = Fit(head, self, title, [font, "b", "n"], t["text"], t["card"], cursor="hand2")
        ttl.pack(side="left", fill="x", expand=True)
        body = tk.Frame(card, bg=t["card"])
        card.head, card.body = head, body

        def apply():
            if self.folded(key):
                chev.config(text=FOLD_OFF)
                body.pack_forget()
            else:
                chev.config(text=FOLD_ON)
                body.pack(fill="both", expand=True, pady=(self.px(8), 0))

        def toggle(e=None):
            self.cfg["fold"][key] = not self.folded(key)
            self.save_cfg()
            apply()
            self.after_idle(self._fold_changed)
        for wd in (chev, ttl):
            wd.bind("<Button-1>", toggle)
        apply()
        return card, body

    def fold_section(self, parent, key, title, right=""):
        """Bilah judul yang bisa dilipat (dipakai untuk kelompok rekening). -> (bar, toggle, terlipat?)"""
        t = self.t
        bar = tk.Frame(parent, bg=t["card"], highlightthickness=1, highlightbackground=t["line"],
                       padx=self.px(14), pady=self.px(9), cursor="hand2")
        chev = tk.Label(bar, font=self.f["m"], fg=t["muted"], bg=t["card"], cursor="hand2")
        chev.pack(side="left")
        ttl = tk.Label(bar, text="  " + title, font=self.f["b"], fg=t["text"], bg=t["card"], cursor="hand2")
        ttl.pack(side="left")
        rt = tk.Label(bar, text=right, font=self.f["n"], fg=t["muted"], bg=t["card"], cursor="hand2")
        rt.pack(side="right")

        def paint():
            chev.config(text=FOLD_OFF if self.folded(key) else FOLD_ON)
        paint()
        return bar, (chev, ttl, rt), paint

    # ---- bisnis (untung-rugi & alur uang)
    bm = bc = bz = biz_id = _bj = None
    biz_name = ""

    def biz_load(self):
        rows = self.db.biz_list()
        for r in rows:                                   # contoh lama (angka dari gambar) -> contoh baru
            if r["name"] == "Paket Umroh (contoh)":
                try:
                    if biz_is_old_umroh(json.loads(self.db.biz_get(r["id"])["data"])):
                        self.db.biz_save(r["id"], "Warung Kopi (contoh)", biz_template("kopi"))
                except (ValueError, TypeError):
                    pass
        if not rows:
            self.db.biz_save(None, "Warung Kopi (contoh)", biz_template("kopi"))
        rows = self.db.biz_list()
        ids = [r["id"] for r in rows]
        cur = self.cfg.get("biz")
        if cur not in ids:
            cur = ids[0]
        self.cfg["biz"] = cur
        r = self.db.biz_get(cur)
        self.biz_id, self.biz_name = cur, r["name"]
        try:
            self.bm = biz_clean(json.loads(r["data"]))
        except ValueError:
            self.bm = biz_clean(None)
        return rows

    def biz_dirty(self):
        if self._bj:
            self.after_cancel(self._bj)
        self._bj = self.after(500, self.biz_flush)

    def biz_flush(self):
        if self._bj:
            try:
                self.after_cancel(self._bj)
            except tk.TclError:
                pass
            self._bj = None
        if self.bm is not None and self.biz_id:
            try:
                self.db.biz_save(self.biz_id, self.biz_name, self.bm)
            except sqlite3.Error:
                pass

    def biz_changed(self):
        self.bc = biz_calc(self.bm)
        self.biz_paint()
        self.biz_dirty()

    @staticmethod
    def fit_set(lb, text, fg=None):
        lb.full = text
        if fg:
            lb.config(fg=fg)
        lb.fit(lb.winfo_width())

    def biz_unit(self):
        return (self.bm["unit"] or "unit").strip().lower()

    def biz_per(self):
        return (self.bm["per"] or "sebulan").strip()

    def biz_smax(self, v):
        ref = max([i["v"] for i in self.bm["inc"] + self.bm["cost"]] or [0])
        return nice_max(max(v * 2, ref * .25, 10000))

    @staticmethod
    def biz_step(smax):
        return max(1, 10 ** (int(math.floor(math.log10(max(smax, 10)))) - 3))

    def wrap_label(self, parent, text="", font="n", fg="muted", **kw):
        """Label yang otomatis membungkus baris sesuai lebar tempatnya (tanpa memaksa kolom melebar)."""
        t = self.t
        lb = tk.Label(parent, text=text, font=self.f[font], fg=t.get(fg, fg), bg=parent.cget("bg"), justify="left",
                      anchor="w", width=1, **kw)

        def fit(e):
            want = max(60, e.width - 4)
            if int(float(lb.cget("wraplength") or 0)) != want:
                lb.config(wraplength=want)
        lb.bind("<Configure>", fit)
        return lb

    def step_head(self, parent, n, title, color, sub):
        t, P = self.t, self.px
        box = tk.Frame(parent, bg=t["card"])
        box.pack(fill="x", pady=(P(16), P(6)))
        top = tk.Frame(box, bg=t["card"])
        top.pack(fill="x")
        tk.Label(top, text=str(n), font=self.f["b"], bg=color, fg=on_color(color), width=2).pack(side="left")
        ttl = Fit(top, self, title, ["m", "b", "n"], t["text"], t["card"])
        ttl.pack(side="left", fill="x", expand=True, padx=(P(8), 0))
        sb = self.biz_dyn(self.wrap_label(box, sub, "s", "muted"), sub)
        sb.pack(fill="x", pady=(P(3), 0))
        return top, ttl, sb

    def page_bisnis(self):
        t, f, P = self.t, self.f, self.px
        rows = self.biz_load()
        self.bc = biz_calc(self.bm)
        w = self.wrap()
        w.grid_columnconfigure(0, weight=1)
        h = self.header(w, "Bisnis", "Hitung untung-rugi usahamu dengan mudah", month_nav=False)
        h.add(self.btn(h, "+  Skenario baru", self.biz_new_dialog, "primary"), 8)
        h.add(self.btn(h, "Ekspor CSV", self.biz_export, "ghost", font="s"), 8)
        h.add(self.btn(h, "Tampilkan angka" if self.hide else "Sembunyikan angka", self.toggle_hide, "ghost",
                       font="s"), 0)
        self.bz = {"root": w, "rows": [], "calc": {}, "bep": {}, "dyn": []}
        # --- pilih skenario
        bar = Bg(w, self)
        bar.grid(row=1, column=0, sticky="ew", pady=(0, P(12)))
        self.lbl(bar, "Skenario", "s", "muted").pack(side="left", padx=(0, P(8)))
        names = [r["name"] for r in rows]
        v_sc = tk.StringVar(value=self.biz_name)
        cb = self.combo(bar, v_sc, names)
        cb.config(width=max(18, min(38, max(len(n) for n in names) + 2)))
        cb.pack(side="left")

        def pick(e=None):
            i = cb.current()
            self.after_idle(lambda: self.biz_switch(rows[i]["id"]))
        cb.bind("<<ComboboxSelected>>", pick, add="+")
        for txt, cmd, kind in (("Ubah nama", self.biz_rename, "ghost"), ("Duplikat", self.biz_duplicate, "ghost"),
                               ("Hapus", self.biz_delete_cur, "danger")):
            self.btn(bar, txt, cmd, kind, font="s", pady=5, padx=12).pack(side="left", padx=(P(8), 0))
        g2 = Bg(w, self)
        g2.grid(row=2, column=0, sticky="ew")
        # --- kesimpulan (selalu paling atas di sisi hasil)
        vc = self.card(g2, 20)
        stripe = tk.Frame(vc, height=P(4), bg=t["accent"])
        stripe.pack(fill="x", pady=(0, P(10)))
        self.lbl(vc, "HASIL USAHAMU", "s", "muted").pack(anchor="w")
        head = Fit(vc, self, "", ["h1", "big", "h2", "m", "b"], t["text"], t["card"])
        head.pack(fill="x", pady=(P(2), P(4)))
        sub = self.wrap_label(vc, "", "n", "text")
        sub.pack(fill="x")
        mini = tk.Frame(vc, bg=t["card"])
        mini.pack(fill="x", pady=(P(12), P(4)))
        vals = {}
        for i, (key, title) in enumerate((("in", "Uang masuk"), ("out", "Pengeluaran"), ("net", "Untung bersih"))):
            mini.grid_columnconfigure(i, weight=1, uniform="m")
            cell = tk.Frame(mini, bg=t["card2"], padx=P(10), pady=P(8))
            cell.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else P(5), 0 if i == 2 else P(5)))
            Fit(cell, self, title.upper(), ["s"], t["muted"], t["card2"]).pack(fill="x")
            vl = Fit(cell, self, "", ["m", "b", "n", "s"], t["text"], t["card2"])
            vl.pack(fill="x")
            vals[key] = vl
        tips = self.wrap_label(vc, "", "s", "muted")
        tips.pack(fill="x", pady=(P(6), 0))
        self.bz["v"] = dict(stripe=stripe, head=head, sub=sub, tips=tips, **vals)
        # --- isi angka (kiri)
        cl, bl = self.fold_card(g2, "b_edit", "Isi angkamu", 18)
        self.bz["ed"] = bl
        # --- hasil lainnya (kanan)
        cr = Bg(g2, self)
        c1, b1 = self.fold_card(cr, "b_split", "Uangmu dipakai untuk apa?", 18)
        c1.pack(fill="x", pady=(0, P(14)))
        self.bz["split"] = SplitBar(b1, self)
        self.bz["split"].pack(fill="x")
        self.lbl(b1, "Titik aman (batas tidak rugi)", "b").pack(anchor="w", pady=(P(14), 0))
        self.bz["meter"] = Meter(b1, self)
        self.bz["meter"].pack(fill="x")
        self.wrap_label(b1, "Titik aman = jumlah terjual paling sedikit supaya uang masuk cukup menutup semua biaya. "
                            "Di bawah itu rugi, di atas itu untung.", "s", "muted").pack(fill="x", pady=(P(4), 0))
        c2, b2 = self.fold_card(cr, "b_calc", "Rincian hitungan", 18)
        c2.pack(fill="x", pady=(0, P(14)))
        self.biz_build_calc(b2)
        c3, b3 = self.fold_card(cr, "b_target", "Mau untung berapa?", 18)
        c3.pack(fill="x")
        self.biz_build_target(b3)

        def reflow(e=None):
            wide = g2.winfo_width() >= P(960)
            if getattr(g2, "wide", None) == wide:
                return
            g2.wide = wide
            for x in (vc, cl, cr):
                x.grid_forget()
            if wide:
                g2.grid_columnconfigure(0, weight=11, uniform="e")
                g2.grid_columnconfigure(1, weight=9, uniform="e")
                cl.grid(row=0, column=0, rowspan=2, sticky="new", padx=(0, P(7)))
                vc.grid(row=0, column=1, sticky="new", padx=(P(7), 0), pady=(0, P(14)))
                cr.grid(row=1, column=1, sticky="new", padx=(P(7), 0))
            else:
                g2.grid_columnconfigure(0, weight=1, uniform="e")
                g2.grid_columnconfigure(1, weight=1, uniform="e")
                vc.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, P(14)))
                cl.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, P(14)))
                cr.grid(row=2, column=0, columnspan=2, sticky="ew")
        g2.bind("<Configure>", reflow)
        # --- diagram alur uang (lebar penuh)
        c4, b4 = self.fold_card(w, "b_sankey", "Alur uang lengkap: dari mana, ke mana", 18)
        c4.grid(row=3, column=0, sticky="ew", pady=(P(14), 0))
        self.sk = Sankey(b4, self, P(420))
        self.sk.pack(fill="x")
        self.wrap_label(b4, "Kiri: dari mana uang masuk. Tengah: total uang. Lalu dibagi jadi Modal pokok (oranye), "
                            "Biaya tetap (ungu), Pajak (abu-abu), dan Untung bersih (hijau). Makin lebar pita, makin "
                            "besar uangnya. Arahkan kursor ke pita untuk melihat angkanya.", "s", "muted"
                        ).pack(fill="x", pady=(P(6), 0))
        self.biz_build_editor()
        self.bz["ready"] = True
        self.biz_paint()

    # -- bagian kiri: isi angka (semua dipandu langkah demi langkah)
    def biz_pair(self, parent, value, on_value, smax_fn, prefix="Rp"):
        """Slider + kolom angka yang saling sinkron."""
        t, P = self.t, self.px
        low = tk.Frame(parent, bg=t["card"])
        v_amt = tk.StringVar(value=num(value) if value else "")
        ent = self.money_entry(low, v_amt, width=14 if prefix else 10)
        ent.pack(side="right", ipady=P(3))
        if prefix:
            self.lbl(low, prefix, "s", "muted").pack(side="right", padx=(P(8), P(4)))
        smax = smax_fn(value)
        sc = tk.Scale(low, from_=0, to=smax, orient="horizontal", showvalue=False, resolution=self.biz_step(smax),
                      bd=0, highlightthickness=0, bg=t["card"], troughcolor=t["card2"], activebackground=t["accent"],
                      sliderrelief="flat", sliderlength=P(20), width=P(12), relief="flat", takefocus=0)
        sc.set(value)
        sc.pack(side="left", fill="x", expand=True)
        st = {"sync": False}

        def mv(val):
            if st["sync"]:
                return
            v = int(float(val))
            st["sync"] = True
            try:
                v_amt.set(num(v) if v else "")
            finally:
                st["sync"] = False
            on_value(v)

        def on_amt(*_):
            if st["sync"]:
                return
            v = parse_money(v_amt.get())
            if v > float(sc.cget("to")):
                ns = smax_fn(v)
                sc.config(to=ns, resolution=self.biz_step(ns))
            st["sync"] = True
            try:
                sc.set(min(v, float(sc.cget("to"))))
            finally:
                st["sync"] = False
            on_value(v)
        sc.config(command=mv)
        v_amt.trace_add("write", on_amt)
        return low

    def biz_dyn(self, lb, fmt):
        """Daftarkan teks yang memuat {u} (satuan) dan {per} (periode) supaya ikut berubah."""
        self.bz["dyn"].append((lb, fmt))
        return lb

    def biz_build_editor(self):
        t, f, P, m = self.t, self.f, self.px, self.bm
        body = self.bz["ed"]
        for wd in body.winfo_children():
            wd.destroy()
        self.bz["rows"] = []
        self.bz["dyn"] = [d for d in self.bz["dyn"] if d[0].winfo_exists()]
        self.wrap_label(body, "Isi dari atas ke bawah. Tiap angka bisa diketik atau digeser pakai slider. Hasilnya "
                              "di sebelah kanan langsung ikut berubah.", "s", "muted").pack(fill="x")
        # 1. jualan
        self.step_head(body, 1, "Jualan", COL_IN, "Apa yang kamu jual, dan berapa banyak yang terjual?")
        g = tk.Frame(body, bg=t["card"])
        g.pack(fill="x")
        g.grid_columnconfigure(1, weight=1)
        for r, (label, key, hint) in enumerate((("Yang dijual", "unit", "mis. cangkir, porsi, paket, orang"),
                                                ("Untuk periode", "per", "mis. sebulan, seminggu, per trip"))):
            self.lbl(g, label, "n", "muted").grid(row=r * 2, column=0, sticky="w", pady=(P(4), 0))
            v = tk.StringVar(value=m[key])
            e = self.entry(g, v, width=16)
            e.grid(row=r * 2, column=1, sticky="w", padx=(P(12), 0), pady=(P(4), 0), ipady=P(3))
            self.lbl(g, hint, "s", "muted").grid(row=r * 2 + 1, column=1, sticky="w", padx=(P(12), 0))

            def on_text(*_, k=key, v=v):
                m[k] = v.get()[:20]
                self.biz_changed()
            v.trace_add("write", on_text)
        lq = self.biz_dyn(self.lbl(body, "", "n"), "Jumlah {u} terjual {per}")
        lq.pack(anchor="w", pady=(P(10), 0))

        def set_qty(v):
            m["qty"] = max(1, min(10 ** 7, v))
            self.biz_changed()
        self.biz_pair(body, m["qty"], set_qty, lambda v: nice_max(max(v * 2, 20)), prefix="").pack(fill="x")
        self.biz_items(body, "inc", "unit", COL_IN, "Harga jual per {u}", "+  Harga jual lain", "Harga jual lain")
        if any(i["b"] == "tetap" for i in m["inc"]):
            self.biz_items(body, "inc", "tetap", COL_IN, "Pemasukan lain (sekali saja, tidak dikali jumlah)",
                           "+  Pemasukan lain", "Pemasukan lain")
        else:
            self.btn(body, "+  Pemasukan lain (sekali saja)", lambda: self.biz_add("inc", "tetap"), "ghost", font="s",
                     pady=3, padx=10).pack(anchor="w", pady=(P(6), 0))
        # 2. modal pokok
        self.step_head(body, 2, "Modal pokok", COL_POKOK,
                       "Biaya yang HABIS tiap kali ada yang beli: bahan, barang, kemasan, ongkos per pesanan.")
        self.biz_items(body, "cost", "unit", COL_POKOK, "Modal per {u}", "+  Tambah modal", "Modal baru")
        # 3. biaya tetap
        self.step_head(body, 3, "Biaya tetap", COL_TETAP,
                       "Dibayar segitu-segitu saja {per}, laku sedikit atau banyak: sewa, gaji, listrik, iklan.")
        self.biz_items(body, "cost", "tetap", COL_TETAP, "Biaya tetap {per}", "+  Tambah biaya tetap", "Biaya tetap baru")
        # 4. pajak
        self.step_head(body, 4, "Pajak (boleh dilewati)", GREY, "Kalau usahamu tidak membayar pajak, biarkan 'Tanpa pajak'.")
        pf = tk.Frame(body, bg=t["card"])
        pf.pack(fill="x")
        self.seg_choice(pf, BIZ_TAX, m["tax_mode"], self.biz_set_tax).pack(side="left")
        if m["tax_mode"] != "none":
            v_tx = tk.StringVar(value=("%g" % m["tax"]).replace(".", ","))
            et = self.entry(pf, v_tx, width=6, justify="center")
            et.pack(side="left", padx=(P(10), P(4)), ipady=P(3))
            self.lbl(pf, "%", "n", "muted").pack(side="left")

            def on_tx(*_):
                s = v_tx.get().replace(",", ".")
                try:
                    m["tax"] = max(0.0, min(90.0, float(s))) if s not in ("", ".") else 0.0
                except ValueError:
                    return
                self.biz_changed()
            v_tx.trace_add("write", on_tx)
            self.wrap_label(body, "Pajak final UMKM biasanya 0,5% dari omzet (uang masuk)." if m["tax_mode"] == "final"
                            else "Pajak dihitung dari untung sebelum pajak, dan hanya kalau untung.", "s", "muted"
                            ).pack(fill="x", pady=(P(6), 0))
        self.biz_paint()

    def biz_items(self, body, kind, basis, color, title, add_text, new_name):
        t, P = self.t, self.px
        items = [i for i in (self.bm["inc"] if kind == "inc" else self.bm["cost"]) if i["b"] == basis]
        head = tk.Frame(body, bg=t["card"])
        head.pack(fill="x", pady=(P(10), P(6)))
        lt = self.biz_dyn(Fit(head, self, title, ["b", "n"], t["text"], t["card"]), title)
        lt.pack(side="left", fill="x", expand=True)
        self.btn(head, add_text, lambda: self.biz_add(kind, basis, new_name), "ghost", font="s", pady=3,
                 padx=10).pack(side="right")
        if not items:
            self.lbl(body, "Belum ada. Klik tombol tambah di kanan.", "s", "muted").pack(anchor="w", pady=(0, P(6)))
        for it in items:
            self.biz_row(body, kind, it, color).pack(fill="x", pady=(0, P(10)))

    def biz_set_tax(self, mode):
        m = self.bm
        m["tax_mode"] = mode
        if mode != "none" and m["tax"] in (0, 0.5, 22.0):          # tarif bawaan menyesuaikan jenis pajak
            m["tax"] = 0.5 if mode == "final" else 22.0
        self.biz_changed()
        self.biz_build_editor()

    def biz_add(self, kind, basis, name=None):
        name = name or ("Pemasukan lain" if kind == "inc" else "Biaya baru")
        self.bm["inc" if kind == "inc" else "cost"].append({"n": name, "v": 0, "b": basis})
        self.bz["focus"] = self.bm["inc" if kind == "inc" else "cost"][-1]
        self.biz_changed()
        self.biz_build_editor()

    def biz_remove(self, kind, it):
        lst = self.bm["inc" if kind == "inc" else "cost"]
        for i, x in enumerate(lst):
            if x is it:
                del lst[i]
                break
        self.biz_changed()
        self.biz_build_editor()

    def biz_row(self, parent, kind, it, color):
        t, f, P = self.t, self.f, self.px
        box = tk.Frame(parent, bg=t["card"])
        top = tk.Frame(box, bg=t["card"])
        top.pack(fill="x")
        tk.Label(top, text="●", font=f["m"], fg=color, bg=t["card"]).pack(side="left")
        x = tk.Label(top, text="✕", font=f["n"], fg=t["muted"], bg=t["card"], cursor="hand2", padx=P(4))
        x.pack(side="right")
        x.bind("<Button-1>", lambda e: self.biz_remove(kind, it))
        x.bind("<Enter>", lambda e: x.config(fg=t["bad"]))
        x.bind("<Leave>", lambda e: x.config(fg=t["muted"]))
        v_n = tk.StringVar(value=it["n"])
        en = self.entry(top, v_n)
        en.pack(side="left", fill="x", expand=True, padx=(P(6), P(6)), ipady=P(3))

        def on_name(*_):
            it["n"] = v_n.get()
            self.biz_changed()
        v_n.trace_add("write", on_name)
        if self.bz.get("focus") is it:
            self.bz["focus"] = None
            en.after_idle(lambda: (en.focus_set(), en.select_range(0, "end")))

        def set_v(v):
            it["v"] = v
            self.biz_changed()
        self.biz_pair(box, it["v"], set_v, self.biz_smax).pack(fill="x", pady=(P(4), 0))
        tot = self.lbl(box, "", "s", "muted")
        tot.pack(anchor="w", padx=(P(2), 0))
        self.bz["rows"].append(dict(it=it, tot=tot))
        return box

    # -- rincian hitungan (dengan rumus yang mudah dibaca)
    def biz_build_calc(self, body):
        t, f, P = self.t, self.f, self.px
        g = tk.Frame(body, bg=t["card"])
        g.pack(fill="x")
        g.grid_columnconfigure(1, weight=1)
        spec = (("omzet", "Uang masuk", "harga jual × jumlah terjual", "b"),
                ("pokok", "−  Modal pokok", "bahan/barang yang habis tiap jual", "n"),
                ("kotor", "=  Laba kotor", "uang masuk − modal pokok", "b"),
                ("ops", "−  Biaya tetap", "sewa, gaji, listrik, dll", "n"),
                ("ebt", "=  Untung sebelum pajak", "laba kotor − biaya tetap", "b"),
                ("pajak", "−  Pajak", "", "n"),
                ("bersih", "=  Untung bersih", "yang benar-benar tersisa", "m"))
        r = 0
        for key, label, how, fk in spec:
            if key in ("kotor", "ebt", "bersih"):
                tk.Frame(g, height=1, bg=t["line"]).grid(row=r, column=0, columnspan=3, sticky="ew", pady=(P(4), 0))
                r += 1
            lb = Fit(g, self, label, [fk, "n"], t["text"] if fk != "n" else t["muted"], t["card"])
            lb.grid(row=r, column=0, sticky="w", pady=P(4))
            hw = Fit(g, self, how, ["s"], t["muted"], t["card"])
            hw.grid(row=r, column=1, sticky="ew", padx=(P(10), P(10)))
            a = tk.Label(g, text="", font=f[fk], fg=t["text"], bg=t["card"], anchor="e")
            a.grid(row=r, column=2, sticky="e")
            self.bz["calc"][key] = (lb, hw, a)
            r += 1
        tk.Frame(g, height=1, bg=t["line"]).grid(row=r, column=0, columnspan=3, sticky="ew", pady=(P(10), P(4)))
        r += 1
        self.lbl(g, "Per satuan", "s", "muted").grid(row=r, column=0, sticky="w", pady=(0, P(2)))
        r += 1
        for key, label in (("p", "Harga jual per {u}"), ("vc", "Modal per {u}"), ("gp", "Laba kotor per {u}")):
            lb = self.biz_dyn(Fit(g, self, label, ["n"], t["muted"], t["card"]), label)
            lb.grid(row=r, column=0, columnspan=2, sticky="ew", pady=P(2))
            v = self.lbl(g, "", "b")
            v.grid(row=r, column=2, sticky="e")
            self.bz["calc"][key] = (lb, None, v)
            r += 1
        tk.Frame(g, height=1, bg=t["line"]).grid(row=r, column=0, columnspan=3, sticky="ew", pady=(P(10), P(4)))
        r += 1
        self.lbl(g, "Dari tiap Rp 100 uang masuk", "s", "muted").grid(row=r, column=0, columnspan=3, sticky="w",
                                                                         pady=(0, P(2)))
        r += 1
        for key, label in (("m_kotor", "jadi laba kotor"), ("r_biaya", "habis untuk semua biaya"),
                           ("m_bersih", "jadi untung bersih"), ("roi", "Imbal hasil (untung ÷ semua biaya)")):
            lb = Fit(g, self, label, ["n"], t["muted"], t["card"])
            lb.grid(row=r, column=0, columnspan=2, sticky="ew", pady=P(2))
            v = self.lbl(g, "", "b")
            v.grid(row=r, column=2, sticky="e")
            self.bz["calc"][key] = (lb, None, v)
            r += 1

    # -- target
    def biz_build_target(self, body):
        t, f, P = self.t, self.f, self.px
        bp = self.bz["bep"]
        self.wrap_label(body, "Ketik untung bersih yang kamu mau. Aplikasi menghitung berapa yang harus terjual, atau "
                              "berapa harga minimalnya.", "s", "muted").pack(fill="x")
        self.lbl(body, "TARGET UNTUNG BERSIH  (Rp)", "s", "muted").pack(anchor="w", pady=(P(8), 0))
        v_tg = tk.StringVar(value=num(self.bm["target"]) if self.bm["target"] else "")
        self.money_entry(body, v_tg).pack(fill="x", pady=(P(3), P(8)), ipady=P(6))

        def on_tg(*_):
            self.bm["target"] = parse_money(v_tg.get())
            self.biz_changed()
        v_tg.trace_add("write", on_tg)

        def kv(key, label):
            r = tk.Frame(body, bg=t["card"])
            r.pack(fill="x", pady=P(3))
            lb = self.biz_dyn(Fit(r, self, label, ["n"], t["muted"], t["card"]), label)
            lb.pack(side="left", fill="x", expand=True)
            v = self.lbl(r, "", "b")
            v.pack(side="right")
            bp[key] = v
        kv("t_units", "Yang harus terjual {per}")
        kv("t_price", "atau harga minimal per {u}")
        bp["gap"] = self.wrap_label(body, "", "s", "muted")
        bp["gap"].pack(fill="x", pady=(P(4), 0))

    # -- isi semua angka (dipanggil tiap ada perubahan)
    def biz_paint(self):
        bz = self.bz
        if not bz or not bz.get("ready") or self.page != "bisnis" or not bz["root"].winfo_exists():
            return
        t, c, m = self.t, self.bc, self.bm
        q, u, per, M = c["q"], self.biz_unit(), self.biz_per(), self.bal
        pc = lambda x: ("%.1f" % (x * 100)).replace(".", ",") + "%"
        # teks dinamis (memuat satuan / periode)
        for lb, fmt in bz["dyn"]:
            if lb.winfo_exists():
                txt = fmt.format(u=u, per=per)
                if hasattr(lb, "fit"):
                    self.fit_set(lb, txt)
                else:
                    lb.config(text=txt)
        # kesimpulan
        say = biz_say(c, m, M)
        col = {"good": t["good"], "bad": t["bad"], "muted": t["muted"]}[say["tone"]]
        v = bz["v"]
        v["stripe"].config(bg=col)
        self.fit_set(v["head"], say["head"], col)
        v["sub"].config(text=say["sub"])
        v["tips"].config(text="\n".join("•  " + x for x in say["tips"]))
        self.fit_set(v["in"], M(c["omzet"]))
        self.fit_set(v["out"], M(c["biaya"] + c["pajak"]))
        self.fit_set(v["net"], self.amt(c["bersih"], "+" if c["bersih"] > 0 else ""), col)
        # baris isian: total per item
        for r in bz["rows"]:
            it = r["it"]
            if it["b"] == "unit" and q > 1 and it["v"]:
                r["tot"].config(text=f"{M(it['v'])} × {num(q)} {u} = {M(it['v'] * q)}")
            else:
                r["tot"].config(text="")
        # rincian
        cal = bz["calc"]
        mode, rate = c["mode"], ("%g" % (c["rate"] * 100)).replace(".", ",")
        how = {"none": "tidak dipakai", "final": f"{rate}% × uang masuk", "umum": f"{rate}% × untung"}[mode]
        self.fit_set(cal["pajak"][1], how)
        vals = {"omzet": c["omzet"], "pokok": c["pokok"], "kotor": c["kotor"], "ops": c["ops"], "ebt": c["ebt"],
                "pajak": c["pajak"], "bersih": c["bersih"]}
        for key, val in vals.items():
            fg = t["text"]
            if key in ("kotor", "ebt", "bersih"):
                fg = t["good"] if val > 0 else t["bad"] if val < 0 else t["text"]
            cal[key][2].config(text=M(val), fg=fg)
        cal["p"][2].config(text=M(c["p"]))
        cal["vc"][2].config(text=M(c["vc"]))
        cal["gp"][2].config(text=M(c["p"] - c["vc"]), fg=t["good"] if c["p"] - c["vc"] > 0 else t["bad"])
        for key in ("m_kotor", "r_biaya", "m_bersih", "roi"):
            x = c[key]
            fg = t["text"] if key in ("r_biaya",) else (t["good"] if x > 0 else t["bad"] if x < 0 else t["text"])
            cal[key][2].config(text=("Rp " + ("%.0f" % (x * 100)) if key != "roi" else pc(x)), fg=fg)
        # target
        bp = bz["bep"]
        if c["target"] > 0:
            bp["t_units"].config(text="tidak mungkin" if c["t_units"] is None else f"{num(c['t_units'])} {u}")
            bp["t_price"].config(text=M(math.ceil(c["t_price"] - 1e-9)))
            gap = c["target"] - c["bersih"]
            bp["gap"].config(text="" if self.hide else (f"Sekarang masih kurang {M(gap)} dari target." if gap > 0 else
                                                        f"Sudah melampaui target sebesar {M(-gap)}."))
        else:
            bp["t_units"].config(text="—")
            bp["t_price"].config(text="—")
            bp["gap"].config(text="Isi target di atas untuk melihat hitungannya.")
        bz["split"].set_calc(c, u)
        bz["meter"].set_calc(c, u)
        self.sk.set_calc(c, u)

    # -- skenario
    def biz_switch(self, bid):
        self.biz_flush()
        self.cfg["biz"] = bid
        self.save_cfg()
        self.show("bisnis")

    def biz_new_dialog(self):
        t, P = self.t, self.px
        d = self.modal("Skenario baru")
        self.lbl(d, "Skenario baru", "h2", bg=t["card"]).pack(anchor="w", pady=(0, P(12)))
        self.lbl(d, "NAMA", "s", "muted", bg=t["card"]).pack(anchor="w")
        v_name = tk.StringVar()
        e = self.entry(d, v_name)
        e.pack(fill="x", pady=(3, P(10)), ipady=P(7))
        e.focus_set()
        self.lbl(d, "MULAI DARI", "s", "muted", bg=t["card"]).pack(anchor="w")
        v_t = tk.StringVar(value=BIZ_TEMPLATES[0][1])
        self.combo(d, v_t, [x[1] for x in BIZ_TEMPLATES]).pack(fill="x", pady=(3, P(6)))
        self.wrap_label(d, "Contoh hanya angka karangan untuk belajar. Ganti semua angkanya dengan data usahamu.", "s",
                        "muted").pack(fill="x", pady=(0, P(14)))

        def save():
            key = [k for k, n in BIZ_TEMPLATES if n == v_t.get()][0]
            name = v_name.get().strip() or dict(BIZ_TEMPLATES)[key].replace(" (contoh)", "")
            self.biz_flush()
            bid = self.db.biz_save(None, name, biz_template(key))
            d.destroy()
            self.biz_switch(bid)
        row = tk.Frame(d, bg=t["card"])
        row.pack(fill="x", side="bottom")
        self.btn(row, "Buat", save, "primary", pady=10).pack(side="left", fill="x", expand=True)
        self.btn(row, "Batal", d.destroy, "ghost", pady=10).pack(side="left", padx=(P(8), 0))
        d.bind("<Return>", lambda ev: save())
        self.show_modal(d, 420)

    def biz_rename(self):
        t, P = self.t, self.px
        d = self.modal("Ubah nama skenario")
        self.lbl(d, "Ubah nama", "h2", bg=t["card"]).pack(anchor="w", pady=(0, P(12)))
        v_name = tk.StringVar(value=self.biz_name)
        e = self.entry(d, v_name)
        e.pack(fill="x", pady=(0, P(14)), ipady=P(7))
        e.focus_set()
        e.select_range(0, "end")

        def save():
            name = v_name.get().strip()
            if not name:
                return
            self.biz_name = name
            self.biz_flush()
            d.destroy()
            self.show("bisnis")
        row = tk.Frame(d, bg=t["card"])
        row.pack(fill="x", side="bottom")
        self.btn(row, "Simpan", save, "primary", pady=10).pack(side="left", fill="x", expand=True)
        self.btn(row, "Batal", d.destroy, "ghost", pady=10).pack(side="left", padx=(P(8), 0))
        d.bind("<Return>", lambda ev: save())
        self.show_modal(d, 360)

    def biz_duplicate(self):
        self.biz_flush()
        bid = self.db.biz_save(None, self.biz_name + " (salinan)", json.loads(json.dumps(self.bm)))
        self.biz_switch(bid)

    def biz_delete_cur(self):
        if not messagebox.askyesno("Hapus skenario", f"Hapus skenario '{self.biz_name}'?\nIni tidak bisa dibatalkan.",
                                   parent=self):
            return
        if self._bj:
            self.after_cancel(self._bj)
            self._bj = None
        self.db.biz_delete(self.biz_id)
        self.cfg["biz"] = None
        self.show("bisnis")

    def biz_export(self):
        self.biz_flush()
        c, m = self.bc, self.bm
        p = filedialog.asksaveasfilename(parent=self, defaultextension=".csv",
                                         initialfile=f"bisnis-{self.biz_name}.csv".replace("/", "-"),
                                         filetypes=[("CSV", "*.csv")])
        if not p:
            return
        q = c["q"]
        with open(p, "w", newline="", encoding="utf-8-sig") as fh:
            wr = csv.writer(fh)
            wr.writerow(["Skenario", self.biz_name])
            wr.writerow(["Satuan", m["unit"]])
            wr.writerow(["Periode", m["per"]])
            wr.writerow(["Jumlah terjual", q])
            wr.writerow([])
            wr.writerow(["Bagian", "Uraian", "Dasar", "Nilai per satuan / tetap", "Total"])
            for it in m["inc"]:
                wr.writerow(["Uang masuk", it["n"], "per satuan" if it["b"] == "unit" else "tetap", it["v"],
                             it["v"] * (q if it["b"] == "unit" else 1)])
            for it in m["cost"]:
                wr.writerow(["Modal pokok" if it["b"] == "unit" else "Biaya tetap", it["n"],
                             "per satuan" if it["b"] == "unit" else "tetap", it["v"],
                             it["v"] * (q if it["b"] == "unit" else 1)])
            wr.writerow([])
            for lab, v in (("Uang masuk", c["omzet"]), ("Modal pokok", c["pokok"]), ("Laba kotor", c["kotor"]),
                           ("Biaya tetap", c["ops"]), ("Untung sebelum pajak", c["ebt"]), ("Pajak", c["pajak"]),
                           ("Untung bersih", c["bersih"])):
                wr.writerow(["Ringkasan", lab, "", "", v])
            wr.writerow(["Rasio", "Margin laba kotor (%)", "", "", round(c["m_kotor"] * 100, 2)])
            wr.writerow(["Rasio", "Margin untung bersih (%)", "", "", round(c["m_bersih"] * 100, 2)])
            wr.writerow(["Rasio", "Imbal hasil (%)", "", "", round(c["roi"] * 100, 2)])
            wr.writerow(["Titik aman", "Jumlah terjual minimum", "", "", "" if c["bep"] is None else c["bep"]])
            wr.writerow(["Titik aman", "Harga minimum per satuan", "", "", math.ceil(c["bep_price"] - 1e-9)])
        messagebox.showinfo("Selesai", f"Tersimpan di:\n{p}", parent=self)

    # ---- kerangka
    def build(self):
        keep = self.snap_form()
        for w in self.winfo_children():
            w.destroy()
        self._toast = None
        self.bgs, self.charts, self.headers = weakref.WeakSet(), [], []
        self.style_ttk()
        self.configure(bg=self.t["bg"])
        self.side = Side(self, self)
        self.side.pack(side="left", fill="y")
        self.body = Bg(self, self)
        self.body.pack(side="left", fill="both", expand=True)
        self.show(self.page, keep=keep)
        self.wp_dirty(80)

    def update_side(self):
        self.total = sum(r["bal"] for r in self.db.balances())
        if getattr(self, "side", None) is not None and self.side.winfo_exists():
            self.side.redraw()

    def show(self, page, keep=None):
        if self._bj:
            self.biz_flush()
        self.page = page
        self.fold_hook = None
        for w in self.body.winfo_children():
            w.destroy()
        self.charts = [c for c in self.charts if c.winfo_exists()]
        self.headers = [h for h in self.headers if h.winfo_exists()]
        self.edit_id = None
        self.update_side()
        self.pg = Page(self.body, self)
        self.pg.pack(fill="both", expand=True)
        getattr(self, "page_" + page)()
        if keep and page == "transaksi":
            self.restore_form(keep)
        self.wp_dirty(60)

    def wrap(self):
        w = Bg(self.pg.inner, self)
        w.pack(fill="both", expand=True, padx=self.px(28), pady=self.px(22))
        return w

    def header(self, parent, title, sub, month_nav=True):
        t = self.t
        h = Header(parent, self, title, sub)
        h.grid(row=0, column=0, columnspan=10, sticky="ew", pady=(0, self.px(16)))
        if month_nav:
            h.add(self.btn(h, "Bulan ini", self.this_month, "ghost", font="s"), 10)
            h.add(self.btn(h, "›", lambda: self.shift_month(1), "ghost", padx=14), 4)
            self.mn_lbl = tk.Label(h, text=self.month_text(), font=self.f["m"], fg=t["text"], bg=t["card"],
                                   width=16, pady=self.px(7), highlightthickness=1, highlightbackground=t["line"])
            h.add(self.mn_lbl, 4)
            h.add(self.btn(h, "‹", lambda: self.shift_month(-1), "ghost", padx=14), 0)
        return h

    def month_text(self):
        return f"{MONTHS[self.ym[1] - 1]} {self.ym[0]}"

    def shift_month(self, dm):
        m = self.ym[1] - 1 + dm
        self.ym = (self.ym[0] + m // 12, m % 12 + 1)
        self.show(self.page)

    def this_month(self):
        d = date.today()
        self.ym = (d.year, d.month)
        self.show(self.page)

    def pick_month(self, m):
        self.ym = (self.ym[0], m)
        self.show(self.page)


    # ---- dashboard
    def page_dashboard(self):
        t, P = self.t, self.px
        y, m = self.ym
        ym = f"{y:04d}-{m:02d}"
        w = self.wrap()
        w.grid_columnconfigure(0, weight=3, uniform="a")
        w.grid_columnconfigure(1, weight=2, uniform="a")
        w.grid_rowconfigure(2, weight=1)
        hd = self.header(w, "Dashboard", "Ringkasan keuanganmu")
        it_, wd_, _ = hd.items[-1]
        hd.items[-1] = (it_, wd_, 12)                    # jarak antara navigasi bulan dan tombol saldo
        hd.add(self.btn(hd, "Tampilkan angka" if self.hide else "Sembunyikan angka", self.toggle_hide, "ghost",
                        font="s"), 14)
        bals = self.db.balances()
        inc, out = self.db.month_totals(ym)
        stats = Bg(w, self)
        stats.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, P(14)))
        data = [("Total saldo", self.bal(sum(b["bal"] for b in bals)), t["accent"], "semua rekening"),
                ("Pemasukan", self.amt(inc), t["good"], MONTHS[m - 1]),
                ("Pengeluaran", self.amt(out), t["bad"], MONTHS[m - 1]),
                ("Selisih bulan ini", self.amt(inc - out, "+" if inc - out >= 0 else ""),
                 t["good"] if inc - out >= 0 else t["bad"], "masuk - keluar")]
        for i, (title, val, col, sub) in enumerate(data):
            stats.grid_columnconfigure(i, weight=1, uniform="s")
            c = tk.Frame(stats, bg=t["card"], highlightthickness=1, highlightbackground=t["line"])
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else P(7), 0 if i == 3 else P(7)))
            tk.Frame(c, height=P(3), bg=col).pack(fill="x")
            inner = tk.Frame(c, bg=t["card"], padx=P(16), pady=P(12))
            inner.pack(fill="both", expand=True)
            Fit(inner, self, title.upper(), ["s"], t["muted"], t["card"]).pack(fill="x")
            Fit(inner, self, val, ["big", "h2", "m", "b", "n"], t["text"], t["card"]).pack(fill="x", pady=(2, 0))
            Fit(inner, self, sub, ["s"], t["muted"], t["card"]).pack(fill="x")
        # diagram batang
        c1, b1 = self.fold_card(w, "d_bar", f"Pemasukan vs pengeluaran {y}")
        c1.grid(row=2, column=0, sticky="nsew", padx=(0, P(7)), pady=(0, P(14)))
        for txt, col in (("Keluar", t["bad"]), ("Masuk", t["good"])):
            self.lbl(c1.head, txt, "s", "muted").pack(side="right", padx=(P(4), 0))
            tk.Label(c1.head, text="●", fg=col, bg=t["card"], font=self.f["s"]).pack(side="right", padx=(P(10), 0))
        bc = BarChart(b1, self, on_pick=self.pick_month)
        bc.pack(fill="both", expand=True)
        ins, exs = self.db.year_series(y)
        self.after(30, lambda: bc.set_data(ins, exs, m - 1, y))
        # diagram donat
        c2, b2 = self.fold_card(w, "d_donut", f"Pengeluaran per kategori · {MONTHS[m - 1]}")
        c2.grid(row=2, column=1, sticky="nsew", padx=(P(7), 0), pady=(0, P(14)))
        dn = Donut(b2, self)
        dn.pack(fill="both", expand=True)
        cs = self.db.cat_sums(ym)
        self.after(30, lambda: dn.set_data(cs))
        # bawah
        c3, b3 = self.fold_card(w, "d_acc", "Rekening", 14)
        c3.grid(row=3, column=0, sticky="nsew", padx=(0, P(7)))
        for b in bals[:4]:
            r = tk.Frame(b3, bg=t["card"])
            r.pack(fill="x", pady=P(3))
            tk.Label(r, text="●", fg=b["color"], bg=t["card"], font=self.f["n"]).pack(side="left")
            self.lbl(r, " " + b["name"], "n").pack(side="left")
            self.lbl(r, "  " + b["kind"], "s", "muted").pack(side="left")
            self.lbl(r, self.bal(b["bal"]), "b", "text" if b["bal"] >= 0 and not self.hide else "bad" if b["bal"] < 0 and not self.hide else "text").pack(side="right")
        if len(bals) > 4:
            self.lbl(b3, f"+{len(bals) - 4} rekening lainnya", "s", "muted").pack(anchor="w", pady=(P(4), 0))
        c4, b4 = self.fold_card(w, "d_rec", "Transaksi terakhir", 14)
        c4.grid(row=3, column=1, sticky="nsew", padx=(P(7), 0))
        rec = self.db.recent(4)
        if not rec:
            self.lbl(b4, "Belum ada transaksi. Catat di menu Transaksi.", "n", "muted").pack(anchor="w")
        for r in rec:
            row = tk.Frame(b4, bg=t["card"])
            row.pack(fill="x", pady=P(3))
            d = date.fromisoformat(r["day"])
            self.lbl(row, fmt_date(d), "s", "muted", width=7, anchor="w").pack(side="left")
            self.lbl(row, self.tx_title(r), "n").pack(side="left")
            sign, col = self.tx_sign(r)
            self.lbl(row, self.amt(r["amount"], sign), "b", col).pack(side="right")
        rows = {2: (c1, c2), 3: (c3, c4)}

        def hook():
            for row, cs_ in rows.items():
                w.grid_rowconfigure(row, weight=1 if row == 2 and any(not self.folded(c.fkey) for c in cs_) else 0)
                for c in cs_:
                    c.grid_configure(sticky="new" if self.folded(c.fkey) else "nsew")
        self.fold_hook = hook
        hook()

    @staticmethod
    def tx_title(r):
        if r["kind"] == "tf":
            return f"{r['an']} → {r['bn']}"
        return r["cat"] or "Lainnya"

    @staticmethod
    def tx_sign(r):
        return {"in": ("+ ", "good"), "out": ("− ", "bad"), "tf": ("⇄ ", "muted")}[r["kind"]]

    # ---- transaksi
    def page_transaksi(self):
        P = self.px
        w = self.wrap()
        w.grid_columnconfigure(0, minsize=P(372))
        w.grid_columnconfigure(1, weight=1)
        w.grid_rowconfigure(1, weight=1)
        self.header(w, "Transaksi", "Catat uang masuk, keluar, atau pindah rekening")
        left, lb = self.fold_card(w, "t_form", "Catat transaksi", 18)
        left.grid(row=1, column=0, sticky="new")
        right, rb = self.fold_card(w, "t_list", "Riwayat bulan ini", 16)
        right.grid(row=1, column=1, sticky="nsew", padx=(P(16), 0))
        self.build_form(lb)
        self.build_list(rb)
        self.reload_list()

        def hook():
            lf, rf = self.folded("t_form"), self.folded("t_list")
            w.grid_columnconfigure(0, minsize=0 if lf else P(372))
            w.grid_rowconfigure(1, weight=0 if rf else 1)
            right.grid_configure(sticky="new" if rf else "nsew")
        self.fold_hook = hook
        hook()

    def build_form(self, p):
        t, f, P = self.t, self.f, self.px
        self.accs = self.db.balances()
        self.acc_names = [f"{a['name']}  ·  {a['kind']}" for a in self.accs]
        self.fkind = "out"
        self.fdate = date.today()
        self.v_amt, self.v_acc, self.v_acc2 = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.v_cat, self.v_note = tk.StringVar(), tk.StringVar()
        seg = tk.Frame(p, bg=t["card2"], padx=3, pady=3)
        seg.pack(fill="x")
        self.seg = {}
        for k, txt in (("out", "Pengeluaran"), ("in", "Pemasukan"), ("tf", "Transfer")):
            lb = tk.Label(seg, text=txt, font=f["b"], pady=P(7), cursor="hand2")
            lb.pack(side="left", expand=True, fill="x")
            lb.bind("<Button-1>", lambda e, kk=k: self.set_kind(kk))
            self.seg[k] = lb
        self.form = tk.Frame(p, bg=t["card"])
        self.form.pack(fill="x", pady=(P(14), 0))
        fr = self.form
        self.l_amt = self.lbl(fr, "JUMLAH", "s", "muted")
        self.l_amt.pack(anchor="w")
        ar = tk.Frame(fr, bg=t["card2"], highlightthickness=1, highlightbackground=t["line"])
        ar.pack(fill="x", pady=(3, 0))
        self.lbl(ar, " Rp", "b", "muted", bg=t["card2"]).pack(side="left", padx=(P(8), 0))
        self.amt_hint = self.lbl(fr, "", "s", "muted")
        self.amt_e = self.money_entry(ar, self.v_amt, "h2", hint=self.amt_hint)
        self.amt_e.config(highlightthickness=0)
        self.amt_e.pack(side="left", fill="x", expand=True, ipady=P(8), padx=P(6))
        self.amt_hint.pack(anchor="w", pady=(2, P(8)))
        self.l_acc = self.lbl(fr, "REKENING", "s", "muted")
        self.l_acc.pack(anchor="w")
        self.acc_cb = self.combo(fr, self.v_acc, self.acc_names)
        self.acc_cb.pack(fill="x", pady=(3, P(10)))
        self.f_acc2 = tk.Frame(fr, bg=t["card"])
        self.lbl(self.f_acc2, "KE REKENING", "s", "muted").pack(anchor="w")
        self.acc2_cb = self.combo(self.f_acc2, self.v_acc2, self.acc_names)
        self.acc2_cb.pack(fill="x", pady=(3, P(10)))
        self.f_cat = tk.Frame(fr, bg=t["card"])
        self.lbl(self.f_cat, "KATEGORI  (bisa ketik baru)", "s", "muted").pack(anchor="w")
        self.cat_cb = self.combo(self.f_cat, self.v_cat, [], readonly=False)
        self.cat_cb.pack(fill="x", pady=(3, P(10)))
        self.f_date = tk.Frame(fr, bg=t["card"])
        self.lbl(self.f_date, "TANGGAL", "s", "muted").pack(anchor="w")
        dr = tk.Frame(self.f_date, bg=t["card"])
        dr.pack(fill="x", pady=(3, P(10)))
        self.date_btn = tk.Label(dr, text="", font=f["n"], bg=t["card2"], fg=t["text"], anchor="w",
                                 padx=P(12), pady=P(8), cursor="hand2", highlightthickness=1,
                                 highlightbackground=t["line"])
        self.date_btn.pack(side="left", fill="x", expand=True)
        self.date_btn.bind("<Button-1>", lambda e: self.open_cal())
        self.btn(dr, "Hari ini", lambda: self.set_date(date.today()), "ghost", font="s", pady=8,
                 padx=10).pack(side="left", padx=(P(6), 0))
        self.btn(dr, "Kemarin", lambda: self.set_date(date.today() - timedelta(days=1)), "ghost",
                 font="s", pady=8, padx=10).pack(side="left", padx=(P(6), 0))
        self.f_note = tk.Frame(fr, bg=t["card"])
        self.lbl(self.f_note, "CATATAN  (opsional)", "s", "muted").pack(anchor="w")
        ne = self.entry(self.f_note, self.v_note)
        ne.pack(fill="x", pady=(3, P(14)), ipady=P(7))
        self.f_btn = tk.Frame(fr, bg=t["card"])
        self.save_btn = self.btn(self.f_btn, "Simpan transaksi", self.save_tx, "primary", pady=11)
        self.save_btn.pack(side="left", fill="x", expand=True)
        self.cancel_btn = self.btn(self.f_btn, "Batal", self.cancel_edit, "ghost", pady=11)
        self.msg = self.lbl(p, "", "s", "good")
        self.msg.pack(anchor="w", pady=(P(8), 0))
        self.amt_e.bind("<Return>", lambda e: self.save_tx())
        ne.bind("<Return>", lambda e: self.save_tx())
        if self.accs:
            self.acc_cb.current(0)
            self.acc2_cb.current(1 if len(self.accs) > 1 else 0)
        self.set_kind("out")
        self.set_date(self.fdate)
        self.amt_e.focus_set()

    def snap_form(self):
        """Simpan isi form (mis. saat zoom / ganti tema membangun ulang tampilan) agar ketikan tidak hilang."""
        try:
            if self.page != "transaksi" or not self.acc_cb.winfo_exists():
                return None
            return dict(kind=self.fkind, amt=self.v_amt.get(), note=self.v_note.get(), cat=self.v_cat.get(),
                        acc=self.acc_cb.current(), acc2=self.acc2_cb.current(), day=self.fdate, edit=self.edit_id)
        except (tk.TclError, AttributeError):
            return None

    def restore_form(self, k):
        try:
            self.set_kind(k["kind"])
            self.v_amt.set(k["amt"])
            self.v_note.set(k["note"])
            self.v_cat.set(k["cat"])
            if 0 <= k["acc"] < len(self.accs):
                self.acc_cb.current(k["acc"])
            if 0 <= k["acc2"] < len(self.accs):
                self.acc2_cb.current(k["acc2"])
            self.set_date(k["day"])
            if k["edit"]:
                self.edit_id = k["edit"]
                self.save_btn.config(text="Perbarui transaksi")
                self.cancel_btn.pack(side="left", padx=(self.px(8), 0))
        except (tk.TclError, AttributeError):
            pass

    def set_kind(self, k):
        t = self.t
        self.fkind = k
        for kk, lb in self.seg.items():
            on = kk == k
            col = {"out": t["bad"], "in": t["good"], "tf": t["accent"]}[kk]
            lb.config(bg=col if on else t["card2"], fg=on_color(col) if on else t["muted"])
        for fr in (self.f_acc2, self.f_cat, self.f_date, self.f_note, self.f_btn):
            fr.pack_forget()
        self.l_acc.config(text="DARI REKENING" if k == "tf" else
                          ("MASUK KE REKENING" if k == "in" else "BAYAR DARI REKENING"))
        if k == "tf":
            self.f_acc2.pack(fill="x")
        else:
            self.cat_cb.config(values=self.db.categories(k))
            if self.v_cat.get() not in self.db.categories(k):
                self.v_cat.set("")
            self.f_cat.pack(fill="x")
        self.f_date.pack(fill="x")
        self.f_note.pack(fill="x")
        self.f_btn.pack(fill="x")

    def set_date(self, d):
        self.fdate = d
        self.date_btn.config(text="📅  " + fmt_date(d, True))

    def open_cal(self):
        CalendarPopup(self, self.date_btn, self.fdate, self.set_date)

    def flash(self, text, good=True):
        self.msg.config(text=text, fg=self.t["good"] if good else self.t["bad"])
        self.after(3000, lambda: self.msg.winfo_exists() and self.msg.config(text=""))

    def save_tx(self):
        amt = parse_money(self.v_amt.get())
        if not self.accs:
            return self.flash("Tambah rekening dulu di menu Rekening.", False)
        if amt <= 0:
            return self.flash("Isi jumlahnya dulu ya.", False)
        i = self.acc_cb.current()
        if i < 0:
            return self.flash("Pilih rekening dulu.", False)
        acc, acc2, k = self.accs[i]["id"], None, self.fkind
        if k == "tf":
            j = self.acc2_cb.current()
            if j < 0 or self.accs[j]["id"] == acc:
                return self.flash("Rekening asal dan tujuan harus berbeda.", False)
            acc2, cat = self.accs[j]["id"], "Transfer"
        else:
            cat = self.v_cat.get().strip() or "Lainnya"
        self.db.add_tx(self.fdate.isoformat(), k, amt, acc, acc2, cat, self.v_note.get().strip(),
                       self.edit_id)
        was_edit = bool(self.edit_id)
        self.ym = (self.fdate.year, self.fdate.month)
        self.mn_lbl.config(text=self.month_text())
        self.clear_form()
        self.reload_list()
        self.flash("Perubahan disimpan ✓" if was_edit else "Tersimpan ✓")

    def clear_form(self):
        self.edit_id = None
        self.v_amt.set("")
        self.v_note.set("")
        self.save_btn.config(text="Simpan transaksi")
        self.cancel_btn.pack_forget()
        self.amt_e.focus_set()

    def cancel_edit(self):
        self.clear_form()

    def build_list(self, p):
        t, P = self.t, self.px
        top = tk.Frame(p, bg=t["card"])
        top.pack(fill="x", pady=(0, P(8)))
        self.sum_lbl = self.lbl(top, "", "n", "muted")
        self.sum_lbl.pack(side="left")
        self.btn(top, "Hapus", self.del_selected, "danger", font="s", pady=6, padx=12).pack(side="right")
        self.btn(top, "Ubah", self.edit_selected, "ghost", font="s", pady=6, padx=12).pack(side="right",
                                                                                           padx=(0, P(6)))
        wrap = tk.Frame(p, bg=t["card"])
        wrap.pack(fill="both", expand=True)
        cols = ("tgl", "rek", "kat", "cat", "jml")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings", selectmode="browse", height=12)
        for c, txt, wd, an in (("tgl", "Tanggal", 84, "w"), ("rek", "Rekening", 112, "w"),
                               ("kat", "Kategori", 112, "w"), ("cat", "Catatan", 60, "w"),
                               ("jml", "Jumlah", 118, "e")):
            wd = int(wd * self.fs)
            self.tree.heading(c, text=txt, anchor=an)
            self.tree.column(c, width=wd, minwidth=wd if c != "cat" else 40, anchor=an,
                             stretch=(c == "cat"))
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.tag_configure("in", foreground=t["good"])
        self.tree.tag_configure("out", foreground=t["bad"])
        self.tree.tag_configure("tf", foreground=t["muted"])
        self.tree.bind("<Double-1>", lambda e: self.edit_selected())
        self.tree.bind("<Delete>", lambda e: self.del_selected())

    def reload_list(self):
        y, m = self.ym
        ym = f"{y:04d}-{m:02d}"
        self.tree.delete(*self.tree.get_children())
        rows = self.db.month_tx(ym)
        for r in rows:
            sign, _ = self.tx_sign(r)
            rek = f"{r['an']} → {r['bn']}" if r["kind"] == "tf" else r["an"]
            self.tree.insert("", "end", iid=str(r["id"]), tags=(r["kind"],),
                             values=(fmt_date(date.fromisoformat(r["day"])), rek,
                                     r["cat"] or "Lainnya", r["note"] or "", self.amt(r["amount"], sign)))
        inc, out = self.db.month_totals(ym)
        self.sum_lbl.config(text=f"{len(rows)} transaksi  ·  masuk {self.amt(inc)}  ·  keluar {self.amt(out)}")
        self.update_side()

    def selected_id(self):
        s = self.tree.selection()
        return int(s[0]) if s else None

    def edit_selected(self):
        tid = self.selected_id()
        if not tid:
            return self.flash("Pilih transaksi di daftar dulu.", False)
        r = self.db.get_tx(tid)
        if not r:
            return
        if self.folded("t_form"):
            self.cfg["fold"]["t_form"] = False
            self.show("transaksi")
            self.tree.selection_set(str(tid))
        self.set_kind(r["kind"])
        self.edit_id = tid
        self.v_amt.set(num(r["amount"]))
        self.v_note.set(r["note"] or "")
        self.v_cat.set(r["cat"] if r["kind"] != "tf" else "")
        ids = [a["id"] for a in self.accs]
        if r["acc"] in ids:
            self.acc_cb.current(ids.index(r["acc"]))
        if r["acc2"] in ids:
            self.acc2_cb.current(ids.index(r["acc2"]))
        self.set_date(date.fromisoformat(r["day"]))
        self.save_btn.config(text="Perbarui transaksi")
        self.cancel_btn.pack(side="left", padx=(self.px(8), 0))

    def del_selected(self):
        tid = self.selected_id()
        if not tid:
            return self.flash("Pilih transaksi di daftar dulu.", False)
        if messagebox.askyesno("Hapus transaksi", "Hapus transaksi ini?", parent=self):
            self.db.delete_tx(tid)
            if self.edit_id == tid:
                self.clear_form()
            self.reload_list()

    # ---- rekening
    def page_rekening(self):
        t, P = self.t, self.px
        w = self.wrap()
        w.grid_columnconfigure(0, weight=1)
        h = self.header(w, "Rekening", "Bank, tabungan, e-wallet, dan dompet tunaimu", month_nav=False)
        h.add(self.btn(h, "+  Rekening baru", lambda: self.account_dialog(), "primary"), 8)
        h.add(self.btn(h, "Pindah rekening", self.move_dialog, "ghost"), 8)
        h.add(self.btn(h, "Impor mutasi", self.import_dialog, "ghost"), 0)
        bals = self.db.balances()
        groups = {}
        for b in bals:
            groups.setdefault(b["kind"], []).append(b)
        order = [k for k in KINDS if k in groups] + [k for k in groups if k not in KINDS]
        for row, kind in enumerate(order, start=1):
            items = groups[kind]
            key = "r_" + kind
            sec = Bg(w, self)
            sec.grid(row=row, column=0, sticky="ew", pady=(0, P(12)))
            bar, parts, paint = self.fold_section(sec, key, f"{kind}  ·  {len(items)} rekening",
                                                  self.bal(sum(b["bal"] for b in items)))
            bar.pack(fill="x")
            grid = Bg(sec, self)
            cards = []
            for b in items:
                c = tk.Frame(grid, bg=t["card"], highlightthickness=1, highlightbackground=t["line"])
                tk.Frame(c, height=P(5), bg=b["color"]).pack(fill="x")
                inn = tk.Frame(c, bg=t["card"], padx=P(18), pady=P(14))
                inn.pack(fill="both", expand=True)
                self.lbl(inn, b["kind"].upper(), "s", "muted").pack(anchor="w")
                self.lbl(inn, b["name"], "h2").pack(anchor="w")
                self.lbl(inn, self.bal(b["bal"]), "big", "bad" if b["bal"] < 0 and not self.hide else "text").pack(anchor="w",
                                                                                          pady=(P(8), P(10)))
                br = tk.Frame(inn, bg=t["card"])
                br.pack(anchor="w")
                self.btn(br, "Ubah", lambda a=b: self.account_dialog(a), "ghost", font="s", pady=5,
                         padx=12).pack(side="left")
                self.btn(br, "Hapus", lambda a=b: self.del_account(a), "danger", font="s", pady=5,
                         padx=12).pack(side="left", padx=(P(6), 0))
                cards.append(c)

            def reflow(e=None, grid=grid, cards=cards):
                W = grid.winfo_width()
                cols = 3 if W >= P(900) else 2 if W >= P(580) else 1
                if getattr(grid, "ncols", 0) == cols:
                    return
                grid.ncols = cols
                for i in range(4):
                    grid.grid_columnconfigure(i, weight=1 if i < cols else 0, uniform="r" if i < cols else "")
                for i, c in enumerate(cards):
                    c.grid(row=i // cols, column=i % cols, sticky="nsew", padx=P(6), pady=P(6))
            grid.bind("<Configure>", reflow, add="+")
            reflow()

            def toggle(e=None, key=key, grid=grid, paint=paint):
                self.cfg["fold"][key] = not self.folded(key)
                self.save_cfg()
                paint()
                if self.folded(key):
                    grid.pack_forget()
                else:
                    grid.pack(fill="x", pady=(P(8), 0))
                self.after_idle(self._fold_changed)
            for wd in (bar,) + parts:
                wd.bind("<Button-1>", toggle)
            if not self.folded(key):
                grid.pack(fill="x", pady=(P(8), 0))

    def account_dialog(self, acc=None):
        t, P = self.t, self.px
        d = self.modal("Ubah rekening" if acc else "Rekening baru")
        v_name = tk.StringVar(value=acc["name"] if acc else "")
        v_kind = tk.StringVar(value=acc["kind"] if acc else KINDS[0])
        v_init = tk.StringVar(value=num(acc["init"]) if acc and acc["init"] else "")
        v_col = tk.StringVar(value=acc["color"] if acc else PALETTE[0])
        self.lbl(d, "Ubah rekening" if acc else "Rekening baru", "h2", bg=t["card"]).pack(anchor="w", pady=(0, P(12)))
        self.lbl(d, "NAMA  (mis. BCA, BRI, DANA, Tabungan Kuliah)", "s", "muted", bg=t["card"]).pack(anchor="w")
        e = self.entry(d, v_name)
        e.pack(fill="x", pady=(3, P(10)), ipady=P(7))
        e.focus_set()
        self.lbl(d, "JENIS", "s", "muted", bg=t["card"]).pack(anchor="w")
        self.combo(d, v_kind, KINDS).pack(fill="x", pady=(3, P(10)))
        self.lbl(d, "SALDO AWAL  (Rp)", "s", "muted", bg=t["card"]).pack(anchor="w")
        hint = self.lbl(d, "", "s", "muted", bg=t["card"])
        self.money_entry(d, v_init, hint=hint).pack(fill="x", pady=(3, 0), ipady=P(7))
        hint.pack(anchor="w", pady=(2, P(10)))
        self.lbl(d, "WARNA", "s", "muted", bg=t["card"]).pack(anchor="w")
        sw = tk.Frame(d, bg=t["card"])
        sw.pack(anchor="w", pady=(4, P(14)))
        boxes = []

        def paint():
            for b, c in boxes:
                b.config(highlightthickness=2 if c == v_col.get() else 0, highlightbackground=t["text"])

        def choose(c):
            v_col.set(c)
            paint()
        for c in PALETTE:
            b = tk.Frame(sw, width=P(26), height=P(26), bg=c, cursor="hand2", highlightcolor=t["text"])
            b.pack(side="left", padx=2)
            b.bind("<Button-1>", lambda ev, cc=c: choose(cc))
            boxes.append((b, c))
        paint()

        def save():
            name = v_name.get().strip()
            if not name:
                return messagebox.showwarning("Nama kosong", "Isi nama rekening dulu.", parent=d)
            self.db.save_account(acc["id"] if acc else None, name, v_kind.get(),
                                 parse_money(v_init.get()), v_col.get())
            d.destroy()
            self.show("rekening")
        row = tk.Frame(d, bg=t["card"])
        row.pack(fill="x", side="bottom")
        self.btn(row, "Simpan", save, "primary", pady=10).pack(side="left", fill="x", expand=True)
        self.btn(row, "Batal", d.destroy, "ghost", pady=10).pack(side="left", padx=(P(8), 0))
        d.bind("<Return>", lambda ev: save())
        self.show_modal(d, 400)

    def import_dialog(self):
        t, P = self.t, self.px
        accs = self.db.balances()
        d = self.modal("Impor mutasi")
        self.lbl(d, "Impor mutasi bank", "h2", bg=t["card"]).pack(anchor="w")
        self.lbl(d, "Unduh mutasi dari m-banking / internet banking / e-wallet dalam format CSV, lalu pilih "
                    "filenya di sini. Tanggal, jumlah, dan masuk/keluar dibaca otomatis. Boleh diimpor "
                    "berulang: transaksi yang sudah ada dilewati.", "s", "muted", bg=t["card"],
                 wraplength=self.wrapw(480), justify="left").pack(anchor="w", pady=(4, P(12)))
        self.lbl(d, "MASUKKAN KE REKENING", "s", "muted", bg=t["card"]).pack(anchor="w")
        v_acc = tk.StringVar(value=accs[0]["name"])
        self.combo(d, v_acc, [a["name"] for a in accs]).pack(fill="x", pady=(3, P(12)))
        st = {"rows": None, "path": ""}
        v_file = tk.StringVar(value="Belum ada file dipilih")
        info = self.lbl(d, "", "n", bg=t["card"], wraplength=self.wrapw(480), justify="left")
        go = self.btn(d, "Impor sekarang", lambda: None, "primary", pady=10)

        def choose():
            p = filedialog.askopenfilename(parent=d, filetypes=[("CSV / teks", "*.csv *.txt"), ("Semua", "*.*")])
            if not p:
                return
            try:
                rows, skip = parse_mutasi(p)
            except Exception as ex:
                st["rows"] = None
                v_file.set(os.path.basename(p))
                info.config(text=str(ex), fg=t["bad"])
                return
            st["rows"] = rows
            v_file.set(os.path.basename(p))
            masuk = sum(1 for r in rows if r["kind"] == "in")
            info.config(text=f"Terbaca {len(rows)} transaksi  ({masuk} masuk, {len(rows) - masuk} keluar)"
                             + (f"  ·  {skip} baris dilewati" if skip else ""), fg=t["good"])

        fr = tk.Frame(d, bg=t["card"])
        fr.pack(fill="x")
        self.btn(fr, "Pilih file CSV…", choose, "ghost").pack(side="left")
        self.lbl(fr, "  ", "n", bg=t["card"]).pack(side="left")
        self.lbl(fr, "", "s", "muted", bg=t["card"], textvariable=v_file).pack(side="left")
        info.pack(anchor="w", pady=(P(12), P(12)))

        def run():
            if not st["rows"]:
                return messagebox.showwarning("Belum siap", "Pilih file CSV yang valid dulu.", parent=d)
            acc = accs[[a["name"] for a in accs].index(v_acc.get())]["id"]
            added, dup = self.db.import_rows(acc, st["rows"])
            d.destroy()
            self.show("rekening")
            messagebox.showinfo("Selesai", f"{added} transaksi diimpor"
                                + (f", {dup} sudah ada (dilewati)." if dup else "."), parent=self)
        go._cmd = run
        go.pack(fill="x", side="bottom")
        self.btn(d, "Batal", d.destroy, "ghost", pady=8).pack(fill="x", side="bottom", pady=(0, P(8)))
        self.show_modal(d, 480)

    def move_dialog(self):
        t, P = self.t, self.px
        accs = self.db.balances()
        if len(accs) < 2:
            return messagebox.showinfo("Butuh dua rekening", "Buat rekening tujuan dulu (mis. bank barumu).",
                                       parent=self)
        names = [a["name"] for a in accs]
        d = self.modal("Pindah rekening")
        self.lbl(d, "Pindah rekening", "h2", bg=t["card"]).pack(anchor="w")
        self.lbl(d, "Ganti bank? Pindahkan seluruh riwayat dan saldo awal dari rekening lama ke rekening "
                    "baru tanpa input ulang. Total saldo tidak berubah.", "s", "muted", bg=t["card"],
                 wraplength=self.wrapw(440), justify="left").pack(anchor="w", pady=(4, P(12)))
        v1, v2, v_del = tk.StringVar(value=names[0]), tk.StringVar(value=names[1]), tk.BooleanVar(value=True)
        self.lbl(d, "DARI (REKENING LAMA)", "s", "muted", bg=t["card"]).pack(anchor="w")
        self.combo(d, v1, names).pack(fill="x", pady=(3, P(10)))
        self.lbl(d, "KE (REKENING BARU)", "s", "muted", bg=t["card"]).pack(anchor="w")
        self.combo(d, v2, names).pack(fill="x", pady=(3, P(10)))
        tk.Checkbutton(d, text="Hapus rekening lama setelah dipindah", variable=v_del, bg=t["card"],
                       fg=t["text"], selectcolor=t["card2"], activebackground=t["card"],
                       activeforeground=t["text"], font=self.f["n"], highlightthickness=0, bd=0
                       ).pack(anchor="w", pady=(2, P(10)))

        def run():
            if v1.get() == v2.get():
                return messagebox.showwarning("Sama", "Pilih dua rekening yang berbeda.", parent=d)
            src, dst = accs[names.index(v1.get())], accs[names.index(v2.get())]
            if not messagebox.askyesno("Pindahkan", f"Pindahkan semua dari “{src['name']}” ke “{dst['name']}”?",
                                       parent=d):
                return
            self.db.merge_account(src["id"], dst["id"], v_del.get())
            d.destroy()
            self.show("rekening")
        row = tk.Frame(d, bg=t["card"])
        row.pack(fill="x", side="bottom")
        self.btn(row, "Pindahkan", run, "primary", pady=10).pack(side="left", fill="x", expand=True)
        self.btn(row, "Batal", d.destroy, "ghost", pady=10).pack(side="left", padx=(P(8), 0))
        self.show_modal(d, 440)

    def del_account(self, a):
        n = self.db.tx_count(a["id"])
        extra = f"\n\n{n} transaksi di rekening ini ikut terhapus." if n else ""
        if len(self.db.balances()) <= 1:
            return messagebox.showinfo("Tidak bisa", "Minimal harus ada satu rekening.", parent=self)
        if messagebox.askyesno("Hapus rekening", f"Hapus rekening “{a['name']}”?{extra}", parent=self):
            self.db.delete_account(a["id"])
            self.show("rekening")


    # ---- pengaturan
    def pil_available(self):
        try:
            import importlib.util
            return importlib.util.find_spec("PIL") is not None
        except Exception:
            return False

    def slider(self, parent, label, lo, hi, val, on_move=None, on_release=None, fmt="{}", enabled=True):
        t, P = self.t, self.px
        box = tk.Frame(parent, bg=t["card"])
        top = tk.Frame(box, bg=t["card"])
        top.pack(fill="x")
        self.lbl(top, label, "n", "text" if enabled else "muted").pack(side="left")
        vl = self.lbl(top, fmt.format(int(val)), "b", "muted")
        vl.pack(side="right")
        sc = tk.Scale(box, from_=lo, to=hi, orient="horizontal", showvalue=False, resolution=1, bd=0,
                      highlightthickness=0, bg=t["card"], troughcolor=t["card2"], activebackground=t["accent"],
                      sliderrelief="flat", sliderlength=P(20), width=P(12), relief="flat",
                      state="normal" if enabled else "disabled")
        sc.set(int(val))
        sc.pack(fill="x", pady=(2, 0))

        def mv(v):
            vl.config(text=fmt.format(int(float(v))))
            if on_move:
                on_move(int(float(v)))
        sc.config(command=mv)
        if on_release:
            sc.bind("<ButtonRelease-1>", lambda e: on_release(int(sc.get())))
        return box

    def seg_choice(self, parent, options, current, cmd):
        """Pilihan ringkas bergaya segmen."""
        t, P = self.t, self.px
        seg = tk.Frame(parent, bg=t["card2"], padx=3, pady=3)
        for val, txt in options:
            on = val == current
            lb = tk.Label(seg, text=txt, font=self.f["b"] if on else self.f["n"], padx=P(12), pady=P(6),
                          cursor="hand2", bg=t["accent"] if on else t["card2"],
                          fg=on_color(t["accent"]) if on else t["muted"])
            lb.pack(side="left")
            lb.bind("<Button-1>", lambda e, v=val: cmd(v))
        return seg

    def page_pengaturan(self):
        t, f, P = self.t, self.f, self.px
        w = self.wrap()
        w.grid_columnconfigure(0, weight=1, uniform="p")
        w.grid_columnconfigure(1, weight=1, uniform="p")
        self.header(w, "Pengaturan", "Atur tampilan dan data sesukamu", month_nav=False)
        colL, colR = Bg(w, self), Bg(w, self)

        def place(e=None):
            narrow = w.winfo_width() < P(760)
            if getattr(w, "narrow", None) == narrow:
                return
            w.narrow = narrow
            if narrow:
                colL.grid(row=1, column=0, columnspan=2, sticky="new")
                colR.grid(row=2, column=0, columnspan=2, sticky="new")
            else:
                colL.grid(row=1, column=0, columnspan=1, sticky="new", padx=(0, P(8)))
                colR.grid(row=1, column=1, columnspan=1, sticky="new", padx=(P(8), 0))
                colR.grid_configure(row=1)
        w.bind("<Configure>", place, add="+")
        place()

        # --- tema & warna
        c1, b1 = self.fold_card(colL, "s_tema", "Tema & warna", 18)
        c1.pack(fill="x", pady=(0, P(14)))
        tr = tk.Frame(b1, bg=t["card"])
        tr.pack(anchor="w", pady=(0, P(4)))
        for i, name in enumerate(list(THEMES) + ["Kustom"]):
            th = THEMES.get(name) or resolve_theme({"theme": "Kustom", "custom": self.cfg.get("custom", {})})
            on = self.cfg["theme"] == name
            b = tk.Frame(tr, bg=th["bg"], cursor="hand2", highlightthickness=2,
                         highlightbackground=t["accent"] if on else t["line"], padx=P(10), pady=P(8))
            b.grid(row=i // 3, column=i % 3, padx=4, pady=4)
            tk.Label(b, text=name, font=f["b"], fg=th["text"], bg=th["bg"], cursor="hand2").pack()
            sw = tk.Frame(b, bg=th["bg"])
            sw.pack(pady=(4, 0))
            for col in (th["card"], th["accent"], th["good"], th["bad"]):
                tk.Frame(sw, width=P(14), height=P(14), bg=col).pack(side="left", padx=1)
            for wd in [b] + b.winfo_children():
                wd.bind("<Button-1>", lambda e, n=name: self.set_theme(n))
        self.lbl(b1, "Warna aksen", "b").pack(anchor="w", pady=(P(14), 0))
        ar = tk.Frame(b1, bg=t["card"])
        ar.pack(anchor="w", pady=(P(6), 0))
        for c in PALETTE + ["#e11d48", "#0ea5e9"]:
            on = t["accent"].lower() == c
            b = tk.Frame(ar, width=P(26), height=P(26), bg=c, cursor="hand2", highlightthickness=2 if on else 0,
                         highlightbackground=t["text"])
            b.pack(side="left", padx=2)
            b.bind("<Button-1>", lambda e, cc=c: self.set_accent(cc))
        br = tk.Frame(b1, bg=t["card"])
        br.pack(anchor="w", pady=(P(10), 0))
        self.btn(br, "Pilih warna lain…", lambda: self.pick_color("accent"), "ghost", font="s", pady=6).pack(side="left")
        self.btn(br, "Reset", lambda: self.set_accent(""), "ghost", font="s", pady=6).pack(side="left", padx=P(6))
        self.lbl(b1, "Warna kustom (otomatis memakai tema Kustom)", "b").pack(anchor="w", pady=(P(16), P(4)))
        for key, label in (("bg", "Latar"), ("card", "Kartu"), ("text", "Teks")):
            r = tk.Frame(b1, bg=t["card"])
            r.pack(fill="x", pady=2)
            tk.Frame(r, width=P(22), height=P(22), bg=t[key], highlightthickness=1,
                     highlightbackground=t["line"]).pack(side="left")
            self.lbl(r, "  " + label, "n").pack(side="left")
            self.btn(r, "Ubah", lambda k=key: self.pick_color(k), "ghost", font="s", pady=4, padx=12).pack(side="right")

        # --- wallpaper & transparansi
        c2, b2 = self.fold_card(colL, "s_wp", "Wallpaper & transparansi", 18)
        c2.pack(fill="x", pady=(0, P(14)))
        self.build_wp_settings(b2)

        # --- tampilan: zoom, huruf, sidebar
        c3, b3 = self.fold_card(colR, "s_view", "Tampilan", 18)
        c3.pack(fill="x", pady=(0, P(14)))
        self.lbl(b3, "Zoom", "b").pack(anchor="w")
        zr = tk.Frame(b3, bg=t["card"])
        zr.pack(anchor="w", pady=(P(6), P(12)))
        self.btn(zr, "−", lambda: self.zoom_by(-.1), "ghost", padx=16).pack(side="left")
        self.lbl(zr, f"  {int(round(self.zoom * 100))}%  ", "m").pack(side="left")
        self.btn(zr, "+", lambda: self.zoom_by(.1), "ghost", padx=16).pack(side="left")
        self.btn(zr, "100%", lambda: self.set_zoom(1.0), "ghost", font="s", pady=6).pack(side="left", padx=(P(10), 0))
        self.lbl(b3, "Pintasan: Ctrl + / Ctrl − / Ctrl 0, atau tahan Ctrl sambil memutar roda mouse.", "s",
                 "muted", wraplength=self.wrapw(380), justify="left").pack(anchor="w", pady=(0, P(12)))
        self.lbl(b3, "Ukuran huruf dasar", "b").pack(anchor="w")
        fr = tk.Frame(b3, bg=t["card"])
        fr.pack(anchor="w", pady=(P(6), P(12)))
        self.btn(fr, "−", lambda: self.set_font(-1), "ghost", padx=16).pack(side="left")
        self.lbl(fr, f"  {self.cfg['font']}  ", "m").pack(side="left")
        self.btn(fr, "+", lambda: self.set_font(1), "ghost", padx=16).pack(side="left")
        sr = tk.Frame(b3, bg=t["card"])
        sr.pack(fill="x", pady=(0, P(12)))
        Switch(sr, self, self.cfg.get("autofont", True), self.apply_autofont).pack(side="right")
        tx = tk.Frame(sr, bg=t["card"])
        tx.pack(side="left", fill="x", expand=True)
        self.lbl(tx, "Huruf ikut ukuran jendela", "b").pack(anchor="w")
        self.lbl(tx, "Jendela dibesarkan/dikecilkan → huruf ikut menyesuaikan.", "s", "muted",
                 wraplength=self.wrapw(330), justify="left").pack(anchor="w")
        hr = tk.Frame(b3, bg=t["card"])
        hr.pack(fill="x", pady=(0, P(12)))
        Switch(hr, self, self.hide, lambda v: self.set_hide(v)).pack(side="right")
        hx = tk.Frame(hr, bg=t["card"])
        hx.pack(side="left", fill="x", expand=True)
        self.lbl(hx, "Sembunyikan saldo & keuangan", "b").pack(anchor="w")
        self.lbl(hx, "Saldo, pemasukan, pengeluaran, dan nominal transaksi diganti •••••• (aman saat layar dilihat orang). Pintasan: F8.", "s", "muted",
                 wraplength=self.wrapw(330), justify="left").pack(anchor="w")
        self.lbl(b3, "Menu samping (tab)", "b").pack(anchor="w")
        self.seg_choice(b3, [(None, "Otomatis"), (False, "Lebar"), (True, "Ciut")], self.cfg.get("side"),
                        lambda v: (self.set_side_mode(v), self.show("pengaturan"))).pack(anchor="w", pady=(P(6), P(4)))
        self.lbl(b3, "Klik tombol « di bawah menu, atau tekan F9, untuk menciutkan menu menjadi ikon.", "s",
                 "muted", wraplength=self.wrapw(380), justify="left").pack(anchor="w")

        # --- data
        c4, b4 = self.fold_card(colR, "s_data", "Data & cadangan", 18)
        c4.pack(fill="x", pady=(0, P(14)))
        self.lbl(b4, f"Lokasi data:\n{self.dir}", "s", "muted", justify="left").pack(anchor="w", pady=(0, P(8)))
        for txt, cmd in (("Impor mutasi bank (CSV)…", self.import_dialog),
                         ("Ekspor ke CSV (buka di LibreOffice / Excel)", self.export_csv),
                         ("Cadangkan database…", self.backup_db),
                         ("Pulihkan dari cadangan…", self.restore_db)):
            self.btn(b4, txt, cmd, "ghost", pady=8).pack(anchor="w", pady=3)
        self.lbl(b4, f"nabunglandx v{VERSION}  ·  data hanya tersimpan di perangkatmu", "s", "muted"
                 ).pack(anchor="w", pady=(P(16), 0))

    def build_wp_settings(self, b):
        t, f, P = self.t, self.f, self.px
        wp = self.cfg["wp"]
        cur = wp.get("src", "")
        self.lbl(b, "Latar belakang", "b").pack(anchor="w")
        grid = tk.Frame(b, bg=t["card"])
        grid.pack(anchor="w", pady=(P(6), P(8)))
        self._thumbs = []
        tw, th = P(92), P(54)
        custom = cur.startswith("file:")
        tiles = [("", "Tanpa")] + [("grad:" + k, v[0]) for k, v in WALLS.items()]
        tiles.append((cur if custom else "file:", "Gambar saya"))
        for i, (spec, name) in enumerate(tiles):
            on = (spec == cur) if spec not in ("file:",) else False
            cell = tk.Frame(grid, bg=t["card"])
            cell.grid(row=i // 3, column=i % 3, padx=P(4), pady=P(4))
            if spec == "":
                img = tk.PhotoImage(width=tw, height=th)
                img.put(t["bg"], to=(0, 0, tw, th))
            elif spec == "file:":
                img = tk.PhotoImage(width=tw, height=th)
                img.put(t["card2"], to=(0, 0, tw, th))
            else:
                img = self.wp_thumb(spec, tw, th)
            self._thumbs.append(img)
            lb = tk.Label(cell, image=img, bd=0, highlightthickness=2, cursor="hand2",
                          highlightbackground=t["accent"] if on else t["line"],
                          text="＋  pilih" if spec == "file:" else ("✕" if spec == "" else ""),
                          compound="center", fg=t["muted"], font=f["n"])
            lb.pack()
            cap = tk.Label(cell, text=name, font=f["s"], fg=t["text"] if on else t["muted"], bg=t["card"],
                           cursor="hand2")
            cap.pack()
            if spec == "file:" or (custom and spec == cur):
                cmd = self.wp_pick_file
            else:
                cmd = (lambda s=spec: self.wp_set(s))
            for wd in (lb, cap):
                wd.bind("<Button-1>", lambda e, c=cmd: c())
        has_pil = self.pil_available()
        self.btn(b, "Atur bagian gambar…", self.wp_frame_dialog, "ghost", font="s", pady=6
                 ).pack(anchor="w", pady=(0, P(6)))

        def part_set(key, v):
            wp[key] = bool(v)
            self.save_cfg()
            self._wp_flush()
        for key, label in (("side", "Wallpaper di sidebar"), ("body", "Wallpaper di halaman")):
            r = tk.Frame(b, bg=t["card"])
            r.pack(fill="x", pady=(P(2), P(2)))
            self.lbl(r, label, "n", "text" if cur else "muted").pack(side="left")
            Switch(r, self, wp.get(key, True), lambda v, k=key: part_set(k, v)).pack(side="right")

        def dim_rel(v):
            wp["dim"] = v
            self.save_cfg()
            self.wp_key = None
            self.wp_dirty(10)

        def blur_rel(v):
            wp["blur"] = v
            self.save_cfg()
            self.wp_key = None
            self.wp_dirty(10)

        def alpha_mv(v):
            self.cfg["alpha"] = v
            self.apply_alpha()

        self.slider(b, "Redupkan wallpaper", 0, 90, wp.get("dim", 35), on_release=dim_rel, fmt="{}%",
                    enabled=bool(cur)).pack(fill="x", pady=(P(6), P(4)))
        self.slider(b, "Blur wallpaper", 0, 20, wp.get("blur", 0), on_release=blur_rel, fmt="{} px",
                    enabled=bool(cur) and has_pil).pack(fill="x", pady=(0, P(4)))
        self.slider(b, "Transparansi jendela", 40, 100, self.cfg.get("alpha", 100), on_move=alpha_mv,
                    on_release=lambda v: self.save_cfg(), fmt="{}%").pack(fill="x", pady=(0, P(6)))
        self.lbl(b, "Transparansi membuat seluruh jendela tembus pandang (butuh compositor: GNOME/KDE/Windows "
                    "sudah punya). 100% = solid.", "s", "muted", wraplength=self.wrapw(380),
                 justify="left").pack(anchor="w")
        if not has_pil:
            r = tk.Frame(b, bg=t["card"])
            r.pack(fill="x", pady=(P(10), 0))
            self.lbl(r, "Mode ringan: gambar PNG/GIF saja. Pasang Pillow untuk JPG/WEBP, blur, dan redup halus.",
                     "s", "muted", wraplength=self.wrapw(380), justify="left").pack(anchor="w")
            self.btn(r, "Pasang Pillow (otomatis)", self.install_pillow, "ghost", font="s", pady=6
                     ).pack(anchor="w", pady=(P(6), 0))

    def set_theme(self, name):
        self.cfg["theme"] = name
        self.apply_theme()

    def set_accent(self, c):
        self.cfg["accent"] = c
        self.apply_theme()

    def set_font(self, d):
        self.cfg["font"] = min(14, max(8, int(self.cfg["font"]) + d))
        self.apply_theme()

    def pick_color(self, key):
        cur = self.t["accent"] if key == "accent" else self.t[key]
        _, hx = colorchooser.askcolor(color=cur, parent=self, title="Pilih warna")
        if not hx:
            return
        if key == "accent":
            self.cfg["accent"] = hx.lower()
        else:
            if self.cfg["theme"] != "Kustom":
                self.cfg["custom"] = {k: self.t[k] for k in ("bg", "card", "text")}
                self.cfg["theme"] = "Kustom"
            self.cfg.setdefault("custom", {})[key] = hx.lower()
        self.apply_theme()

    def export_csv(self):
        p = filedialog.asksaveasfilename(parent=self, defaultextension=".csv",
                                         initialfile=f"nabunglandx-{date.today()}.csv",
                                         filetypes=[("CSV", "*.csv")])
        if not p:
            return
        names = {"in": "Pemasukan", "out": "Pengeluaran", "tf": "Transfer"}
        with open(p, "w", newline="", encoding="utf-8-sig") as fh:
            wr = csv.writer(fh)
            wr.writerow(["Tanggal", "Jenis", "Jumlah", "Rekening", "Ke rekening", "Kategori", "Catatan"])
            for r in self.db.all_tx():
                wr.writerow([r["day"], names[r["kind"]], r["amount"], r["an"], r["bn"] or "",
                             r["cat"] or "", r["note"] or ""])
        messagebox.showinfo("Selesai", f"Tersimpan di:\n{p}", parent=self)

    def backup_db(self):
        p = filedialog.asksaveasfilename(parent=self, defaultextension=".db",
                                         initialfile=f"nabunglandx-cadangan-{date.today()}.db",
                                         filetypes=[("Database", "*.db")])
        if not p:
            return
        dest = sqlite3.connect(p)
        self.db.c.backup(dest)
        dest.close()
        messagebox.showinfo("Selesai", f"Cadangan tersimpan di:\n{p}", parent=self)

    def restore_db(self):
        p = filedialog.askopenfilename(parent=self, filetypes=[("Database", "*.db")])
        if not p:
            return
        try:
            chk = sqlite3.connect(p)
            chk.execute("SELECT COUNT(*) FROM accounts")
            chk.execute("SELECT COUNT(*) FROM tx")
            chk.close()
        except Exception:
            return messagebox.showerror("Gagal", "File ini bukan cadangan nabunglandx.", parent=self)
        if not messagebox.askyesno("Pulihkan", "Data saat ini akan diganti dengan cadangan. Lanjut?",
                                   parent=self):
            return
        self.db.close()
        shutil.copyfile(p, self.db_path)
        self.db.open()
        self.show("dashboard")


def main():
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    App().mainloop()


if __name__ == "__main__":
    main()
